function sol = vfi_solver(modelo, tol_V, max_iter, V_init)
% VFI_SOLVER Solucionador de Bellman por Iteracao da Funcao Valor (VFI) vetorizada.
%
% Sintaxe:
%   sol = vfi_solver(modelo)
%   sol = vfi_solver(modelo, tol_V, max_iter, V_init)

    if nargin < 2 || isempty(tol_V),   tol_V = 1e-7;   end
    if nargin < 3 || isempty(max_iter), max_iter = 1500; end
    if nargin < 4,                     V_init = [];    end

    sol = vfi_extensao_vetorizada(modelo, tol_V, max_iter, V_init);
end
