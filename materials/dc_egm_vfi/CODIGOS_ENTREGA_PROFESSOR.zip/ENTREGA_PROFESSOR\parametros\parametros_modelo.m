function params = parametros_modelo(Na, chi_bar)
% PARAMETROS_MODELO Parametros economicos do modelo com Escolhas Ocupacionais e Custos de Transicao.
%
% Sintaxe:
%   params = parametros_modelo(Na, chi_bar)
%
% Entradas:
%   Na      - Numero de pontos da grade de ativos (default: 400)
%   chi_bar - Custo de transicao entre ocupacoes (default: 0.05)

    if nargin < 1 || isempty(Na),      Na      = 400;  end
    if nargin < 2 || isempty(chi_bar), chi_bar = 0.05; end

    params = parametros_modelo_ext(0.00, chi_bar, Na);
end
