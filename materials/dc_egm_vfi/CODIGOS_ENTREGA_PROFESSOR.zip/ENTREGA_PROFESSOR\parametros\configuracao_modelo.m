function cfg = configuracao_modelo(Na, chi_bar)
% CONFIGURACAO_MODELO Parametros estruturais e numericos do modelo canonico.
%
% Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
% Uma Comparacao entre VFI e DC-EGM
%
% NOTA METODOLOGICA:
%   O pipeline oficial de resolucao utiliza 'parametros_modelo.m' e
%   'parametros_modelo_ext.m'. Esta funcao serve como documentacao interativa
%   e consulta rapida da calibracao canonica adotada na pesquisa.
%
% Sintaxe:
%   cfg = configuracao_modelo()
%   cfg = configuracao_modelo(Na, chi_bar)

    if nargin < 1 || isempty(Na),      Na      = 400;  end
    if nargin < 2 || isempty(chi_bar), chi_bar = 0.05; end

    % Obtem os parametros diretamente da rotina oficial canonica
    p = parametros_modelo(Na, chi_bar);

    cfg = struct();
    % 1. Preferencias das Familias
    cfg.beta        = p.beta;       % Fator de desconto intertemporal (0.96)
    cfg.sigma       = p.sigma;      % Coeficiente de aversao relativa ao risco (CRRA = 2.0)
    cfg.psi         = p.psi;        % Desutilidade de esforco por setor [0, 0.05, 0.08]

    % 2. Tecnologia e Producao Neoclassica
    cfg.alpha       = p.alpha;      % Participacao do capital na funcao Cobb-Douglas (0.36)
    cfg.delta       = p.delta;      % Taxa de depreciacao anual do capital fisico (0.08)
    cfg.A           = p.A;          % Produtividade total dos fatores (PTF = 1.0)

    % 3. Setor Publico, Ocupacoes e Mercado de Trabalho
    cfg.kappa       = p.kappa;      % Produtividade relativa do setor informal (0.72)
    cfg.tau         = p.tau;        % Aliquota tributaria do setor formal (0.20)
    cfg.tau_d       = p.tau_d;      % Aliquotas por ocupacao [0, 0, 0.20]
    cfg.h_eff       = p.h_eff;      % Oferta de horas efetivas por setor [0, 0.72, 1.0]
    cfg.chi_bar     = p.chi_bar;    % Custo fixo de transicao ocupacional (0.05)
    cfg.scale_eps   = p.scale_eps;  % Escala de taste shocks (0.00 = deterministico)

    % 4. Processo Estocastico de Produtividade Idiossincratica (Rouwenhorst)
    cfg.rho_z       = p.rho_z;      % Persistencia AR(1) da produtividade (0.90)
    cfg.sigma_eps   = p.sigma_eps;  % Desvio-padrao das inovacoes (0.20)
    cfg.Nz          = p.Nz;         % Numero de estados discretos de produtividade (5)

    % 5. Grade de Ativos (Discretizacao Continua)
    cfg.Na          = p.Na;         % Numero de nos de ativos (400, 800 ou 1600)
    cfg.a_min       = p.a_min;      % Limite inferior de credito (0.0)
    cfg.a_max       = p.a_max;      % Limite superior de ativos (80.0)

    % 6. Precos de Referencia em Equilibrio Parcial (Regra de Ouro Modificada)
    cfg.r_pe        = (1.0 / p.beta) - 1.0; % r = 4.1667%
    k_rep           = (cfg.alpha * cfg.A / (cfg.r_pe + cfg.delta))^(1.0 / (1.0 - cfg.alpha));
    cfg.w_pe        = (1.0 - cfg.alpha) * cfg.A * (k_rep^cfg.alpha); % w = 1.178124
    cfg.k_rep       = k_rep;        % Razao capital-trabalho representativa (5.4055)
end
