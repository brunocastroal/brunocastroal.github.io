function [u, du, inv_du, d2u] = utilidade_crra(c, sigma, target_du)
% UTILIDADE_CRRA Avalia a utilidade CRRA, utilidade marginal, inversa e segunda derivada.
%
% Trata estritamente o limite logaritmico sigma -> 1:
%   u(c)      = log(c)
%   u'(c)     = 1/c
%   (u')^-1(x)= 1/x
%   u''(c)    = -1/c^2
%
% Entradas:
%   c         - Consumo (escalar, vetor ou matriz)
%   sigma     - Coeficiente de aversao relativa ao risco (CRRA >= 0)
%   target_du - (Opcional) Valor da utilidade marginal para calcular a inversa (u')^-1

    u = []; du = []; inv_du = []; d2u = [];
    if nargin < 2 || isempty(sigma)
        sigma = 2.0;
    end

    limite_log = abs(sigma - 1.0) < 1e-6;

    if nargin >= 1 && ~isempty(c)
        % Tratar consumo nao positivo
        mask_invalido = (c <= 0);

        if limite_log
            u = log(max(c, 1e-12));
            if any(mask_invalido(:))
                u(mask_invalido) = -1e10;
            end
        else
            u = (max(c, 1e-12).^(1.0 - sigma) - 1.0) / (1.0 - sigma);
            if any(mask_invalido(:))
                u(mask_invalido) = -1e10;
            end
        end

        if nargout >= 2
            if limite_log
                du = 1.0 ./ max(c, 1e-12);
            else
                du = max(c, 1e-12).^(-sigma);
            end
            if any(mask_invalido(:))
                du(mask_invalido) = 1e10;
            end
        end

        if nargout >= 4
            if limite_log
                d2u = -1.0 ./ (max(c, 1e-12).^2);
            else
                d2u = -sigma * max(c, 1e-12).^(-sigma - 1.0);
            end
        end
    end

    if nargin >= 3 && ~isempty(target_du)
        target_du_safe = max(target_du, 1e-12);
        if limite_log
            inv_du = 1.0 ./ target_du_safe;
        else
            inv_du = target_du_safe.^(-1.0 / sigma);
        end
    end
end
