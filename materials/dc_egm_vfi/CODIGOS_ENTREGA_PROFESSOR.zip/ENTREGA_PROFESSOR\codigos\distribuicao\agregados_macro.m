function agregados = agregados_macro(distribuicao, modelo, solucao)
% AGREGADOS_MACRO Calcula agregados macroeconomicos, composicao ocupacional,
% estatisticas de distribuicao de riqueza e consistencia contabil de Walras.
%
% Sintaxe:
%   agregados = agregados_macro(distribuicao, modelo, solucao)
%
% Entradas:
%   distribuicao - Estrutura retornada por distribuicao_estacionaria
%   modelo       - Estrutura retornada por preprocessamento_modelo_ext
%   solucao      - Estrutura retornada por dc_egm_extensao ou vfi_extensao_vetorizada
%
% Saidas:
%   agregados    - Estrutura com variaveis macroeconomicas e distributivas

    mu = distribuicao.mu; % Na x Nz x 3
    mu_a = distribuicao.mu_a; % Na x 1
    Na = modelo.Na;
    Nz = modelo.Nz;
    a  = modelo.a;
    z  = modelo.z;
    params = modelo.params;

    A_ptf  = params.A;
    alpha  = params.alpha;
    delta  = params.delta;
    tau    = params.tau;
    kappa  = params.kappa;
    w      = modelo.w;
    r      = modelo.r;

    % 1. Capital agregado ofertado K_s e poupanca agregada esperada K_prime
    A_3d = repmat(a, [1, Nz, 3]);
    K_s  = sum(mu(:) .* A_3d(:));

    % Poupanca no proximo periodo por ramo e ponderada por escolhas
    % aprime_exp(i, j, d_prev) = sum_d P_d(i, j, d, d_prev) * aprime_d(i, j, d)
    K_prime = sum(mu(:) .* solucao.aprime_exp(:));
    diff_K_invariancia = abs(K_prime - K_s);

    % 2. Consumo agregado C_s
    C_s = sum(mu(:) .* solucao.c_exp(:));

    % 3. Participacoes ocupacionais agregadas (massas M_N, M_I, M_F)
    M_N = 0.0; M_I = 0.0; M_F = 0.0;
    L_I = 0.0; L_F = 0.0;

    for d_prev = 1:3
        for j = 1:Nz
            mu_slice = mu(:, j, d_prev);
            prob_N = solucao.P_d(:, j, 1, d_prev);
            prob_I = solucao.P_d(:, j, 2, d_prev);
            prob_F = solucao.P_d(:, j, 3, d_prev);

            mass_N_slice = sum(mu_slice .* prob_N);
            mass_I_slice = sum(mu_slice .* prob_I);
            mass_F_slice = sum(mu_slice .* prob_F);

            M_N = M_N + mass_N_slice;
            M_I = M_I + mass_I_slice;
            M_F = M_F + mass_F_slice;

            % Trabalho efetivo: L_N = 0, L_I = kappa * z_j, L_F = z_j
            L_I = L_I + mass_I_slice * (kappa * z(j));
            L_F = L_F + mass_F_slice * z(j);
        end
    end
    L_s = L_I + L_F;

    % 4. Razao capital-trabalho e producao da firma representativa
    k_supply = K_s / L_s;
    Y_prod   = A_ptf * (K_s^alpha) * (L_s^(1.0 - alpha));
    I_deprec = delta * K_s;
    G_gov    = tau * w * L_F;

    absorcao_total = C_s + I_deprec + G_gov;
    hiato_walras   = Y_prod - absorcao_total;

    % Precos implicitos pela oferta de fatores
    r_implied = alpha * A_ptf * (k_supply^(alpha - 1.0)) - delta;
    w_implied = (1.0 - alpha) * A_ptf * (k_supply^alpha);

    % 5. Estatisticas distributivas e desigualdade de riqueza
    % Media e desvio padrao
    media_a = K_s;
    var_a   = sum(mu_a .* (a - media_a).^2);
    dp_a    = sqrt(max(var_a, 0.0));

    % Coeficiente de Gini
    diff_matrix = abs(bsxfun(@minus, a, a'));
    peso_matrix = mu_a * mu_a';
    if media_a > 1e-12
        gini_riqueza = sum(sum(peso_matrix .* diff_matrix)) / (2.0 * media_a);
    else
        gini_riqueza = 0.0;
    end

    % Percentis acumulados de riqueza
    cdf_a = cumsum(mu_a);
    cdf_a(end) = 1.0;

    pct_list = [0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99];
    percentis_val = zeros(size(pct_list));
    for p_idx = 1:length(pct_list)
        target_p = pct_list(p_idx);
        k_hit = find(cdf_a >= target_p, 1, 'first');
        if isempty(k_hit) || k_hit == 1
            percentis_val(p_idx) = a(1);
        else
            % Interpolacao linear no percentil
            w_int = (target_p - cdf_a(k_hit - 1)) / max(cdf_a(k_hit) - cdf_a(k_hit - 1), 1e-15);
            percentis_val(p_idx) = a(k_hit - 1) + w_int * (a(k_hit) - a(k_hit - 1));
        end
    end

    % Top shares e Bottom 50%
    % Riqueza acumulada da fracao inferior a corte p
    % Fatias: Bottom 50%, Top 10%, Top 5%, Top 1%
    k_50 = find(cdf_a >= 0.50, 1, 'first');
    bottom_50 = sum(mu_a(1:k_50) .* a(1:k_50)) / max(K_s, 1e-12);

    k_90 = find(cdf_a >= 0.90, 1, 'first');
    top_10 = sum(mu_a(k_90:end) .* a(k_90:end)) / max(K_s, 1e-12);

    k_95 = find(cdf_a >= 0.95, 1, 'first');
    top_5 = sum(mu_a(k_95:end) .* a(k_95:end)) / max(K_s, 1e-12);

    k_99 = find(cdf_a >= 0.99, 1, 'first');
    top_1 = sum(mu_a(k_99:end) .* a(k_99:end)) / max(K_s, 1e-12);

    % Fracao no limite inferior (restricao de liquidez) e superior
    frac_a_min = mu_a(1);
    frac_a_max = mu_a(end);

    % Consolidacao da estrutura de agregados
    agregados = struct();
    agregados.K_s                = K_s;
    agregados.K_prime            = K_prime;
    agregados.diff_K_invariancia = diff_K_invariancia;
    agregados.L_s                = L_s;
    agregados.L_I                = L_I;
    agregados.L_F                = L_F;
    agregados.k_supply           = k_supply;
    agregados.C_s                = C_s;
    agregados.M_N                = M_N;
    agregados.M_I                = M_I;
    agregados.M_F                = M_F;
    agregados.Y_prod             = Y_prod;
    agregados.I_deprec           = I_deprec;
    agregados.G_gov              = G_gov;
    agregados.absorcao_total     = absorcao_total;
    agregados.hiato_walras       = hiato_walras;
    agregados.r_implied          = r_implied;
    agregados.w_implied          = w_implied;
    agregados.media_a            = media_a;
    agregados.dp_a               = dp_a;
    agregados.gini_riqueza       = gini_riqueza;
    agregados.P10                = percentis_val(1);
    agregados.P25                = percentis_val(2);
    agregados.P50                = percentis_val(3);
    agregados.P75                = percentis_val(4);
    agregados.P90                = percentis_val(5);
    agregados.P95                = percentis_val(6);
    agregados.P99                = percentis_val(7);
    agregados.bottom_50          = bottom_50;
    agregados.top_10             = top_10;
    agregados.top_5              = top_5;
    agregados.top_1              = top_1;
    agregados.frac_a_min         = frac_a_min;
    agregados.frac_a_max         = frac_a_max;
end
