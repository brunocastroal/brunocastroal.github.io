function dist = distribuicao_estacionaria(modelo, solucao, opcoes)
% DISTRIBUICAO_ESTACIONARIA Calcula a distribuicao estacionaria conjunta mu(a, z, d^-)
% usando o operador de transicao esparso de Young (2010) com escolhas probabilisticas
% e politicas de poupanca especificas por ramo ocupacional.
%
% Sintaxe:
%   dist = distribuicao_estacionaria(modelo, solucao)
%   dist = distribuicao_estacionaria(modelo, solucao, opcoes)
%
% Entradas:
%   modelo  - Estrutura contendo parametros e grade do modelo
%   solucao - Estrutura retornada por dc_egm_extensao ou vfi_extensao_vetorizada
%   opcoes  - (Opcional) Estrutura com parametros de simulacao:
%               .tol_dist (default: 1e-10)
%               .max_iter (default: 25000)
%               .mu_init  (default: uniforme)
%               .verbose  (default: false)
%
% Saidas:
%   dist - Estrutura com a distribuicao estacionaria e diagnosticos

    if nargin < 3, opcoes = struct(); end
    if ~isfield(opcoes, 'tol_dist'), opcoes.tol_dist = 1e-10; end
    if ~isfield(opcoes, 'max_iter'), opcoes.max_iter = 25000; end
    if ~isfield(opcoes, 'verbose'),  opcoes.verbose  = false; end

    t_start = tic;

    Na = modelo.Na;
    Nz = modelo.Nz;
    N_states = Na * Nz * 3;
    a = modelo.a;
    delta_a = a(2) - a(1);
    Pi = modelo.Pi;

    % 1. Construcao vetorizada dos triplets do operador de transicao de Young (2010)
    % Para cada um dos N_states estados (i, j, d_prev):
    % O agente escolhe d in {1, 2, 3} com probabilidade P_d(i, j, d, d_prev).
    % Poupanca no ramo d: a' = aprime_d(i, j, d).
    % Loteria linear de Young sobre [a_k, a_{k+1}].
    % Proximo choque de produtividade j' com probabilidade Pi(j, j').
    % Proxima ocupacao anterior: d' = d.
    % Total de transicoes por estado: 3 ramos x 2 vizinhos x Nz choques = 30 nao-zeros.

    total_nnz_max = N_states * 30;
    rows = zeros(total_nnz_max, 1);
    cols = zeros(total_nnz_max, 1);
    vals = zeros(total_nnz_max, 1);
    ptr = 0;

    [I, J, D_prev] = ndgrid(1:Na, 1:Nz, 1:3);
    s_source = I(:) + (J(:) - 1) * Na + (D_prev(:) - 1) * Na * Nz;

    for d = 1:3
        % Politica de poupanca do ramo d: Na x Nz
        ap = solucao.aprime_d(:, :, d);
        k_flt = 1.0 + (ap - a(1)) / delta_a;
        k_idx = min(max(floor(k_flt), 1), Na - 1);
        omega = min(max(k_idx + 1.0 - k_flt, 0.0), 1.0);

        % Probabilidade de escolha ocupacional P(d | a_i, z_j, d_prev)
        % solucao.P_d tem dimensao Na x Nz x 3 x 3
        prob_slice = solucao.P_d(:, :, d, :);
        prob_vec = prob_slice(:); % vetor de tamanho N_states alinhado a s_source

        % Expansao de k_idx e omega ao longo de d_prev
        k_vec = repmat(k_idx(:), [3, 1]);
        omega_vec = repmat(omega(:), [3, 1]);

        for jp = 1:Nz
            pi_val = Pi(J(:), jp);

            % Alvo 1: (k, jp, d)
            s_target1 = k_vec + (jp - 1) * Na + (d - 1) * Na * Nz;
            w1 = prob_vec .* omega_vec .* pi_val;

            % Alvo 2: (k+1, jp, d)
            s_target2 = (k_vec + 1) + (jp - 1) * Na + (d - 1) * Na * Nz;
            w2 = prob_vec .* (1.0 - omega_vec) .* pi_val;

            idx_range1 = (ptr + 1):(ptr + N_states);
            rows(idx_range1) = s_source;
            cols(idx_range1) = s_target1;
            vals(idx_range1) = w1;
            ptr = ptr + N_states;

            idx_range2 = (ptr + 1):(ptr + N_states);
            rows(idx_range2) = s_source;
            cols(idx_range2) = s_target2;
            vals(idx_range2) = w2;
            ptr = ptr + N_states;
        end
    end

    % Montar matriz de transicao estocastica esparsa
    T = sparse(rows, cols, vals, N_states, N_states);
    t_build = toc(t_start);

    % 2. Verificacao estocastica do operador
    soma_linhas = full(sum(T, 2));
    erro_estoc = max(abs(soma_linhas - 1.0));
    if erro_estoc > 1e-12
        warning('Operador de transicao com desvio estocastico: %.2e', erro_estoc);
    end

    % 3. Iteracao de potencia para distribuicao invariante
    if isfield(opcoes, 'mu_init') && ~isempty(opcoes.mu_init)
        mu = opcoes.mu_init(:)';
        mu = mu / sum(mu);
    else
        mu = ones(1, N_states) / N_states;
    end

    t_iter_start = tic;
    convergiu = false;
    diff_sup = 1.0;

    for it = 1:opcoes.max_iter
        mu_new = mu * T;
        diff_sup = max(abs(mu_new - mu));
        mu = mu_new;

        if diff_sup < opcoes.tol_dist
            convergiu = true;
            break;
        end

        if opcoes.verbose && mod(it, 1000) == 0
            fprintf('Distribuicao iter %d: diff_sup = %.2e\n', it, diff_sup);
        end
    end

    t_iter = toc(t_iter_start);
    tempo_total = toc(t_start);

    % Garantir nao negatividade e normalizacao exata
    mu = max(mu, 0.0);
    mu = mu / sum(mu);

    % Tensor 3D mu(a, z, d_prev)
    mu_3d = reshape(mu, [Na, Nz, 3]);

    % Distribuicoes marginais
    mu_a = squeeze(sum(sum(mu_3d, 2), 3)); % Na x 1
    mu_z = squeeze(sum(sum(mu_3d, 1), 3))'; % Nz x 1
    mu_d = squeeze(sum(sum(mu_3d, 1), 2)); % 3 x 1

    % Fracoes nos extremos da grade
    massa_a_min = mu_a(1);
    massa_a_max = mu_a(end);

    % Montar estrutura de saida
    dist = struct();
    dist.mu          = mu_3d;
    dist.mu_vec      = mu;
    dist.mu_a        = mu_a;
    dist.mu_z        = mu_z;
    dist.mu_d        = mu_d;
    dist.T           = T;
    dist.iteracoes   = it;
    dist.dist_final  = diff_sup;
    dist.convergiu   = convergiu;
    dist.tempo_build = t_build;
    dist.tempo_iter  = t_iter;
    dist.tempo       = tempo_total;
    dist.massa_total = sum(mu);
    dist.massa_a_min = massa_a_min;
    dist.massa_a_max = massa_a_max;
    dist.erro_estoc  = erro_estoc;
end
