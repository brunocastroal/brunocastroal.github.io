function sol = vfi_extensao_vetorizada(modelo, tol_V, max_iter, V_init)
% VFI_EXTENSAO_VETORIZADA Resolve Bellman com Taste Shocks e Custos de Transicao via Broadcasting Matricial.
%
% Pre-calcula matrizes de utilidade de fluxo e executa a maximizacao de forma vetorizada.
%
% Entradas:
%   modelo   - Estrutura gerada por preprocessamento_modelo_ext
%   tol_V    - Tolerancia de convergencia ||V_new - V||_inf (default: 1e-7)
%   max_iter - Numero maximo de iteracoes de Bellman (default: 1000)
%   V_init   - Chute inicial para V(a, z, d^-) (Na x Nz x 3). Opcional.

    if nargin < 2 || isempty(tol_V), tol_V = 1e-7; end
    if nargin < 3 || isempty(max_iter), max_iter = 1000; end

    params    = modelo.params;
    beta      = params.beta;
    sigma     = params.sigma;
    psi       = params.psi;
    scale_eps = modelo.scale_eps;
    chi_mat   = modelo.chi_mat;

    Na = modelo.Na;
    Nz = modelo.Nz;
    a  = modelo.a;
    R  = modelo.R;
    y  = modelo.y;
    Pi = modelo.Pi;

    if nargin >= 4 && ~isempty(V_init)
        V = V_init;
    else
        V = zeros(Na, Nz, 3);
    end

    t_start = tic;

    % 1. PRE-COMPUTACAO DAS MATRIZES DE CONSUMO E UTILIDADE DE FLUXO (Na x Na x Nz x 3)
    % Dimensao 1: ativos correntes a_i
    % Dimensao 2: ativos futuros a'_k
    % Dimensao 3: choque de produtividade z_j
    % Dimensao 4: ocupacao corrente escolhida d
    u_fluxo = -Inf(Na, Na, Nz, 3);
    a_col   = reshape(a, [Na, 1]);
    ap_row  = reshape(a, [1, Na]);

    for d = 1:3
        psi_d = psi(d);
        for j = 1:Nz
            yj = y(j, d);
            c_mat = R * a_col + yj - ap_row; % Na x Na
            mask_pos = (c_mat > 0);
            u_sub = -Inf(Na, Na);
            u_sub(mask_pos) = utilidade_crra(c_mat(mask_pos), sigma) - psi_d;
            u_fluxo(:, :, j, d) = u_sub;
        end
    end

    convergiu = false;
    iter = 0;
    erro_V = Inf;

    W          = zeros(Na, Nz, 3);
    tilde_v    = zeros(Na, Nz, 3);
    pol_aprime = zeros(Na, Nz, 3);
    pol_c      = zeros(Na, Nz, 3);
    v_cond     = zeros(Na, Nz, 3, 3);
    P_d        = zeros(Na, Nz, 3, 3);
    V_new      = zeros(Na, Nz, 3);

    while iter < max_iter && ~convergiu
        iter = iter + 1;

        % 1. Continuacao esperada por ocupacao
        for d = 1:3
            W(:, :, d) = beta * (V(:, :, d) * Pi');
        end

        % 2. Maximizacao vetorizada sobre a'
        for d = 1:3
            W_d_3d = reshape(W(:, :, d), [1, Na, Nz]); % 1 x Na x Nz
            val_mat = bsxfun(@plus, u_fluxo(:, :, :, d), W_d_3d); % Na x Na x Nz
            [max_v, idx_k] = max(val_mat, [], 2);

            tilde_v(:, :, d)    = reshape(max_v, [Na, Nz]);
            idx_sub             = reshape(idx_k, [Na, Nz]);
            pol_aprime(:, :, d) = a(idx_sub);

            for j = 1:Nz
                pol_c(:, j, d) = R * a + y(j, d) - pol_aprime(:, j, d);
            end
        end

        % 3. Custos de transicao, taste shocks e valor inclusivo
        for d_prev = 1:3
            v1 = tilde_v(:, :, 1) - chi_mat(d_prev, 1);
            v2 = tilde_v(:, :, 2) - chi_mat(d_prev, 2);
            v3 = tilde_v(:, :, 3) - chi_mat(d_prev, 3);

            v_cond(:, :, 1, d_prev) = v1;
            v_cond(:, :, 2, d_prev) = v2;
            v_cond(:, :, 3, d_prev) = v3;

            if scale_eps > 0
                m  = max(v1, max(v2, v3));
                e1 = exp((v1 - m) / scale_eps);
                e2 = exp((v2 - m) / scale_eps);
                e3 = exp((v3 - m) / scale_eps);
                S  = e1 + e2 + e3;

                V_new(:, :, d_prev) = m + scale_eps * log(S);

                P_d(:, :, 1, d_prev) = e1 ./ S;
                P_d(:, :, 2, d_prev) = e2 ./ S;
                P_d(:, :, 3, d_prev) = e3 ./ S;
            else
                [max_v, d_star_mat] = max(cat(4, v1, v2, v3), [], 4);
                V_new(:, :, d_prev) = max_v;

                P_d(:, :, 1, d_prev) = double(d_star_mat == 1);
                P_d(:, :, 2, d_prev) = double(d_star_mat == 2);
                P_d(:, :, 3, d_prev) = double(d_star_mat == 3);
            end
        end

        % 4. Teste de convergencia
        erro_V = max(abs(V_new(:) - V(:)));
        V = V_new;

        if erro_V < tol_V
            convergiu = true;
        end
    end

    tempo_total = toc(t_start);

    % 5. Politicas agregadas
    aprime_exp = zeros(Na, Nz, 3);
    c_exp      = zeros(Na, Nz, 3);
    for d_prev = 1:3
        aprime_exp(:, :, d_prev) = P_d(:, :, 1, d_prev) .* pol_aprime(:, :, 1) + ...
                                   P_d(:, :, 2, d_prev) .* pol_aprime(:, :, 2) + ...
                                   P_d(:, :, 3, d_prev) .* pol_aprime(:, :, 3);
        c_exp(:, :, d_prev)      = P_d(:, :, 1, d_prev) .* pol_c(:, :, 1) + ...
                                   P_d(:, :, 2, d_prev) .* pol_c(:, :, 2) + ...
                                   P_d(:, :, 3, d_prev) .* pol_c(:, :, 3);
    end

    sol = struct();
    sol.V          = V;
    sol.v_cond     = v_cond;
    sol.P_d        = P_d;
    sol.aprime_d   = pol_aprime;
    sol.c_d        = pol_c;
    sol.aprime_exp = aprime_exp;
    sol.c_exp      = c_exp;
    sol.iter       = iter;
    sol.erro_V     = erro_V;
    sol.convergiu  = convergiu;
    sol.tempo      = tempo_total;

    if scale_eps == 0
        [~, d_star_full] = max(v_cond, [], 3);
        sol.d_star = squeeze(d_star_full);
    else
        sol.d_star = [];
    end
end
