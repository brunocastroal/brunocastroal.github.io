function pasta_raiz = obter_raiz_projeto(caminho_ref)
% OBTER_RAIZ_PROJETO Localiza a pasta raiz do projeto (ENTREGA_PROFESSOR).
%
% Sobe ate 5 niveis na arvore de diretorios a partir do arquivo ou pasta
% de referencia ate encontrar as subpastas canonicas 'resultados' e 'parametros'.
%
% Sintaxe:
%   pasta_raiz = obter_raiz_projeto()
%   pasta_raiz = obter_raiz_projeto(mfilename('fullpath'))

    if nargin < 1 || isempty(caminho_ref)
        caminho_ref = mfilename('fullpath');
    end

    if isfolder(caminho_ref)
        pasta_atual = caminho_ref;
    else
        pasta_atual = fileparts(caminho_ref);
    end
    if isempty(pasta_atual)
        pasta_atual = pwd;
    end

    pasta_raiz = pasta_atual;
    for k_up = 1:5
        if isfolder(fullfile(pasta_raiz, 'resultados')) && isfolder(fullfile(pasta_raiz, 'parametros'))
            return;
        end
        pasta_pai = fileparts(pasta_raiz);
        if strcmp(pasta_pai, pasta_raiz)
            break;
        end
        pasta_raiz = pasta_pai;
    end

    % Fallback caso executado fora da arvore padrao
    if ~(isfolder(fullfile(pasta_raiz, 'resultados')) && isfolder(fullfile(pasta_raiz, 'parametros')))
        pasta_pwd = pwd;
        if isfolder(fullfile(pasta_pwd, 'resultados')) && isfolder(fullfile(pasta_pwd, 'parametros'))
            pasta_raiz = pasta_pwd;
        end
    end
end
