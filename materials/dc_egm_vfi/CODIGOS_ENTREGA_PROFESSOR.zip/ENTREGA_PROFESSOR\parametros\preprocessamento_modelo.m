function modelo = preprocessamento_modelo(params)
% PREPROCESSAMENTO_MODELO Preprocessamento de matrizes e grades para o modelo.
%
% Sintaxe:
%   modelo = preprocessamento_modelo()
%   modelo = preprocessamento_modelo(params)

    if nargin < 1 || isempty(params)
        params = parametros_modelo();
    end
    modelo = preprocessamento_modelo_ext(params);
end
