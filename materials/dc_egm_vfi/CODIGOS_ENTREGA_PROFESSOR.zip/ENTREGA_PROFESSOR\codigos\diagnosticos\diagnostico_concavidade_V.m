function res = diagnostico_concavidade_V(modelo, solucao)
% DIAGNOSTICO_CONCAVIDADE_V Avalia numericamente a concavidade da funcao valor V(a, z, d^-)
% e das funcoes valor condicionais v_d(a, z, d^-) atraves de diferencas finitas de 2a ordem.
%
% Sintaxe:
%   res = diagnostico_concavidade_V(modelo, solucao)
%
% Entradas:
%   modelo  - Estrutura retornada por preprocessamento_modelo_ext
%   solucao - Estrutura retornada por dc_egm_extensao ou vfi_extensao_vetorizada
%
% Saidas:
%   res - Estrutura com estatisticas detalhadas de segunda diferenca:
%         .D2V           - Tensor Na-2 x Nz x 3 de segundas diferencas divididas (V_aa)
%         .max_D2V       - Maior valor de V_aa em cada (j, d_prev)
%         .min_D2V       - Menor valor de V_aa em cada (j, d_prev)
%         .num_pos       - Contagem de pontos positivos (V_aa > 0)
%         .pct_pos       - Percentual de pontos positivos
%         .maior_seq_pos - Tamanho da maior sequencia consecutiva de V_aa > 0
%         .loc_pos       - Valores de a onde V_aa > 0
%         .razao_escala  - Razao max(D2V) / |min(D2V)|
%         .media_pos     - Media dos valores estritamente positivos
%         .media_neg     - Media dos valores estritamente negativos
%         .total_pos     - Contagem total de pontos positivos em todo o espaco de estados
%         .total_pontos  - Total de pontos interiores avaliados (Na-2)*Nz*3
%         .pct_total_pos - Percentual global de convexidade local

    Na = modelo.Na;
    Nz = modelo.Nz;
    a  = modelo.a;
    delta_a = a(2) - a(1);
    delta_a2 = delta_a^2;

    V = solucao.V; % Na x Nz x 3

    % Diferencas finitas de segunda ordem centralizadas para i = 2 ... Na - 1
    % D2V(i-1, j, d_prev) = (V(i+1) - 2*V(i) + V(i-1)) / delta_a^2
    V_interior_plus  = V(3:Na, :, :);
    V_interior_mid   = V(2:Na-1, :, :);
    V_interior_minus = V(1:Na-2, :, :);

    D2V_raw = V_interior_plus - 2.0 * V_interior_mid + V_interior_minus;
    D2V = D2V_raw / delta_a2;

    a_interior = a(2:Na-1);
    num_interior = Na - 2;

    % Estatisticas por estado (j, d_prev)
    max_D2V       = zeros(Nz, 3);
    min_D2V       = zeros(Nz, 3);
    num_pos       = zeros(Nz, 3);
    pct_pos       = zeros(Nz, 3);
    maior_seq_pos = zeros(Nz, 3);
    razao_escala  = zeros(Nz, 3);
    media_pos     = zeros(Nz, 3);
    media_neg     = zeros(Nz, 3);
    loc_pos_cell  = cell(Nz, 3);

    for d_prev = 1:3
        for j = 1:Nz
            d2_slice = D2V(:, j, d_prev);

            max_val = max(d2_slice);
            min_val = min(d2_slice);
            max_D2V(j, d_prev) = max_val;
            min_D2V(j, d_prev) = min_val;

            mask_pos = (d2_slice > 0);
            n_pos = sum(mask_pos);
            num_pos(j, d_prev) = n_pos;
            pct_pos(j, d_prev) = (n_pos / num_interior) * 100.0;

            loc_pos_cell{j, d_prev} = a_interior(mask_pos);

            % Maior sequencia consecutiva de positivos
            if n_pos > 0
                diff_idx = diff([0; mask_pos; 0]);
                start_runs = find(diff_idx == 1);
                end_runs   = find(diff_idx == -1) - 1;
                run_lengths = end_runs - start_runs + 1;
                maior_seq_pos(j, d_prev) = max(run_lengths);
            else
                maior_seq_pos(j, d_prev) = 0;
            end

            % Razao de escala e medias condicionais
            if abs(min_val) > 1e-14
                razao_escala(j, d_prev) = max(0, max_val) / abs(min_val);
            else
                razao_escala(j, d_prev) = 0;
            end

            if n_pos > 0
                media_pos(j, d_prev) = mean(d2_slice(mask_pos));
            else
                media_pos(j, d_prev) = 0;
            end

            mask_neg = (d2_slice < 0);
            if any(mask_neg)
                media_neg(j, d_prev) = mean(d2_slice(mask_neg));
            else
                media_neg(j, d_prev) = 0;
            end
        end
    end

    total_pontos = numel(D2V);
    total_pos    = sum(D2V(:) > 0);
    pct_total_pos = (total_pos / total_pontos) * 100.0;

    % Diagnostico similar para ramos condicionais v_cond (se disponivel)
    res = struct();
    res.D2V           = D2V;
    res.D2V_raw       = D2V_raw;
    res.a_interior    = a_interior;
    res.max_D2V       = max_D2V;
    res.min_D2V       = min_D2V;
    res.num_pos       = num_pos;
    res.pct_pos       = pct_pos;
    res.maior_seq_pos = maior_seq_pos;
    res.loc_pos       = loc_pos_cell;
    res.razao_escala  = razao_escala;
    res.media_pos     = media_pos;
    res.media_neg     = media_neg;
    res.total_pos     = total_pos;
    res.total_pontos  = total_pontos;
    res.pct_total_pos = pct_total_pos;
    res.max_global    = max(D2V(:));
    res.min_global    = min(D2V(:));
end
