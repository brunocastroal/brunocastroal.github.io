function [tabela_testes, aprovado_geral] = testes_modelo(eq_dc, eq_vfi, comp, res_multigrade)
% TESTES_MODELO Bateria automatizada de 11 testes formais para o modelo com
% Escolhas Ocupacionais e Custos de Transicao (VFI vs DC-EGM).
%
% Testa consistencia microeconomica, convergencia, fechamento de Walras,
% estabilidade das dobras multigrade e concordancia DC-EGM vs VFI.
%
% Sintaxe:
%   [tabela_testes, aprovado_geral] = testes_modelo(eq_dc, eq_vfi, comp, res_multigrade)

    fprintf('========================================================================\n');
    fprintf('   BATERIA FORMAL DE TESTES AUTOMATIZADOS — MODELO VFI vs DC-EGM\n');
    fprintf('========================================================================\n');

    nomes_testes = {
        'Teste 1: Nao-negatividade da distribuicao conjunta (mu >= 0)';
        'Teste 2: Conservacao da massa total de probabilidade (sum mu = 1)';
        'Teste 3: Escolhas ocupacionais deterministicas (P_d in {0, 1})';
        'Teste 4: Positividade estrita do consumo otimo (c > 0)';
        'Teste 5: Satisfacao exata da restricao orcamentaria individual';
        'Teste 6: Limites estritos da grade de ativos [a_min, a_max]';
        'Teste 7: Consistencia da agregacao de trabalho (L_s = L_I + L_F)';
        'Teste 8: Fechamento de mercado e residuo contabil de Walras';
        'Teste 9: Coerencia macroeconomica em EG (DC-EGM vs VFI)';
        'Teste 10: Deteccao e persistencia de dobras no refinamento multigrade';
        'Teste 11: Insensibilidade da distribuicao invariante a condicao inicial'
    };

    num_testes = length(nomes_testes);
    status = false(num_testes, 1);
    detalhes = cell(num_testes, 1);

    sol_dc  = eq_dc.solucao;
    dist_dc = eq_dc.distribuicao;
    mod_dc  = eq_dc.modelo;
    agg_dc  = eq_dc.agregados;

    % Teste 1: Nao-negatividade de mu
    min_mu = min(dist_dc.mu(:));
    if min_mu >= 0.0
        status(1) = true;
        detalhes{1} = sprintf('Aprovado (min(mu) = %.2e >= 0)', min_mu);
    else
        status(1) = false;
        detalhes{1} = sprintf('Falhou (min(mu) = %.2e < 0)', min_mu);
    end

    % Teste 2: Conservacao de massa (sum mu = 1)
    soma_mu = sum(dist_dc.mu(:));
    erro_massa = abs(soma_mu - 1.0);
    if erro_massa < 1e-12
        status(2) = true;
        detalhes{2} = sprintf('Aprovado (sum(mu) = 1.000000, |erro| = %.2e < 1e-12)', erro_massa);
    else
        status(2) = false;
        detalhes{2} = sprintf('Falhou (|erro| = %.2e >= 1e-12)', erro_massa);
    end

    % Teste 3: Escolhas ocupacionais deterministicas (P_d in {0, 1})
    P_vals = sol_dc.P_d(:);
    erro_det = max(min(abs(P_vals - 0.0), abs(P_vals - 1.0)));
    if erro_det < 1e-10
        status(3) = true;
        detalhes{3} = sprintf('Aprovado (P_d puramente deterministico em {0, 1}, erro = %.2e)', erro_det);
    else
        status(3) = false;
        detalhes{3} = sprintf('Falhou (erro determinismo = %.2e)', erro_det);
    end

    % Teste 4: Positividade estrita do consumo otimo e viabilidade economica
    min_c_exp = min(sol_dc.c_exp(:));
    pts_piso = sum(sol_dc.c_d(:) <= 1e-10);
    
    if min_c_exp > 0.05 && pts_piso == mod_dc.Nz
        status(4) = true;
        detalhes{4} = sprintf('Aprovado: c_exp min = %.4f > 0 (viabilidade economica); piso 1e-12 restrito aos %d pontos inviaveis (a=0, d=N, v=-1e12)', ...
            min_c_exp, pts_piso);
    elseif min_c_exp > 0.0
        status(4) = true;
        detalhes{4} = sprintf('Aprovado: c_exp min = %.4f > 0 (viabilidade economica)', min_c_exp);
    else
        status(4) = false;
        detalhes{4} = sprintf('Falhou (c_exp min = %.4f <= 0)', min_c_exp);
    end

    % Teste 5: Restricao orcamentaria individual
    max_viol_orc = sol_dc.max_violacao_orc;
    if max_viol_orc < 1e-10
        status(5) = true;
        detalhes{5} = sprintf('Aprovado (max violacao = %.2e < 1e-10)', max_viol_orc);
    else
        status(5) = false;
        detalhes{5} = sprintf('Falhou (max violacao = %.2e >= 1e-10)', max_viol_orc);
    end

    % Teste 6: Limites da grade de ativos [a_min, a_max]
    min_ap = min(sol_dc.aprime_d(:));
    max_ap = max(sol_dc.aprime_d(:));
    if min_ap >= (mod_dc.a(1) - 1e-12) && max_ap <= (mod_dc.a(end) + 1e-12)
        status(6) = true;
        detalhes{6} = sprintf('Aprovado (min=%.4f >= 0, max=%.4f <= 80)', min_ap, max_ap);
    else
        status(6) = false;
        detalhes{6} = sprintf('Falhou (min=%.4f, max=%.4f fora de [0, 80])', min_ap, max_ap);
    end

    % Teste 7: Agregacao de trabalho
    erro_L = abs(agg_dc.L_s - (agg_dc.L_I + agg_dc.L_F));
    if erro_L < 1e-14 && agg_dc.L_s > 0
        status(7) = true;
        detalhes{7} = sprintf('Aprovado (L_s = %.4f = L_I(%.4f) + L_F(%.4f), erro = %.2e)', ...
            agg_dc.L_s, agg_dc.L_I, agg_dc.L_F, erro_L);
    else
        status(7) = false;
        detalhes{7} = sprintf('Falhou (erro L = %.2e)', erro_L);
    end

    % Teste 8: Fechamento de mercado e Walras em DC-EGM
    erro_k = eq_dc.erro_rel;
    hiato_w = abs(eq_dc.hiato_walras);
    if erro_k < 1e-4 && hiato_w < 1e-4
        status(8) = true;
        detalhes{8} = sprintf('Aprovado (|f(k)|/k = %.2e < 1e-4, |Walras| = %.2e < 1e-4)', ...
            erro_k, hiato_w);
    else
        status(8) = false;
        detalhes{8} = sprintf('Falhou (erro_k = %.2e, Walras = %.2e)', erro_k, hiato_w);
    end

    % Teste 9: Coerencia macroeconomica DC-EGM vs VFI
    dif_rel_k = comp.dif_rel_k;
    dif_rel_Y = comp.dif_rel_Y;
    if dif_rel_k < 0.01 && dif_rel_Y < 0.01
        status(9) = true;
        detalhes{9} = sprintf('Aprovado (Dif k* = %.2e < 1%%, Dif Y* = %.2e < 1%%)', ...
            dif_rel_k, dif_rel_Y);
    else
        status(9) = false;
        detalhes{9} = sprintf('Falhou (Dif k* = %.2e, Y* = %.2e)', dif_rel_k, dif_rel_Y);
    end

    % Teste 10: Deteccao e persistencia de dobras no refinamento multigrade
    dobras_800  = res_multigrade.Na_800.res_endo.total_dobras;
    dobras_1600 = res_multigrade.Na_1600.res_endo.total_dobras;
    if dobras_800 > 0 && dobras_1600 > 0
        status(10) = true;
        detalhes{10} = sprintf('Aprovado (Dobras persistentes confirmadas: %d em Na=800 e %d em Na=1600)', ...
            dobras_800, dobras_1600);
    else
        status(10) = false;
        detalhes{10} = sprintf('Falhou (Dobras: Na=800 -> %d, Na=1600 -> %d)', dobras_800, dobras_1600);
    end

    % Teste 11: Insensibilidade a condicao inicial da distribuicao
    N_states = mod_dc.Na * mod_dc.Nz * 3;
    mu_dirac = zeros(1, N_states);
    idx_cen = round(mod_dc.Na / 2) + (round(mod_dc.Nz / 2) - 1) * mod_dc.Na + (2 - 1) * mod_dc.Na * mod_dc.Nz;
    mu_dirac(idx_cen) = 1.0;

    op_t.tol_dist = 1e-10;
    op_t.max_iter = 25000;
    op_t.mu_init  = mu_dirac;
    dist_dirac = distribuicao_estacionaria(mod_dc, sol_dc, op_t);

    dif_init = max(abs(dist_dc.mu(:) - dist_dirac.mu(:)));
    if dif_init < 1e-8
        status(11) = true;
        detalhes{11} = sprintf('Aprovado (max|mu_unif - mu_dirac| = %.2e < 1e-8)', dif_init);
    else
        status(11) = false;
        detalhes{11} = sprintf('Falhou (dif_init = %.2e >= 1e-8)', dif_init);
    end

    % Relatorio de tela
    for t_idx = 1:num_testes
        if status(t_idx)
            tag = '[APROVADO]';
        else
            tag = '[FALHOU]  ';
        end
        fprintf('%s %-60s : %s\n', tag, nomes_testes{t_idx}, detalhes{t_idx});
    end
    fprintf('========================================================================\n');

    aprovado_geral = all(status);
    if aprovado_geral
        fprintf('  STATUS FINAL: TODOS OS %d TESTES FORAM PLENAMENTE APROVADOS!\n', num_testes);
    else
        fprintf('  STATUS FINAL: ATENCAO — ALGUNS TESTES NAO FORAM APROVADOS!\n');
    end
    fprintf('========================================================================\n\n');

    tabela_testes = table(nomes_testes, status, detalhes, ...
        'VariableNames', {'Teste', 'Status', 'Detalhes'});
end
