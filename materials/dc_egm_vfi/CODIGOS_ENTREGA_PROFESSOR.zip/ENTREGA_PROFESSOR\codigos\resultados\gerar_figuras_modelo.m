function gerar_figuras_modelo(eq_dc, eq_vfi, comp, res_multigrade, pasta_figuras)
% GERAR_FIGURAS_MODELO Gera as 10 figuras academicas de alta resolucao (300 DPI)
% com fundo branco explicito, texto preto e alto contraste para a publicacao
% final do projeto:
% "Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
%  Uma Comparacao entre VFI e DC-EGM"
%
% Sintaxe:
%   gerar_figuras_modelo()
%   gerar_figuras_modelo(eq_dc, eq_vfi, comp, res_multigrade, pasta_figuras)

    pasta_atual = fileparts(mfilename('fullpath'));
    if isempty(pasta_atual), pasta_atual = pwd; end
    pasta_raiz = pasta_atual;
    for k_up = 1:5
        if isfolder(fullfile(pasta_raiz, 'resultados')) && isfolder(fullfile(pasta_raiz, 'parametros'))
            break;
        end
        pasta_pai = fileparts(pasta_raiz);
        if strcmp(pasta_pai, pasta_raiz), break; end
        pasta_raiz = pasta_pai;
    end

    if nargin < 5 || isempty(pasta_figuras)
        pasta_figuras = fullfile(pasta_raiz, 'figuras');
    end
    if ~exist(pasta_figuras, 'dir')
        mkdir(pasta_figuras);
    end

    if nargin < 4 || isempty(eq_dc) || isempty(res_multigrade)
        arq_final = fullfile(pasta_raiz, 'resultados', 'resultados_modelo_final.mat');
        arq_indiv = fullfile(pasta_raiz, 'resultados', 'resultados_solucao_individual.mat');
        d_fin = load(arq_final);
        d_ind = load(arq_indiv);

        eq_dc   = d_fin.eq_dc;
        eq_vfi  = d_fin.eq_vfi;
        comp    = d_fin.comp;
        if isfield(d_fin, 'res_multigrade')
            res_multigrade = d_fin.res_multigrade;
        elseif isfield(d_ind, 'resultados_fase1')
            res_multigrade = d_ind.resultados_fase1;
        end
    end

    % Paleta de cores com alto contraste
    azul_escuro   = [0.00, 0.25, 0.60];
    vermelho_vivo = [0.85, 0.15, 0.10];
    verde_escuro  = [0.10, 0.55, 0.20];
    roxo_escuro   = [0.45, 0.10, 0.60];
    cinza_escuro  = [0.20, 0.20, 0.20];
    laranja_vivo  = [0.90, 0.50, 0.00];

    a = eq_dc.modelo.a;
    idx_zoom = a <= 30;
    j_med = 3;

    % =========================================================================
    % FIGURA 1: FUNCOES VALOR CONDICIONAIS E ENVELOPE SUPERIOR (EG, Na = 400)
    % =========================================================================
    f1 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1200, 420]);

    titulos_p = {
        'Origem Inativo (d^- = N)', ...
        'Origem Informal (d^- = I)', ...
        'Origem Formal (d^- = F)'
    };
    % Usar z_2 = 0.5694 onde o cruzamento entre escolhas ocupacionais e evidente
    j_sel = 2;
    idx_zoom1 = (a <= 15);

    for d_prev = 1:3
        subplot(1, 3, d_prev);
        set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
        hold on; box on; grid on;

        v_N = eq_dc.solucao.v_cond(idx_zoom1, j_sel, 1, d_prev);
        v_I = eq_dc.solucao.v_cond(idx_zoom1, j_sel, 2, d_prev);
        v_F = eq_dc.solucao.v_cond(idx_zoom1, j_sel, 3, d_prev);
        V_env = eq_dc.solucao.V(idx_zoom1, j_sel, d_prev);

        % Filtrar ponto inviavel v_N(a=0) = -1e12 para evitar distorcao da escala vertical
        v_N(v_N < -50) = NaN;

        hN = plot(a(idx_zoom1), v_N, ':',  'LineWidth', 1.8, 'Color', cinza_escuro,  'DisplayName', 'v_N (Inativo)');
        hI = plot(a(idx_zoom1), v_I, '--', 'LineWidth', 2.0, 'Color', laranja_vivo,  'DisplayName', 'v_I (Informal)');
        hF = plot(a(idx_zoom1), v_F, '-.', 'LineWidth', 2.0, 'Color', azul_escuro,   'DisplayName', 'v_F (Formal)');
        hE = plot(a(idx_zoom1), V_env,     'LineWidth', 2.4, 'Color', verde_escuro,  'DisplayName', 'Envelope V = max_d v_d');

        xlabel('Ativos Financeiros Correntes (a)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
        ylabel('Valor Condicional v_d(a) e V(a)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
        title(sprintf('%s (EG, z_2=%.3f)', titulos_p{d_prev}, eq_dc.modelo.z(j_sel)), ...
            'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
        xlim([0, 15]);

        vals_validos = [v_I; v_F; v_N(~isnan(v_N))];
        y_min = min(vals_validos) - 0.5;
        y_max = max(V_env) + 0.5;
        ylim([y_min, y_max]);

        if d_prev == 1
            legend([hN, hI, hF, hE], 'Location', 'southeast', 'FontSize', 9, 'TextColor', 'k', 'Color', 'w');
        end
    end
    salvar_figura(f1, fullfile(pasta_figuras, 'figura1_funcoes_valor_envelope.png'));

    % =========================================================================
    % FIGURA 2: REGIOES DE CONVEXIDADE LOCAL DA FUNCAO VALOR (EP, Na = 400)
    % =========================================================================
    f2 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 950, 520]);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    rV = res_multigrade.Na_400.res_V;
    a_int = rV.a_interior;
    idx_int_zoom = a_int <= 25;
    cores_z = [cinza_escuro; azul_escuro; verde_escuro; laranja_vivo; vermelho_vivo];

    for j = 1:5
        plot(a_int(idx_int_zoom), rV.D2V(idx_int_zoom, j, 2), 'LineWidth', 2.0, ...
            'Color', cores_z(j, :), 'DisplayName', sprintf('Choque z_%d = %.3f', j, eq_dc.modelo.z(j)));
    end
    yline(0, 'r--', 'LineWidth', 1.3, 'DisplayName', 'Fronteira de Concavidade (V_{aa} = 0)');

    xlabel('Ativos Financeiros (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Segunda Diferenca V_{aa} = \Delta^2 V / \Delta a^2', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Regioes de Convexidade Local da Funcao Valor: V_{aa}(a, z, d^-=I) em EP (N_a = 400)', ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'southeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 25]); ylim([-0.25, 0.08]);

    salvar_figura(f2, fullfile(pasta_figuras, 'figura2_convexidade_local.png'));

    % =========================================================================
    % FIGURA 3: MONOTONICIDADE E DOBRAS NAS GRADES ENDOGENAS (EP vs EG)
    % =========================================================================
    f3 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1400, 480]);

    % Subplot 1: EP Na = 800 (2 dobras)
    subplot(1, 3, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    m800 = res_multigrade.Na_800.modelo;
    rE800 = res_multigrade.Na_800.res_endo;
    a_mid_800 = m800.a(1:end-1);
    idx_m800 = a_mid_800 >= 50 & a_mid_800 <= 80;

    plot(a_mid_800(idx_m800), rE800.da_endo_tensor(idx_m800, 2, 2), 'LineWidth', 1.8, 'Color', laranja_vivo, ...
        'DisplayName', 'Informal (d=2, z_2)');
    plot(a_mid_800(idx_m800), rE800.da_endo_tensor(idx_m800, 3, 3), 'LineWidth', 2.0, 'Color', azul_escuro, ...
        'DisplayName', 'Formal (d=3, z_3)');
    yline(0, 'r--', 'LineWidth', 1.4, 'DisplayName', 'Dobra (\Delta a_{endo} < 0)');
    plot(74.39, -0.0139, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'DisplayName', 'Dobra Interior (a''=74.4)');
    plot(79.80, -0.0571, 'rs', 'MarkerSize', 8, 'MarkerFaceColor', 'm', 'DisplayName', 'Dobra Borda (a''=79.8)');

    xlabel('Ativos Futuros a''', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('\Delta a_{endo} (Incremento)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'[EP] N_a = 800 (\Delta a = 0.100)', '2 Dobras Detectadas'}, 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8, 'TextColor', 'k', 'Color', 'w');
    xlim([50, 80]); ylim([-0.08, 0.18]);

    % Subplot 2: EP Na = 1600 (4 dobras persistentes)
    subplot(1, 3, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    m1600 = res_multigrade.Na_1600.modelo;
    rE1600 = res_multigrade.Na_1600.res_endo;
    a_mid_1600 = m1600.a(1:end-1);
    idx_m1600 = a_mid_1600 >= 50 & a_mid_1600 <= 80;

    plot(a_mid_1600(idx_m1600), rE1600.da_endo_tensor(idx_m1600, 1, 2), 'LineWidth', 1.6, 'Color', cinza_escuro, ...
        'DisplayName', 'Informal (d=2, z_1)');
    plot(a_mid_1600(idx_m1600), rE1600.da_endo_tensor(idx_m1600, 2, 2), 'LineWidth', 1.8, 'Color', laranja_vivo, ...
        'DisplayName', 'Informal (d=2, z_2)');
    plot(a_mid_1600(idx_m1600), rE1600.da_endo_tensor(idx_m1600, 2, 3), '-.', 'LineWidth', 1.8, 'Color', roxo_escuro, ...
        'DisplayName', 'Formal (d=3, z_2)');
    plot(a_mid_1600(idx_m1600), rE1600.da_endo_tensor(idx_m1600, 3, 3), 'LineWidth', 2.0, 'Color', azul_escuro, ...
        'DisplayName', 'Formal (d=3, z_3)');
    yline(0, 'r--', 'LineWidth', 1.4, 'DisplayName', 'Zero');
    plot([60.49, 74.40, 64.49], [-0.0424, -0.0626, -0.0180], 'ro', 'MarkerSize', 7, 'MarkerFaceColor', 'r', ...
        'DisplayName', '3 Dobras Interiores');
    plot(79.80, -0.1081, 'rs', 'MarkerSize', 7, 'MarkerFaceColor', 'm', 'DisplayName', '1 Dobra Borda');

    xlabel('Ativos Futuros a''', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('\Delta a_{endo} (Incremento)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'[EP] N_a = 1600 (\Delta a = 0.050)', '4 Dobras (3 Interiores + 1 Borda)'}, ...
        'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8, 'TextColor', 'k', 'Color', 'w');
    xlim([50, 80]); ylim([-0.12, 0.12]);

    % Subplot 3: EG Na = 400 (Grau estritamente monotonico)
    subplot(1, 3, 3);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    diag_eg = diagnostico_grades_endogenas(eq_dc.modelo, eq_dc.solucao);
    a_mid_eg = eq_dc.modelo.a(1:end-1);
    idx_eg = a_mid_eg >= 50 & a_mid_eg <= 80;

    plot(a_mid_eg(idx_eg), diag_eg.da_endo_tensor(idx_eg, j_med, 1), ':', 'LineWidth', 1.8, 'Color', cinza_escuro, ...
        'DisplayName', sprintf('Inativo (min = +%.3f)', min(diag_eg.min_inc(:, 1))));
    plot(a_mid_eg(idx_eg), diag_eg.da_endo_tensor(idx_eg, j_med, 2), '--', 'LineWidth', 1.8, 'Color', laranja_vivo, ...
        'DisplayName', sprintf('Informal (min = +%.3f)', min(diag_eg.min_inc(:, 2))));
    plot(a_mid_eg(idx_eg), diag_eg.da_endo_tensor(idx_eg, j_med, 3), 'LineWidth', 2.0, 'Color', azul_escuro, ...
        'DisplayName', sprintf('Formal (min = +%.3f)', min(diag_eg.min_inc(:, 3))));
    yline(0, 'r--', 'LineWidth', 1.4, 'DisplayName', 'Zero (Dobra)');

    xlabel('Ativos Futuros a''', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('\Delta a_{endo} (Incremento)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'[EG] N_a = 400 (r^* = 2.80%)', '0 Dobras: Estritamente Monotonica'}, ...
        'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8, 'TextColor', 'k', 'Color', 'w');
    xlim([50, 80]); ylim([-0.05, 0.40]);

    salvar_figura(f3, fullfile(pasta_figuras, 'figura3_grades_endogenas.png'));

    % =========================================================================
    % FIGURA 4: COMPARACAO ENTRE VFI E DC-EGM EM EQUILIBRIO GERAL (Na = 400)
    % =========================================================================
    f4 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1100, 480]);

    % Subplot 1: Funcao Valor
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    plot(a(idx_zoom), eq_dc.solucao.V(idx_zoom, j_med, 2), 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'DisplayName', 'DC-EGM com Upper Envelope');
    plot(a(idx_zoom), eq_vfi.solucao.V(idx_zoom, j_med, 2), '--', 'LineWidth', 2.0, 'Color', vermelho_vivo, ...
        'DisplayName', 'VFI Vetorizada (Referencia)');

    xlabel('Ativos Financeiros Correntes (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Funcao Valor V(a, z_3, d^-=I)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Concordancia de Funcao Valor em EG (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'southeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 25]);

    % Subplot 2: Politica de Poupanca
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    plot(a(idx_zoom), eq_dc.solucao.aprime_exp(idx_zoom, j_med, 2), 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'DisplayName', 'DC-EGM a''(a)');
    plot(a(idx_zoom), eq_vfi.solucao.aprime_exp(idx_zoom, j_med, 2), '--', 'LineWidth', 2.0, 'Color', vermelho_vivo, ...
        'DisplayName', 'VFI a''(a)');
    plot(a(idx_zoom), a(idx_zoom), 'k:', 'LineWidth', 1.2, 'DisplayName', 'Linha 45^o (a'' = a)');

    xlabel('Ativos Financeiros Correntes (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Poupanca Otima a''(a, z_3, d^-=I)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Concordancia da Politica de Poupanca em EG (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 25]); ylim([0, 25]);

    salvar_figura(f4, fullfile(pasta_figuras, 'figura4_comparacao_vfi_dcegm.png'));

    % =========================================================================
    % FIGURA 5: POLITICAS DE POUPANCA POR OCUPACAO EM EQUILIBRIO GERAL (Na = 400)
    % =========================================================================
    f5 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 900, 520]);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    plot(a(idx_zoom), a(idx_zoom), 'k:', 'LineWidth', 1.5, 'DisplayName', 'Linha 45^o (a'' = a)');
    plot(a(idx_zoom), eq_dc.solucao.aprime_d(idx_zoom, j_med, 1), 'LineWidth', 2.2, 'Color', cinza_escuro, ...
        'DisplayName', 'Inativo (N): y = 0');
    plot(a(idx_zoom), eq_dc.solucao.aprime_d(idx_zoom, j_med, 2), 'LineWidth', 2.2, 'Color', laranja_vivo, ...
        'DisplayName', sprintf('Informal (I): y = \\kappa wz (\\kappa=0.72)'));
    plot(a(idx_zoom), eq_dc.solucao.aprime_d(idx_zoom, j_med, 3), 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'DisplayName', sprintf('Formal (F): y = (1-\\tau)wz (\\tau=0.20)'));

    xlabel('Ativos Correntes (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Ativos Futuros Escolhidos a''_d(a, z_3)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title(sprintf('Politicas Condicionais de Poupanca em EG (N_a = 400, z_3 = %.3f, w^* = %.4f)', ...
        eq_dc.modelo.z(j_med), eq_dc.w), 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 25]); ylim([0, 25]);

    salvar_figura(f5, fullfile(pasta_figuras, 'figura5_politicas_poupanca.png'));

    % =========================================================================
    % FIGURA 6: DISTRIBUICAO ESTACIONARIA DE ATIVOS EM EG (Na = 400)
    % =========================================================================
    f6 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1100, 480]);

    % Subplot 1: Densidade
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    plot(a(idx_zoom), eq_dc.distribuicao.mu_a(idx_zoom), 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'DisplayName', sprintf('DC-EGM (K = %.2f, Gini = %.3f)', eq_dc.K, eq_dc.gini));
    plot(a(idx_zoom), eq_vfi.distribuicao.mu_a(idx_zoom), '--', 'LineWidth', 2.0, 'Color', vermelho_vivo, ...
        'DisplayName', sprintf('VFI (K = %.2f, Gini = %.3f)', eq_vfi.K, eq_vfi.gini));

    xlabel('Ativos Financeiros (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Massa de Probabilidade \mu_a(a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Densidade Marginal de Riqueza em EG (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 30]);

    % Subplot 2: CDF
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    plot(a(idx_zoom), cumsum(eq_dc.distribuicao.mu_a(idx_zoom)), 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'DisplayName', 'CDF DC-EGM');
    plot(a(idx_zoom), cumsum(eq_vfi.distribuicao.mu_a(idx_zoom)), '--', 'LineWidth', 2.0, 'Color', vermelho_vivo, ...
        'DisplayName', 'CDF VFI');
    yline(0.50, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Mediana P50');
    yline(0.90, 'k-.', 'LineWidth', 1.2, 'DisplayName', 'Percentil P90');

    xlabel('Ativos Financeiros (a)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Probabilidade Acumulada', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Distribuicao Acumulada (CDF) em EG (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'southeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    xlim([0, 30]); ylim([0, 1.02]);

    salvar_figura(f6, fullfile(pasta_figuras, 'figura6_distribuicao_estacionaria.png'));

    % =========================================================================
    % FIGURA 7: COMPOSICAO OCUPACIONAL (EP vs EG, Na = 400)
    % =========================================================================
    f7 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1150, 480]);

    % Painel A: Equilibrio Parcial (Precos Exogenos)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    dados_ep = [9.4, 87.0, 3.6];
    cores_ep = [cinza_escuro; laranja_vivo; azul_escuro];

    b1 = bar(1:3, dados_ep, 0.55, 'FaceColor', 'flat');
    for k = 1:3
        b1.CData(k, :) = cores_ep(k, :);
    end
    b1.EdgeColor = 'k';
    b1.LineWidth = 1.0;

    set(gca, 'XTick', 1:3, 'XTickLabel', {'Inativos (N)', 'Informais (I)', 'Formais (F)'}, ...
        'FontSize', 10, 'FontWeight', 'bold');
    ylabel('Participacao Ocupacional (%)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'Painel A: Equilibrio Parcial (Precos Exogenos)', ...
           'r = 4.1667%, w = 1.1781 | Domina Informalidade'}, ...
           'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylim([0, 105]);

    for k = 1:3
        val = dados_ep(k);
        text(k, val + 2.5, sprintf('%.1f%%', val), ...
            'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    end

    % Painel B: Equilibrio Geral Estacionario (Precos Endogenos)
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    dados_eg = [
        eq_dc.M_N * 100,  eq_vfi.M_N * 100;
        eq_dc.M_I * 100,  eq_vfi.M_I * 100;
        eq_dc.M_F * 100,  eq_vfi.M_F * 100
    ];

    b2 = bar(1:3, dados_eg, 0.65, 'grouped');
    b2(1).FaceColor = azul_escuro;   b2(1).EdgeColor = 'k'; b2(1).LineWidth = 1.0;
    b2(2).FaceColor = verde_escuro;  b2(2).EdgeColor = 'k'; b2(2).LineWidth = 1.0;

    set(gca, 'XTick', 1:3, 'XTickLabel', {'Inativos (N)', 'Informais (I)', 'Formais (F)'}, ...
        'FontSize', 10, 'FontWeight', 'bold');
    ylabel('Participacao Ocupacional (%)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'Painel B: Equilibrio Geral Estacionario (Precos Endogenos)', ...
           'r* = 2.80%, w* = 1.2600 | Domina Formalidade'}, ...
           'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend({'DC-EGM com Envelope', 'VFI Vetorizada'}, 'Location', 'northwest', ...
        'FontSize', 10, 'TextColor', 'k', 'Color', 'w');
    ylim([0, 115]);

    for cat = 1:3
        for met = 1:2
            val = dados_eg(cat, met);
            x_pos = b2(met).XEndPoints(cat);
            if val > 0.5
                text(x_pos, val + 2.5, sprintf('%.1f%%', val), ...
                    'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold', 'Color', 'k');
            else
                text(x_pos, val + 2.5, sprintf('%.1f%%', val), ...
                    'HorizontalAlignment', 'center', 'FontSize', 9, 'Color', [0.4, 0.4, 0.4]);
            end
        end
    end

    salvar_figura(f7, fullfile(pasta_figuras, 'figura7_composicao_ocupacional.png'));

    % =========================================================================
    % FIGURA 8: EQUILIBRIO ENTRE OFERTA E DEMANDA DE CAPITAL (EG, Na = 400)
    % =========================================================================
    f8 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 900, 530]);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    hist_dc = eq_dc.historico;
    [r_sort, sort_idx] = sort(hist_dc.r * 100);
    Ks_sort = hist_dc.Ks(sort_idx);

    r_grid_pct = linspace(min(hist_dc.r)*100 * 0.9, max(hist_dc.r)*100 * 1.1, 100);
    r_grid = r_grid_pct / 100;
    Kd_grid = eq_dc.L * ((r_grid + eq_dc.modelo.params.delta) / ...
        (eq_dc.modelo.params.alpha * eq_dc.modelo.params.A)).^(1.0 / (eq_dc.modelo.params.alpha - 1.0));

    plot(Ks_sort, r_sort, 'o-', 'LineWidth', 2.2, 'Color', azul_escuro, 'MarkerFaceColor', azul_escuro, ...
        'DisplayName', 'Oferta Agregada das Familias K_s(r) (Iteracoes DC-EGM)');
    plot(Kd_grid, r_grid_pct, '--', 'LineWidth', 2.2, 'Color', vermelho_vivo, ...
        'DisplayName', sprintf('Demanda da Firma Competitiva K_d(r) (L^* = %.4f)', eq_dc.L));
    plot(eq_dc.K, eq_dc.r * 100, 'p', 'MarkerSize', 14, 'MarkerFaceColor', verde_escuro, ...
        'MarkerEdgeColor', 'k', 'DisplayName', sprintf('Equilibrio de Mercado: K^* = %.3f, r^* = %.3f%%', eq_dc.K, eq_dc.r * 100));

    xlabel('Estoque Agregado de Capital (K)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Taxa de Juros Real r (%)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Equilibrio entre Oferta e Demanda de Capital em EG (N_a = 400)', ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');

    salvar_figura(f8, fullfile(pasta_figuras, 'figura8_oferta_demanda_capital.png'));

    % =========================================================================
    % FIGURA 9: CONVERGENCIA DO EQUILIBRIO GERAL (EG, Na = 400)
    % =========================================================================
    f9 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 1100, 480]);

    % Subplot 1: Trajetoria de k e f(k)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    [k_s, sk] = sort(hist_dc.k);
    fk_s = hist_dc.fk(sk);

    plot(k_s, fk_s, 'o-', 'LineWidth', 2.0, 'Color', azul_escuro, 'MarkerFaceColor', azul_escuro, ...
        'DisplayName', 'DC-EGM f(k) = K_s/L_s - k');
    yline(0, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Zero (Equilibrio)');
    plot(eq_dc.k, eq_dc.f_k, 'p', 'MarkerSize', 12, 'MarkerFaceColor', verde_escuro, ...
        'MarkerEdgeColor', 'k', 'DisplayName', sprintf('k^* = %.4f', eq_dc.k));

    xlabel('Razao Capital-Trabalho (k)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Funcao de Excesso f(k)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Funcao de Excesso de Oferta f(k) (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');

    % Subplot 2: Erro Relativo ao Longo das Iteracoes
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    semilogy(1:length(hist_dc.erro_rel), hist_dc.erro_rel, 'o-', 'LineWidth', 2.2, 'Color', azul_escuro, ...
        'MarkerFaceColor', azul_escuro, 'DisplayName', 'DC-EGM |f(k)|/k');
    yline(1e-4, 'r:', 'LineWidth', 1.4, 'DisplayName', 'Tolerancia de Mercado 10^{-4}');

    xlabel('Iteracao da Bisseccao', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Erro Relativo de Mercado |f(k)|/k', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    title('Convergencia da Bisseccao: 11 Iteracoes (N_a = 400)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 10, 'TextColor', 'k', 'Color', 'w');

    salvar_figura(f9, fullfile(pasta_figuras, 'figura9_convergencia_equilibrio.png'));

    % =========================================================================
    % FIGURA 10: DESEMPENHO COMPUTACIONAL DOS METODOS (EP MULTIGRADE)
    % =========================================================================
    f10 = figure('Visible', 'off', 'Color', 'w', 'Position', [100, 100, 960, 560]);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 11, 'LineWidth', 1.0);
    hold on; box on; grid on;

    na_rotulos = {'400', '800', '1600'};
    t_vfi_vec = [res_multigrade.Na_400.tempo_vfi, res_multigrade.Na_800.tempo_vfi, res_multigrade.Na_1600.tempo_vfi];
    t_dc_vec  = [res_multigrade.Na_400.tempo_dc,  res_multigrade.Na_800.tempo_dc,  res_multigrade.Na_1600.tempo_dc];

    b10 = bar(1:3, [t_dc_vec; t_vfi_vec]', 'grouped');
    b10(1).FaceColor = azul_escuro;   b10(1).EdgeColor = 'k';
    b10(2).FaceColor = vermelho_vivo; b10(2).EdgeColor = 'k';

    xticks(1:3);
    xticklabels(na_rotulos);
    xlim([0.5 3.5]);
    set(gca, 'FontSize', 11, 'FontWeight', 'bold');
    ylabel('Tempo de Execucao (segundos)', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    xlabel({'Pontos na Grade de Ativos (N_a)', ...
            '* Nota: Em N_a = 400, DC-EGM atingiu 1500 it. (tol = 10^{-7}); em N_a = 800 e 1600, convergiu em 376 it.'}, ...
        'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    title({'Desempenho Computacional em Equilibrio Parcial: DC-EGM vs VFI (\chi = 0.05)', ...
           'Refinamento Multigrade Canonico: N_a \in {400, 800, 1600}'}, ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');
    legend({'DC-EGM com Upper Envelope', 'VFI Vetorizada'}, 'Location', 'northwest', ...
        'FontSize', 11, 'TextColor', 'k', 'Color', 'w');

    % Rotulos precisos de speedup consistentes com a tabela arredondada (3 casas)
    speedups = round(t_vfi_vec, 3) ./ round(t_dc_vec, 3);
    text(1, max(t_vfi_vec(1), t_dc_vec(1)) + 2.0, ...
        sprintf('%.2fx (DC 1500 it.*)', speedups(1)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    text(2, max(t_vfi_vec(2), t_dc_vec(2)) + 2.0, ...
        sprintf('Speedup: %.2fx', speedups(2)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    text(3, max(t_vfi_vec(3), t_dc_vec(3)) + 2.0, ...
        sprintf('Speedup: %.2fx', speedups(3)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    ylim([0, max([t_vfi_vec, t_dc_vec]) * 1.25]);

    salvar_figura(f10, fullfile(pasta_figuras, 'figura10_desempenho_computacional.png'));

    fprintf('Todas as 10 figuras do projeto foram geradas com sucesso em:\n  %s\n', pasta_figuras);
end


function salvar_figura(fig_handle, caminho_arquivo)
    [pasta, nome, ~] = fileparts(caminho_arquivo);

    % 1. PNG em 300 DPI na pasta local (figuras/)
    arq_png = fullfile(pasta, [nome, '.png']);
    if exist(arq_png, 'file')
        try, delete(arq_png); catch, pause(0.2); try, delete(arq_png); catch, end, end
    end
    exportgraphics(fig_handle, arq_png, 'Resolution', 300);

    % 2. Exportacoes estruturadas
    pasta_raiz = fileparts(pasta);
    locais_pdf = {fullfile(pasta, 'PDF')};
    locais_png = {fullfile(pasta, 'PNG')};
    locais_fig = {fullfile(pasta, 'FIG')};

    pasta_ff = fullfile(pasta_raiz, '..', 'FIGURAS_FINAL');
    if exist(pasta_ff, 'dir')
        locais_pdf{end+1} = fullfile(pasta_ff, 'PDF');
        locais_png{end+1} = fullfile(pasta_ff, 'PNG');
        locais_fig{end+1} = fullfile(pasta_ff, 'FIG');
    end

    for i = 1:length(locais_pdf)
        p_pdf = locais_pdf{i};
        p_png = locais_png{i};
        p_fig = locais_fig{i};
        if ~exist(p_pdf, 'dir'), mkdir(p_pdf); end
        if ~exist(p_png, 'dir'), mkdir(p_png); end
        if ~exist(p_fig, 'dir'), mkdir(p_fig); end

        arq_pdf = fullfile(p_pdf, [nome, '.pdf']);
        if exist(arq_pdf, 'file'), try, delete(arq_pdf); catch, end, end
        exportgraphics(fig_handle, arq_pdf, 'ContentType', 'vector');

        arq_png_dest = fullfile(p_png, [nome, '.png']);
        if exist(arq_png_dest, 'file'), try, delete(arq_png_dest); catch, end, end
        copyfile(arq_png, arq_png_dest);

        arq_fig = fullfile(p_fig, [nome, '.fig']);
        if exist(arq_fig, 'file'), try, delete(arq_fig); catch, end, end
        savefig(fig_handle, arq_fig);
    end

    close(fig_handle);
end
