function [pol_c, pol_aprime, v_cond, teve_dobra, diag_ramo] = dc_egm_ramo_condicional(...
    a_grid, W_d_z, Wprime_d_z, y_dz, psi_d, R, sigma, kinks_cand)
% DC_EGM_RAMO_CONDICIONAL Resolve o ramo condicional continuo (d, z) via EGM com Upper Envelope.
%
% Trata explicitamente os tres regimes:
%   1) Canto inferior: a' = a_min (restricao de credito)
%   2) Solucao interior: a_min < a' < a_max (inversao da equacao de Euler)
%   3) Canto superior: a' = a_max (restricao de riqueza maxima)
%
% Permite integracao opcional de candidatos de kink ocupacional:
%   Se kinks_cand for fornecido, avalia a funcao valor nos pontos de quebra
%   e atualiza a solucao caso algum candidato supere o valor obtido via EGM.
%
% Satisfaz estritamente a restricao orcamentaria em todos os estados:
%   c + a' = R * a + y_dz  (|c + a' - (R*a + y_dz)| < 1e-12)
%
% Avalia a funcao valor de forma consistente com a politica:
%   v_d(a, z) = u(c) - psi_d + W_d(a', z)

    Na = length(a_grid);
    a_min = a_grid(1);
    a_max = a_grid(end);

    % 1. Inversao da Condicao de Euler para obter consumo endogeno:
    % u'(c) = W'_{d, a'} => c = (W')^(-1/sigma)
    Wprime_pos = max(Wprime_d_z, 1e-14);
    if abs(sigma - 1.0) < 1e-6
        c_endo = 1.0 ./ Wprime_pos;
    else
        c_endo = Wprime_pos.^(-1.0 / sigma);
    end

    % 2. Grade de Ativos Endogena via Restricao Orcamentaria:
    % c + a' = R*a + y => a_endo = (c + a' - y) / R
    a_endo = (c_endo + a_grid - y_dz) / R;

    % 3. Deteccao de Nao-Monotonicidade (Dobras na Grade Endogena)
    da_endo = diff(a_endo);
    teve_dobra = any(da_endo < -1e-8);

    % 4. Pre-alocacao
    pol_c      = zeros(Na, 1);
    pol_aprime = zeros(Na, 1);
    v_cond     = zeros(Na, 1);

    if ~teve_dobra
        % =====================================================================
        % CASO 1: Grade Endogena Monotonica (Sem Dobras)
        % =====================================================================
        a_min_endo = a_endo(1);
        a_max_endo = a_endo(end);

        mask_canto_inf = (a_grid <= a_min_endo);
        mask_canto_sup = (a_grid >= a_max_endo);
        mask_int       = (~mask_canto_inf) & (~mask_canto_sup);

        % 1. Canto Inferior: Restricao de Credito Ativa (a' = a_min = 0)
        % Kuhn-Tucker: u'(c) >= W'_{d, a'}(a_min, z)
        if any(mask_canto_inf)
            c_inf = max(1e-12, R * a_grid(mask_canto_inf) + y_dz - a_min);
            pol_c(mask_canto_inf)      = c_inf;
            pol_aprime(mask_canto_inf) = a_min;
            v_cond(mask_canto_inf)     = utilidade_crra(c_inf, sigma) - psi_d + W_d_z(1);
        end

        % 2. Canto Superior: Restricao Superior Ativa (a' = a_max)
        % Kuhn-Tucker: u'(c) <= W'_{d, a'}(a_max, z)
        if any(mask_canto_sup)
            c_sup = max(1e-12, R * a_grid(mask_canto_sup) + y_dz - a_max);
            pol_c(mask_canto_sup)      = c_sup;
            pol_aprime(mask_canto_sup) = a_max;
            v_cond(mask_canto_sup)     = utilidade_crra(c_sup, sigma) - psi_d + W_d_z(end);
        end

        % 3. Solucao Interior: a_min_endo < a < a_max_endo
        if any(mask_int)
            c_int = interp1(a_endo, c_endo, a_grid(mask_int), 'linear');
            c_int = max(1e-12, c_int);
            ap_int = R * a_grid(mask_int) + y_dz - c_int;
            
            % Garantir limites numericos exatos
            ap_int = max(a_min, min(a_max, ap_int));
            c_int  = R * a_grid(mask_int) + y_dz - ap_int;

            pol_c(mask_int)      = c_int;
            pol_aprime(mask_int) = ap_int;

            % Avaliacao consistente da funcao valor: u(c) - psi + W(a')
            W_int = interp1(a_grid, W_d_z, ap_int, 'linear');
            v_cond(mask_int)     = utilidade_crra(c_int, sigma) - psi_d + W_int;
        end
    else
        % =====================================================================
        % CASO 2: Grade Endogena com Dobras (Upper Envelope)
        % =====================================================================
        ramos = identificar_ramos_monotonicos(a_endo, c_endo, a_grid);
        num_ramos = length(ramos);

        v_candidatos  = -Inf(Na, num_ramos);
        c_candidatos  = zeros(Na, num_ramos);
        ap_candidatos = zeros(Na, num_ramos);

        for r = 1:num_ramos
            ramo = ramos{r};
            mask_valida = (a_grid >= ramo.a_min) & (a_grid <= ramo.a_max);
            if any(mask_valida)
                c_interp = interp1(ramo.a, ramo.c, a_grid(mask_valida), 'linear');
                c_interp = max(1e-12, c_interp);
                ap_interp = R * a_grid(mask_valida) + y_dz - c_interp;
                ap_interp = max(a_min, min(a_max, ap_interp));
                c_interp  = R * a_grid(mask_valida) + y_dz - ap_interp;

                W_val = interp1(a_grid, W_d_z, ap_interp, 'linear');
                v_interp = utilidade_crra(c_interp, sigma) - psi_d + W_val;

                c_candidatos(mask_valida, r)  = c_interp;
                ap_candidatos(mask_valida, r) = ap_interp;
                v_candidatos(mask_valida, r)  = v_interp;
            end
        end

        % Candidatos de cantos exatos
        c_canto_inf = max(1e-12, R * a_grid + y_dz - a_min);
        v_canto_inf = utilidade_crra(c_canto_inf, sigma) - psi_d + W_d_z(1);

        c_canto_sup = max(1e-12, R * a_grid + y_dz - a_max);
        v_canto_sup = utilidade_crra(c_canto_sup, sigma) - psi_d + W_d_z(end);

        a_canto_inf_lim = a_endo(1);
        a_canto_sup_lim = a_endo(end);

        for i = 1:Na
            ai = a_grid(i);
            [max_v_inter, idx_r] = max(v_candidatos(i, :));

            % Comparar com cantos
            if ai <= a_canto_inf_lim || isinf(max_v_inter) || v_canto_inf(i) >= max_v_inter
                if v_canto_sup(i) > v_canto_inf(i) && ai >= a_canto_sup_lim
                    pol_c(i)      = c_canto_sup(i);
                    pol_aprime(i) = a_max;
                    v_cond(i)     = v_canto_sup(i);
                else
                    pol_c(i)      = c_canto_inf(i);
                    pol_aprime(i) = a_min;
                    v_cond(i)     = v_canto_inf(i);
                end
            elseif ai >= a_canto_sup_lim && v_canto_sup(i) >= max_v_inter
                pol_c(i)      = c_canto_sup(i);
                pol_aprime(i) = a_max;
                v_cond(i)     = v_canto_sup(i);
            else
                pol_c(i)      = c_candidatos(i, idx_r);
                pol_aprime(i) = ap_candidatos(i, idx_r);
                v_cond(i)     = max_v_inter;
            end
        end
    end

    % 5. Integracao de Candidatos de Kink (se fornecidos)
    melhorias_kink = 0;
    if nargin >= 8 && ~isempty(kinks_cand)
        kinks_validos = kinks_cand(kinks_cand >= a_min & kinks_cand <= a_max);
        if ~isempty(kinks_validos)
            W_kinks = interp1(a_grid, W_d_z, kinks_validos, 'linear');
            for i = 1:Na
                ai = a_grid(i);
                recurso = R * ai + y_dz;
                c_k_vec = recurso - kinks_validos;
                mask_pos = (c_k_vec > 1e-12);
                if any(mask_pos)
                    u_k = utilidade_crra(c_k_vec(mask_pos), sigma) - psi_d;
                    v_k_vec = u_k + W_kinks(mask_pos);
                    [v_k_best, idx_best] = max(v_k_vec);
                    if v_k_best > v_cond(i) + 1e-9
                        k_valid_pos = kinks_validos(mask_pos);
                        c_valid_pos = c_k_vec(mask_pos);
                        pol_c(i)      = c_valid_pos(idx_best);
                        pol_aprime(i) = k_valid_pos(idx_best);
                        v_cond(i)     = v_k_best;
                        melhorias_kink = melhorias_kink + 1;
                    end
                end
            end
        end
    end

    diag_ramo = struct();
    diag_ramo.a_endo          = a_endo;
    diag_ramo.c_endo          = c_endo;
    diag_ramo.teve_dobra      = teve_dobra;
    diag_ramo.da_endo         = da_endo;
    diag_ramo.melhorias_kink  = melhorias_kink;
end

function ramos = identificar_ramos_monotonicos(a_endo, c_endo, a_grid)
% Divide a grade endogena em segmentos estritamente monotonos.
    N = length(a_endo);
    ramos = {};

    idx_inicio = 1;
    for k = 1:(N - 1)
        if a_endo(k+1) <= a_endo(k)
            if k > idx_inicio
                r = struct();
                r.a = a_endo(idx_inicio:k);
                r.c = c_endo(idx_inicio:k);
                r.a_min = min(r.a);
                r.a_max = max(r.a);
                ramos{end+1} = r;
            end
            idx_inicio = k + 1;
        end
    end

    if idx_inicio <= N
        r = struct();
        r.a = a_endo(idx_inicio:N);
        r.c = c_endo(idx_inicio:N);
        r.a_min = min(r.a);
        r.a_max = max(r.a);
        ramos{end+1} = r;
    end
end
