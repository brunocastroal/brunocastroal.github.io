function comp = comparacao_metodos(eq_dc, eq_vfi)
% COMPARACAO_METODOS Compara quantitativamente as solucoes de Equilibrio Geral
% competitivo obtidas por DC-EGM e VFI.
%
% Sintaxe:
%   comp = comparacao_metodos(eq_dc, eq_vfi)

    comp = comparacao_equilibrio_geral(eq_dc, eq_vfi);
end
