function params = parametros_modelo_ext(scale_eps, chi_bar, Na)
% PARAMETROS_MODELO_EXT Parametros economicos da extensao com Taste Shocks e Custos de Transicao.
%
% Sintaxe:
%   params = parametros_modelo_ext(scale_eps, chi_bar, Na)
%
% Entradas:
%   scale_eps - Escala dos choques Gumbel tipo I (s_eps >= 0). Default: 0.00
%   chi_bar   - Custo de transicao entre ocupacoes distintas (chi_bar >= 0). Default: 0.00
%   Na        - Numero de pontos da grade de ativos (default: 400)

    if nargin < 1 || isempty(scale_eps), scale_eps = 0.00; end
    if nargin < 2 || isempty(chi_bar),   chi_bar   = 0.00; end
    if nargin < 3 || isempty(Na),        Na        = 400;  end

    params = struct();

    % Preferencias do Consumidor
    params.beta      = 0.96;           % Fator de desconto intertemporal
    params.sigma     = 2.00;           % Aversao relativa ao risco (CRRA)
    params.psi       = [0.00, 0.05, 0.08]; % Desutilidade do esforco: [N, I, F]

    % Tecnologia Cobb-Douglas e Producao Agregada
    params.A         = 1.00;           % Produtividade total dos fatores
    params.alpha     = 0.36;           % Participacao do capital no produto
    params.delta     = 0.08;           % Taxa de depreciacao anual do capital

    % Politica Tributaria e Distorcao Ocupacional
    params.tau       = 0.20;           % Aliquota de imposto sobre trabalho formal
    params.tau_d     = [0.00, 0.00, 0.20]; % Aliquota por ocupacao: [N, I, F]
    params.kappa     = 0.72;           % Produtividade relativa do trabalho informal
    params.h_eff     = [0.00, 0.72, 1.00]; % Oferta de trabalho efetivo: [N, I, F]

    % Processo Estocastico de Produtividade (AR(1) em logs via Rouwenhorst)
    params.rho_z     = 0.90;           % Persistencia autorregressiva
    params.sigma_eps = 0.20;           % Desvio-padrao da inovacao do choque
    params.Nz        = 5;              % Numero de estados de produtividade

    % Grade de Ativos Financeiros
    params.Na        = Na;             % Numero de pontos da grade de ativos
    params.a_min     = 0.00;           % Limite inferior (restricao estrita de liquidez)
    params.a_max     = 80.00;          % Limite superior da grade

    % Precos de Equilibrio Parcial (calculados dinamicamente se vazios)
    params.r         = [];             % Taxa de juros de referencia de equilibrio parcial
    params.w         = [];             % Salario real de referencia de equilibrio parcial

    % PARAMETROS DA NOVA EXTENSAO ECONOMICA
    params.scale_eps = scale_eps;      % Parametro de escala s_eps dos taste shocks Gumbel (s_eps >= 0)
    params.chi_bar   = chi_bar;        % Custo de transicao ocupacional chi_bar (unidades de utilidade)
end
