# Pacote de Entrega: Modelo de Agentes Heterogêneos com Escolhas Ocupacionais e Custos de Transição

**Uma Comparação Rigorosa entre VFI e DC-EGM**  
*Disciplina: Economia Computacional / Macroeconomia Quantitativa*  
*Nível: Pós-Graduação em Economia*  
*Autor: Bruno Castro Alves (Pós-Graduação em Economia)*  
*Data: 12 de novembro de 2026*  
*Ambiente de Referência: MATLAB R2026b Update 1 / R2020b+*

---

## 1. Visão Geral

Este pacote contém o código-fonte, a parametrização, os dados numéricos, as figuras e a documentação completa do projeto de pesquisa que implementa e compara dois métodos numéricos para a solução de modelos de agentes heterogêneos (*incomplete markets*):

1. **Value Function Iteration (VFI) Vetorizada:** Solucionador clássico por busca exaustiva sobre grade discreta $(a, a')$, monotonicidade e robustez global.
2. **Discrete-Continuous Endogenous Grid Method (DC-EGM) com Upper Envelope:** Extensão do método de Carroll (2006) por Iskhakov et al. (2017) que inverte analiticamente a Equação de Euler sem otimização numérica, utilizando poda geométrica (*Upper Envelope*) para contornar a quebra de concavidade gerada por custos fixos de transição ocupacional ($\bar\chi = 0{,}05$) e escolhas discretas determinísticas ($s_\varepsilon = 0$).

---

## 2. Início Rápido (Instruções para o Professor)

Para executar o projeto e reproduzir todos os resultados, siga os três passos abaixo:

1. Abra o **MATLAB** e defina o diretório atual para a pasta raiz do pacote (`ENTREGA_PROFESSOR/`):
   ```matlab
   cd('caminho/para/ENTREGA_PROFESSOR')
   ```
2. Digite no Prompt de Comando (o script adiciona automaticamente `codigos/` e `parametros/` ao *path*):
   ```matlab
   executar_projeto
   ```
3. Escolha uma das opções:
   - **Opção [1] (Recomendada - Validação Rápida):** Executa a suíte de 11 testes formais de consistência, valida a Lei de Walras ($< 10^{-7}$, com resíduo observado $-1{,}68 \times 10^{-8}$) e regenera todas as 16 figuras científicas em alta resolução e tabelas CSV.
   - **Opção [2] (Reprodução do Zero em ~40s):** Resolve as Equações de Bellman do zero via DC-EGM e VFI, calcula a distribuição estacionária e encontra a taxa de juros de equilíbrio geral por bisseção.
   - **Opção [3] (Benchmark Multigrade em ~2min):** Resolve o modelo em malhas $N_a \in \{400, 800, 1600\}$, registrando o desempenho empírico de até 7,65x do DC-EGM em $N_a=1600$ (após convergência a partir de $N_a=800$).

---

## 3. Estrutura do Pacote

Para o mapeamento detalhado de assinaturas e dependências, consulte `documentacao/MAPA_CODIGOS.md` (ou `.pdf`).

```text
ENTREGA_PROFESSOR/
│
├── README.md                              <- Este documento de orientação
├── executar_projeto.m                     <- ÚNICO PONTO DE ENTRADA (menus [1], [2], [3])
│
├── parametros/                            <- Parâmetros econômicos e grades (sem duplicação)
│   ├── configuracao_modelo.m              <- Consulta interativa da calibração canônica
│   ├── parametros_modelo.m / _ext.m       <- Definição canônica dos parâmetros
│   ├── preprocessamento_modelo.m / _ext.m <- Grade [0,80], Rouwenhorst (5) e custos chi
│   └── obter_raiz_projeto.m               <- Localização dinâmica da raiz do pacote
│
├── codigos/                               <- Funções e rotinas organizadas em 5 subpastas
│   ├── solucionadores/                    <- VFI vetorizada, DC-EGM, Upper Envelope e CRRA
│   ├── distribuicao/                      <- Operador de Young (2010) e agregados_macro.m
│   ├── equilibrio_geral/                  <- Bisseção de EG (DC-EGM e VFI) e comparação
│   ├── diagnosticos/                      <- 11 testes formais, multigrade, dobras e D2V
│   └── resultados/                        <- Validação, reprodução integral, 16 figuras e CSVs
│
├── resultados/                            <- Arquivos .mat, log e planilhas geradas
│   ├── tabelas/                           <- tabela1..3.csv e TABELAS_RESULTADOS_FINAIS.xlsx
│   ├── resultados_*.mat                   <- Registros binários oficiais (EP, EG e benchmark)
│   └── log_execucao_modelo.txt            <- Registro completo da última execução
│
├── figuras/                               <- Gráficos acadêmicos em formato triplo (16 figuras)
│   ├── PDF/                               <- 16 figuras vetoriais prontas para publicação
│   ├── PNG/                               <- 16 figuras em 300 DPI
│   └── FIG/                               <- 16 figuras editáveis em formato MATLAB (.fig)
│
└── documentacao/                          <- Manuais, mapa de códigos, relatórios e e-book
    ├── MAPA_CODIGOS.pdf / .md             <- Mapa completo de arquivos, dependências e fluxos
    ├── MANUAL_EXECUCAO.pdf                <- Guia operacional e requisitos
    ├── DESCRICAO_ALGORITMOS.pdf           <- Formulação matemática dos algoritmos
    ├── RELATORIO_FINAL.pdf                <- Artigo acadêmico completo
    ├── APRESENTACAO_FINAL.pdf             <- Slides executivos em LaTeX Beamer (18 slides, 16:9)
    ├── APRESENTACAO_COMPLETA.pdf          <- Apresentação Beamer expandida (45 slides, 16:9)
    ├── EBOOK_DC_EGM_VFI_FINAL.pdf         <- E-book didático consolidado com capítulo MATLAB
    └── COLETANEA_FIGURAS.pdf              <- Caderno encadernado com todas as figuras
```

> **Materiais complementares fora deste pacote leve:** fontes LaTeX editáveis do e-book em `12_SINTESE_DIDATICA/ebook/FONTES_EDITAVEIS/` e audiolivro didático completo em 12 capítulos (`02:30:46` em MP3 `pt-BR`) em `12_SINTESE_DIDATICA/AUDIOLIVRO/`.

---

## 4. Síntese dos Resultados Numéricos

### A. Equilíbrio Geral Estacionário ($N_a = 400$)

| Variável Macroeconômica | DC-EGM com Envelope | VFI Vetorizada | Discrepância Relativa |
| :--- | :---: | :---: | :---: |
| Razão Capital-Trabalho ($k^*$) | 6,564697 | 6,547806 | 0,258 % |
| Taxa Real de Juros ($r^*$) | 2,7966 % | 2,8144 % | 0,633 % (1,8 pb) |
| Salário Real Competitivo ($w^*$) | 1,260020 | 1,258851 | 0,093 % |
| Estoque de Capital ($K^*$) | 6,5349 | 6,5147 | 0,310 % |
| Trabalho Efetivo ($L^*$) | 0,9956 | 0,9947 | 0,090 % |
| Produto Agregado ($Y^*$) | 1,9600 | 1,9567 | 0,169 % |
| Consumo Agregado ($C^*$) | 1,1892 | 1,1885 | 0,055 % |
| Investimento Agregado ($I^*$) | 0,5228 | 0,5212 | 0,309 % |
| **Resíduo da Lei de Walras** | **$-1{,}68 \times 10^{-8}$** | **$-2{,}47 \times 10^{-8}$** | **Fechamento Exato** |
| Coeficiente de Gini de Riqueza | 0,4948 | 0,5115 | 3,38 % |
| Participação no Setor Formal ($M_F$) | 98,28 % | 97,96 % | 0,32 pp |
| **Tempo de CPU em Equilíbrio Geral** | **7,61 s** | **26,60 s** | **3,49x mais rápido** |

### B. Refinamento Multigrade (Equilíbrio Parcial Canônico com $\bar\chi = 0{,}05$)

| $N_a$ | Iter. VFI | Iter. DC-EGM | Tempo VFI | Tempo DC-EGM | Speedup | $\|V_{\text{VFI}} - V_{\text{DC}}\|_\infty$ | Concordância Ocupacional | Dobras Endógenas |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| 400 | 376 | 1500* | 2,91 s | 4,99 s | 0,58x | 0,3387 | 99,27 % | 0 |
| 800 | 376 | 376 | 10,59 s | 2,53 s | **4,19x** | 0,0682 | 99,78 % | 2 |
| 1600 | 376 | 376 | 39,75 s | 5,20 s | **7,65x** | 0,0156 | 99,97 % | 4 |

*\* Nota: Em $N_a=400$, o DC-EGM atingiu o limite de 1.500 iterações com resíduo de Cauchy $\|V^{(k+1)} - V^{(k)}\|_\infty = 2{,}09 \times 10^{-6}$ (tolerância $10^{-7}$) devido a alternâncias locais nas fronteiras de custos de transição. Nas malhas refinadas ($N_a \ge 800$), a maior densidade espacial elimina o ciclo e restabelece a convergência em 376 iterações ($9{,}91 \times 10^{-8} < 10^{-7}$).*

---

## 5. Referências Bibliográficas

1. **Aiyagari, S. R. (1994).** Uninsured Idiosyncratic Risk and Aggregate Saving. *Quarterly Journal of Economics*, 109(3), 659–684.
2. **Carroll, C. D. (2006).** The Method of Endogenously Constrained Grids for Solving Dynamic Stochastic Optimization Problems. *Economics Letters*, 91(3), 312–320.
3. **Huggett, M. (1993).** The Risk-Free Rate in Heterogeneous-Agent Incomplete-Insurance Economies. *Journal of Economic Dynamics and Control*, 17(5-6), 953–969.
4. **Iskhakov, F., Jørgensen, T. H., Rust, J., & Schjerning, B. (2017).** The Endogenous Grid Method for Discrete-Continuous Dynamic Choice Models with (or without) Taste Shocks. *Quantitative Economics*, 8(2), 317–365.
5. **Young, E. R. (2010).** Solving the Incomplete Markets Model with Aggregate Uncertainty Using the Krusell-Smith Algorithm and Non-Stochastic Simulations. *Journal of Economic Dynamics and Control*, 34(1), 36–41.
