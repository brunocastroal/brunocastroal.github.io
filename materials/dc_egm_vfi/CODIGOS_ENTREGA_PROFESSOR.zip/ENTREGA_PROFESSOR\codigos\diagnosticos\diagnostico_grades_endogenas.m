function res = diagnostico_grades_endogenas(modelo, solucao)
% DIAGNOSTICO_GRADES_ENDOGENAS Avalia a monotonicidade e a ocorrencia de dobras
% nas grades endogenas a_endo(a', z, d) para todos os 15 ramos ocupacionais.
%
% Sintaxe:
%   res = diagnostico_grades_endogenas(modelo, solucao)

    Na = modelo.Na;
    Nz = modelo.Nz;
    a  = modelo.a;
    R  = modelo.R;
    y  = modelo.y;
    sigma = modelo.params.sigma;

    Wprime = solucao.Wprime; % Na x Nz x 3

    a_endo_tensor  = zeros(Na, Nz, 3);
    c_endo_tensor  = zeros(Na, Nz, 3);
    da_endo_tensor = zeros(Na - 1, Nz, 3);

    min_inc         = zeros(Nz, 3);
    max_inc         = zeros(Nz, 3);
    num_neg         = zeros(Nz, 3);
    num_prox_zero   = zeros(Nz, 3);
    classificacao   = cell(Nz, 3);
    loc_dobras_cell = cell(Nz, 3);

    tol_zero = 1e-6;

    for d = 1:3
        for j = 1:Nz
            Wp_pos = max(Wprime(:, j, d), 1e-14);
            if abs(sigma - 1.0) < 1e-6
                c_endo = 1.0 ./ Wp_pos;
            else
                c_endo = Wp_pos.^(-1.0 / sigma);
            end

            a_endo = (c_endo + a - y(j, d)) / R;
            da_endo = diff(a_endo);

            a_endo_tensor(:, j, d)  = a_endo;
            c_endo_tensor(:, j, d)  = c_endo;
            da_endo_tensor(:, j, d) = da_endo;

            min_val = min(da_endo);
            max_val = max(da_endo);
            min_inc(j, d) = min_val;
            max_inc(j, d) = max_val;

            n_neg = sum(da_endo < 0.0);
            num_neg(j, d) = n_neg;

            n_zero = sum(abs(da_endo) < tol_zero);
            num_prox_zero(j, d) = n_zero;

            if n_neg > 0
                idx_neg = find(da_endo < 0.0);
                loc_dobras_cell{j, d} = a(idx_neg);
                classificacao{j, d} = 'Nao monotonica (Dobra)';
            elseif min_val <= 1e-5
                loc_dobras_cell{j, d} = [];
                classificacao{j, d} = 'Quase critica';
            else
                loc_dobras_cell{j, d} = [];
                classificacao{j, d} = 'Monotonica';
            end
        end
    end

    total_dobras = sum(num_neg(:));
    total_quase_criticas = sum(strcmp(classificacao(:), 'Quase critica'));

    res = struct();
    res.a_endo_tensor        = a_endo_tensor;
    res.c_endo_tensor        = c_endo_tensor;
    res.da_endo_tensor       = da_endo_tensor;
    res.min_inc              = min_inc;
    res.max_inc              = max_inc;
    res.num_neg              = num_neg;
    res.num_prox_zero        = num_prox_zero;
    res.classificacao        = classificacao;
    res.loc_dobras           = loc_dobras_cell;
    res.total_dobras         = total_dobras;
    res.total_quase_criticas = total_quase_criticas;
    res.min_global_inc       = min(da_endo_tensor(:));
    res.max_global_inc       = max(da_endo_tensor(:));
end
