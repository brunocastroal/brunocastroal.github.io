function modelo = preprocessamento_modelo_ext(params)
% PREPROCESSAMENTO_MODELO_EXT Prepara grades, matriz de transicao, custos e rendas da extensao.
%
% Sintaxe:
%   modelo = preprocessamento_modelo_ext(params)

    if nargin < 1 || isempty(params)
        params = parametros_modelo_ext();
    end

    Na = params.Na;
    Nz = params.Nz;

    % 1. Grade de Ativos Financeiros
    a = linspace(params.a_min, params.a_max, Na)';

    % 2. Processo de Produtividade Estocastica (Rouwenhorst, 1995)
    rho = params.rho_z;
    sigma_eps = params.sigma_eps;

    p = (1.0 + rho) / 2.0;
    q = p;

    sigma_x = sigma_eps / sqrt(1.0 - rho^2);
    psi_x = sqrt(Nz - 1.0) * sigma_x;
    x = linspace(-psi_x, psi_x, Nz)';

    % Construcao recursiva de Rouwenhorst
    Pi = [p, 1.0 - p; 1.0 - q, q];
    for n = 3:Nz
        Pi_old = Pi;
        Pi = zeros(n, n);
        Pi(1:n-1, 1:n-1) = Pi(1:n-1, 1:n-1) + p * Pi_old;
        Pi(1:n-1, 2:n)   = Pi(1:n-1, 2:n)   + (1.0 - p) * Pi_old;
        Pi(2:n,   1:n-1) = Pi(2:n,   1:n-1) + (1.0 - q) * Pi_old;
        Pi(2:n,   2:n)   = Pi(2:n,   2:n)   + q * Pi_old;
        Pi(2:n-1, :) = Pi(2:n-1, :) / 2.0;
    end
    Pi = Pi ./ repmat(sum(Pi, 2), 1, Nz); % Estocasticidade exata

    % Distribuicao estacionaria de Markov via autovetor unitario
    [V_aut, D_aut] = eig(Pi');
    [~, idx_1] = min(abs(diag(D_aut) - 1.0));
    pi_z = real(V_aut(:, idx_1))';
    pi_z = pi_z / sum(pi_z);

    % Niveis de produtividade normalizados com E[z] = 1
    z_raw = exp(x);
    z = z_raw / sum(pi_z(:) .* z_raw(:));

    % 3. Precos de Equilibrio Parcial (Regra de Ouro Modificada)
    if isempty(params.r)
        r = (1.0 / params.beta) - 1.0;
    else
        r = params.r;
    end
    R = 1.0 + r;

    if isempty(params.w)
        k_rep = (params.alpha * params.A / (r + params.delta))^(1.0 / (1.0 - params.alpha));
        w = (1.0 - params.alpha) * params.A * (k_rep^params.alpha);
    else
        w = params.w;
        k_rep = ((1.0 - params.alpha) * params.A / w)^(-1.0 / params.alpha);
    end

    % 4. Matriz de Renda Liquida por Choque e Ocupacao y(z, d) (Nz x 3)
    % Coluna 1: Inativo (N)   -> y = 0
    % Coluna 2: Informal (I)  -> y = kappa * w * z
    % Coluna 3: Formal (F)    -> y = (1 - tau) * w * z
    y = zeros(Nz, 3);
    y(:, 1) = 0.0;
    y(:, 2) = params.kappa * w * z;
    y(:, 3) = (1.0 - params.tau) * w * z;

    % 5. Matriz de Custos de Transicao Ocupacional chi(d^-, d) (3 x 3)
    % Linha d^-: ocupacao no periodo anterior
    % Coluna d:  ocupacao escolhida no periodo corrente
    % chi(d^-, d) = 0 se d^- == d; chi_bar se d^- ~= d.
    chi_mat = params.chi_bar * (ones(3, 3) - eye(3));

    % Estrutura consolidada
    modelo = struct();
    modelo.params    = params;
    modelo.a         = a;
    modelo.Na        = Na;
    modelo.x         = x;
    modelo.z         = z;
    modelo.Nz        = Nz;
    modelo.Pi        = Pi;
    modelo.pi_z      = pi_z;
    modelo.r         = r;
    modelo.w         = w;
    modelo.R         = R;
    modelo.k_rep     = k_rep;
    modelo.y         = y;
    modelo.chi_mat   = chi_mat;
    modelo.scale_eps = params.scale_eps;
    modelo.chi_bar   = params.chi_bar;
end
