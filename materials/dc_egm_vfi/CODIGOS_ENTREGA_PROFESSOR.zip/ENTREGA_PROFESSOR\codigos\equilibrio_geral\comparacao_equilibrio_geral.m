function comp = comparacao_equilibrio_geral(eq_dc, eq_vfi, eq_pe_dc, eq_pe_vfi)
% COMPARACAO_EQUILIBRIO_GERAL Compara exaustivamente as solucoes de Equilibrio Geral
% e Equilibrio Parcial obtidas por DC-EGM e VFI sob Taste Shocks e Custos de Transicao.
%
% Sintaxe:
%   comp = comparacao_equilibrio_geral(eq_dc, eq_vfi, eq_pe_dc, eq_pe_vfi)

    if nargin < 3, eq_pe_dc = []; end
    if nargin < 4, eq_pe_vfi = []; end

    % 1. Comparacao Direta DC-EGM vs VFI em Equilibrio Geral
    dif_k       = abs(eq_dc.k - eq_vfi.k);
    dif_rel_k   = dif_k / eq_vfi.k;

    dif_r       = abs(eq_dc.r - eq_vfi.r);
    dif_rel_r   = dif_r / max(abs(eq_vfi.r), 1e-12);

    dif_w       = abs(eq_dc.w - eq_vfi.w);
    dif_rel_w   = dif_w / eq_vfi.w;

    dif_K       = abs(eq_dc.K - eq_vfi.K);
    dif_rel_K   = dif_K / eq_vfi.K;

    dif_L       = abs(eq_dc.L - eq_vfi.L);
    dif_rel_L   = dif_L / eq_vfi.L;

    dif_Y       = abs(eq_dc.Y - eq_vfi.Y);
    dif_rel_Y   = dif_Y / eq_vfi.Y;

    dif_C       = abs(eq_dc.C - eq_vfi.C);
    dif_rel_C   = dif_C / eq_vfi.C;

    dif_gini    = abs(eq_dc.gini - eq_vfi.gini);
    dif_MN      = abs(eq_dc.M_N - eq_vfi.M_N);
    dif_MI      = abs(eq_dc.M_I - eq_vfi.M_I);
    dif_MF      = abs(eq_dc.M_F - eq_vfi.M_F);

    speedup_eg  = eq_vfi.tempo_total / max(eq_dc.tempo_total, 1e-6);

    % 2. Comparacao de Politicas e Funcao Valor
    dif_sup_V   = max(abs(eq_dc.solucao.V(:) - eq_vfi.solucao.V(:)));
    dif_sup_ap  = max(abs(eq_dc.solucao.aprime_d(:) - eq_vfi.solucao.aprime_d(:)));
    dif_sup_c   = max(abs(eq_dc.solucao.c_d(:) - eq_vfi.solucao.c_d(:)));
    dif_sup_P   = max(abs(eq_dc.solucao.P_d(:) - eq_vfi.solucao.P_d(:)));
    dif_sup_mu  = max(abs(eq_dc.distribuicao.mu(:) - eq_vfi.distribuicao.mu(:)));

    % 3. Consolidacao
    comp = struct();
    comp.eq_dc      = eq_dc;
    comp.eq_vfi     = eq_vfi;
    comp.eq_pe_dc   = eq_pe_dc;
    comp.eq_pe_vfi  = eq_pe_vfi;

    comp.dif_k      = dif_k;
    comp.dif_rel_k  = dif_rel_k;
    comp.dif_r      = dif_r;
    comp.dif_rel_r  = dif_rel_r;
    comp.dif_w      = dif_w;
    comp.dif_rel_w  = dif_rel_w;
    comp.dif_K      = dif_K;
    comp.dif_rel_K  = dif_rel_K;
    comp.dif_L      = dif_L;
    comp.dif_rel_L  = dif_rel_L;
    comp.dif_Y      = dif_Y;
    comp.dif_rel_Y  = dif_rel_Y;
    comp.dif_C      = dif_C;
    comp.dif_rel_C  = dif_rel_C;
    comp.dif_gini   = dif_gini;
    comp.dif_MN     = dif_MN;
    comp.dif_MI     = dif_MI;
    comp.dif_MF     = dif_MF;

    comp.dif_sup_V  = dif_sup_V;
    comp.dif_sup_ap = dif_sup_ap;
    comp.dif_sup_c  = dif_sup_c;
    comp.dif_sup_P  = dif_sup_P;
    comp.dif_sup_mu = dif_sup_mu;

    comp.speedup_eg = speedup_eg;

    % Imprimir tabela comparativa
    fprintf('========================================================================\n');
    fprintf('       COMPARACAO DC-EGM vs VFI EM EQUILIBRIO GERAL ESTACIONARIO\n');
    fprintf('========================================================================\n');
    fprintf('%-25s | %-12s | %-12s | %-12s\n', 'Variavel', 'DC-EGM', 'VFI', 'Dif Relativa');
    fprintf('------------------------------------------------------------------------\n');
    fprintf('%-25s | %-12.6f | %-12.6f | %-12.4e\n', 'Razao k* = K/L', eq_dc.k, eq_vfi.k, dif_rel_k);
    fprintf('%-25s | %-11.4f%% | %-11.4f%% | %-12.4e\n', 'Taxa de Juros r*', eq_dc.r * 100, eq_vfi.r * 100, dif_rel_r);
    fprintf('%-25s | %-12.6f | %-12.6f | %-12.4e\n', 'Salario Real w*', eq_dc.w, eq_vfi.w, dif_rel_w);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Capital Agregado K*', eq_dc.K, eq_vfi.K, dif_rel_K);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Trabalho Efetivo L*', eq_dc.L, eq_vfi.L, dif_rel_L);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Produto Total Y*', eq_dc.Y, eq_vfi.Y, dif_rel_Y);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Consumo Privado C*', eq_dc.C, eq_vfi.C, dif_rel_C);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Investimento I* = d*K', eq_dc.I, eq_vfi.I, abs(eq_dc.I - eq_vfi.I)/eq_vfi.I);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Gasto Publico G*', eq_dc.G, eq_vfi.G, abs(eq_dc.G - eq_vfi.G)/eq_vfi.G);
    fprintf('%-25s | %-12.2e | %-12.2e | %-12s\n', 'Residuo de Walras', eq_dc.hiato_walras, eq_vfi.hiato_walras, '-');
    fprintf('%-25s | %-11.2f%% | %-11.2f%% | %-12.4e\n', 'Participacao Inativos', eq_dc.M_N * 100, eq_vfi.M_N * 100, dif_MN);
    fprintf('%-25s | %-11.2f%% | %-11.2f%% | %-12.4e\n', 'Participacao Informais', eq_dc.M_I * 100, eq_vfi.M_I * 100, dif_MI);
    fprintf('%-25s | %-11.2f%% | %-11.2f%% | %-12.4e\n', 'Participacao Formais', eq_dc.M_F * 100, eq_vfi.M_F * 100, dif_MF);
    fprintf('%-25s | %-12.4f | %-12.4f | %-12.4e\n', 'Coeficiente de Gini', eq_dc.gini, eq_vfi.gini, dif_gini);
    fprintf('%-25s | %-11.4f%% | %-11.4f%% | %-12s\n', 'Fatia Bottom 50%', eq_dc.bottom_50 * 100, eq_vfi.bottom_50 * 100, '-');
    fprintf('%-25s | %-11.4f%% | %-11.4f%% | %-12s\n', 'Fatia Top 10%', eq_dc.top_10 * 100, eq_vfi.top_10 * 100, '-');
    fprintf('%-25s | %-11.4f%% | %-11.4f%% | %-12s\n', 'Fatia Top 1%', eq_dc.top_1 * 100, eq_vfi.top_1 * 100, '-');
    fprintf('%-25s | %-11.4f%% | %-11.4f%% | %-12s\n', 'Fracao em a=0', eq_dc.frac_a_min * 100, eq_vfi.frac_a_min * 100, '-');
    fprintf('%-25s | %-11.4e%% | %-11.4e%% | %-12s\n', 'Fracao em a=80', eq_dc.frac_a_max * 100, eq_vfi.frac_a_max * 100, '-');
    fprintf('%-25s | %-12d | %-12d | %-12s\n', 'Iteracoes Bisseccao', eq_dc.iteracoes, eq_vfi.iteracoes, '-');
    fprintf('%-25s | %-11.2f s | %-11.2f s | %-12.2f (Speedup)\n', 'Tempo Computacional', eq_dc.tempo_total, eq_vfi.tempo_total, speedup_eg);
    fprintf('========================================================================\n');
end
