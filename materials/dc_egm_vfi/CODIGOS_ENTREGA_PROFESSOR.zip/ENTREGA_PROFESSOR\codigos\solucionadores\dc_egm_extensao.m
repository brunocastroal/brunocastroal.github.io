function sol = dc_egm_extensao(modelo, tol_V, tol_c, max_iter, V_init, c_init, use_parfor, kinks_by_d)
% DC_EGM_EXTENSAO Resolve o modelo com Taste Shocks e Custos de Transicao via DC-EGM.
%
% Versao Validada e Auditada com:
%   1) Tratamento estrito de cantos inferior e superior (Kuhn-Tucker)
%   2) Satisfacao exata da restricao orcamentaria: c + a' = R*a + y (|erro| < 1e-10)
%   3) Avaliacao consistente da funcao valor: v_d(a, z) = u(c) - psi_d + W_d(a', z)
%   4) Operador Bellman economico exato (sem regra artificial de tolerancia/inercia)
%      V = max_d v_d, d* = argmax_d v_d (desempate numerico por menor indice)
%   5) Suporte a integracao de candidatos de kink ocupacional na maximizacao continua
%
% Sintaxe:
%   sol = dc_egm_extensao(modelo, tol_V, tol_c, max_iter, V_init, c_init, use_parfor, kinks_by_d)

    if nargin < 2 || isempty(tol_V),      tol_V      = 1e-7;  end
    if nargin < 3 || isempty(tol_c),      tol_c      = 1e-6;  end
    if nargin < 4 || isempty(max_iter),   max_iter   = 1000;  end
    if nargin < 7 || isempty(use_parfor), use_parfor = false; end

    params    = modelo.params;
    beta      = params.beta;
    sigma     = params.sigma;
    psi       = params.psi;
    scale_eps = modelo.scale_eps;
    chi_mat   = modelo.chi_mat;

    Na = modelo.Na;
    Nz = modelo.Nz;
    a  = modelo.a;
    R  = modelo.R;
    y  = modelo.y;
    Pi = modelo.Pi;

    % 1. Inicializacao da Funcao Valor e Politica de Consumo
    if nargin >= 5 && ~isempty(V_init)
        V = V_init;
    else
        V = zeros(Na, Nz, 3);
    end

    if nargin >= 6 && ~isempty(c_init)
        pol_c = c_init;
    else
        pol_c = zeros(Na, Nz, 3);
        for d = 1:3
            for j = 1:Nz
                pol_c(:, j, d) = max(1e-6, R * a + y(j, d));
            end
        end
    end

    v_cond = zeros(Na, Nz, 3, 3); % (a, z, d, d^-)
    for d_prev = 1:3
        for d = 1:3
            v_cond(:, :, d, d_prev) = V(:, :, d_prev) - chi_mat(d_prev, d);
        end
    end

    t_start = tic;
    convergiu = false;
    iter = 0;
    erro_V = Inf;
    erro_c = Inf;

    W          = zeros(Na, Nz, 3);
    Wprime     = zeros(Na, Nz, 3);
    tilde_v    = zeros(Na, Nz, 3);
    pol_aprime = zeros(Na, Nz, 3);
    pol_c_new  = zeros(Na, Nz, 3);
    V_new      = zeros(Na, Nz, 3);
    P_d        = zeros(Na, Nz, 3, 3);
    total_dobras_detectadas = 0;

    num_tarefas = 3 * Nz;

    while iter < max_iter && ~convergiu
        iter = iter + 1;

        % PASSO 1: CONTINUACAO ESPERADA ESPECIFICA POR OCUPACAO d
        for d = 1:3
            W(:, :, d) = beta * (V(:, :, d) * Pi');
        end

        % PASSO 2: PROBABILIDADES FUTURAS E DERIVADA DO VALOR INCLUSIVO
        uprime_c = zeros(Na, Nz, 3);
        for j = 1:3
            if abs(sigma - 1.0) < 1e-6
                uprime_c(:, :, j) = 1.0 ./ max(pol_c(:, :, j), 1e-12);
            else
                uprime_c(:, :, j) = max(pol_c(:, :, j), 1e-12).^(-sigma);
            end
        end

        P_fut = zeros(Na, Nz, 3, 3); % (a', z', j_amanha, d_hoje)
        d_star_curr = zeros(Na, Nz, 3);

        for d_hoje = 1:3
            v1 = v_cond(:, :, 1, d_hoje);
            v2 = v_cond(:, :, 2, d_hoje);
            v3 = v_cond(:, :, 3, d_hoje);

            if scale_eps > 0
                m = max(v1, max(v2, v3));
                e1 = exp((v1 - m) / scale_eps);
                e2 = exp((v2 - m) / scale_eps);
                e3 = exp((v3 - m) / scale_eps);
                S = e1 + e2 + e3;
                P_fut(:, :, 1, d_hoje) = e1 ./ S;
                P_fut(:, :, 2, d_hoje) = e2 ./ S;
                P_fut(:, :, 3, d_hoje) = e3 ./ S;
            else
                % Regime Deterministico: verdadeiro operador argmax
                % Em caso de empate numerico exato (diferenca < eps), a convencao padrao do MATLAB
                % seleciona deterministicamente a primeira alternativa otima (menor indice ocupacional)
                [~, d_star_mat] = max(cat(4, v1, v2, v3), [], 4);
                P_fut(:, :, 1, d_hoje) = double(d_star_mat == 1);
                P_fut(:, :, 2, d_hoje) = double(d_star_mat == 2);
                P_fut(:, :, 3, d_hoje) = double(d_star_mat == 3);
            end
        end

        % M(a', z', d) = sum_j P_fut(a', z', j, d) .* uprime_c(a', z', j)
        for d = 1:3
            M_d = P_fut(:, :, 1, d) .* uprime_c(:, :, 1) + ...
                  P_fut(:, :, 2, d) .* uprime_c(:, :, 2) + ...
                  P_fut(:, :, 3, d) .* uprime_c(:, :, 3);
            Wprime(:, :, d) = beta * R * (M_d * Pi');
        end

        % PASSO 3: RESOLUCAO DOS 15 RAMOS CONDICIONAIS VIA DC-EGM
        if use_parfor
            c_cell     = cell(num_tarefas, 1);
            ap_cell    = cell(num_tarefas, 1);
            v_cell     = cell(num_tarefas, 1);
            dobras_vec = false(num_tarefas, 1);

            parfor t_idx = 1:num_tarefas
                d = ceil(t_idx / Nz);
                j = t_idx - (d - 1) * Nz;

                [c_cell{t_idx}, ap_cell{t_idx}, v_cell{t_idx}, dobras_vec(t_idx)] = ...
                    dc_egm_ramo_condicional(a, W(:, j, d), Wprime(:, j, d), ...
                                           y(j, d), psi(d), R, sigma);
            end

            for t_idx = 1:num_tarefas
                d = ceil(t_idx / Nz);
                j = t_idx - (d - 1) * Nz;
                pol_c_new(:, j, d)  = c_cell{t_idx};
                pol_aprime(:, j, d) = ap_cell{t_idx};
                tilde_v(:, j, d)    = v_cell{t_idx};
            end
            total_dobras_detectadas = total_dobras_detectadas + sum(dobras_vec);
        else
            for d = 1:3
                psi_d = psi(d);
                k_cand = [];
                if nargin >= 8 && ~isempty(kinks_by_d)
                    k_cand = kinks_by_d{d};
                end
                for j = 1:Nz
                    [c_res, ap_res, v_res, teve_d] = dc_egm_ramo_condicional(...
                        a, W(:, j, d), Wprime(:, j, d), y(j, d), psi_d, R, sigma, k_cand);

                    pol_c_new(:, j, d)  = c_res;
                    pol_aprime(:, j, d) = ap_res;
                    tilde_v(:, j, d)    = v_res;
                    if teve_d
                        total_dobras_detectadas = total_dobras_detectadas + 1;
                    end
                end
            end
        end

        % PASSO 4: CUSTOS DE TRANSICAO, TASTE SHOCKS E VALOR INCLUSIVO
        for d_prev = 1:3
            v1 = tilde_v(:, :, 1) - chi_mat(d_prev, 1);
            v2 = tilde_v(:, :, 2) - chi_mat(d_prev, 2);
            v3 = tilde_v(:, :, 3) - chi_mat(d_prev, 3);

            v_cond(:, :, 1, d_prev) = v1;
            v_cond(:, :, 2, d_prev) = v2;
            v_cond(:, :, 3, d_prev) = v3;

            if scale_eps > 0
                m  = max(v1, max(v2, v3));
                e1 = exp((v1 - m) / scale_eps);
                e2 = exp((v2 - m) / scale_eps);
                e3 = exp((v3 - m) / scale_eps);
                S  = e1 + e2 + e3;

                V_new(:, :, d_prev) = m + scale_eps * log(S);

                P_d(:, :, 1, d_prev) = e1 ./ S;
                P_d(:, :, 2, d_prev) = e2 ./ S;
                P_d(:, :, 3, d_prev) = e3 ./ S;
            else
                [max_v, d_star_mat] = max(cat(4, v1, v2, v3), [], 4);
                V_new(:, :, d_prev) = max_v;

                P_d(:, :, 1, d_prev) = double(d_star_mat == 1);
                P_d(:, :, 2, d_prev) = double(d_star_mat == 2);
                P_d(:, :, 3, d_prev) = double(d_star_mat == 3);
            end
        end

        % PASSO 5: CONVERGENCIA ESTREITA
        erro_V = max(abs(V_new(:) - V(:)));
        erro_c = max(abs(pol_c_new(:) - pol_c(:)));

        V = V_new;
        pol_c = pol_c_new;

        if erro_V < tol_V && erro_c < tol_c
            convergiu = true;
        end
    end

    tempo_total = toc(t_start);

    % Politicas agregadas esperadas
    aprime_exp = zeros(Na, Nz, 3);
    c_exp      = zeros(Na, Nz, 3);
    for d_prev = 1:3
        aprime_exp(:, :, d_prev) = P_d(:, :, 1, d_prev) .* pol_aprime(:, :, 1) + ...
                                   P_d(:, :, 2, d_prev) .* pol_aprime(:, :, 2) + ...
                                   P_d(:, :, 3, d_prev) .* pol_aprime(:, :, 3);
        c_exp(:, :, d_prev)      = P_d(:, :, 1, d_prev) .* pol_c(:, :, 1) + ...
                                   P_d(:, :, 2, d_prev) .* pol_c(:, :, 2) + ...
                                   P_d(:, :, 3, d_prev) .* pol_c(:, :, 3);
    end

    % Verificacao automatica da restricao orcamentaria
    max_violacao_orc = 0.0;
    for d = 1:3
        for j = 1:Nz
            viol = max(abs(R * a + y(j, d) - pol_aprime(:, j, d) - pol_c(:, j, d)));
            max_violacao_orc = max(max_violacao_orc, viol);
        end
    end

    sol = struct();
    sol.V                = V;
    sol.tilde_v          = tilde_v;
    sol.v_cond           = v_cond;
    sol.P_d              = P_d;
    sol.aprime_d         = pol_aprime;
    sol.c_d              = pol_c;
    sol.aprime_exp       = aprime_exp;
    sol.c_exp            = c_exp;
    sol.W                = W;
    sol.Wprime           = Wprime;
    sol.iter             = iter;
    sol.erro_V           = erro_V;
    sol.erro_c           = erro_c;
    sol.convergiu        = convergiu;
    sol.tempo            = tempo_total;
    sol.use_parfor       = use_parfor;
    sol.total_dobras     = total_dobras_detectadas;
    sol.max_violacao_orc = max_violacao_orc;

    if scale_eps == 0
        [~, d_star_full] = max(v_cond, [], 3);
        sol.d_star = squeeze(d_star_full);
    else
        sol.d_star = [];
    end
end
