function res = diagnostico_concavidade(solucao, modelo)
% DIAGNOSTICO_CONCAVIDADE Avalia a concavidade e as segundas diferencas finitas
% da funcao valor V(a, z, d^-).
%
% Sintaxe:
%   res = diagnostico_concavidade(solucao, modelo)

    res = diagnostico_concavidade_V(solucao, modelo);
end
