function eq = equilibrio_geral_dc_egm(params_base, opcoes)
% EQUILIBRIO_GERAL_DC_EGM Determina o equilibrio geral estacionario competitivo
% com agentes heterogeneos, taste shocks e custos de transicao via DC-EGM
% utilizando busca por bisseccao na razao capital-trabalho k = K/L.
%
% Sintaxe:
%   eq = equilibrio_geral_dc_egm()
%   eq = equilibrio_geral_dc_egm(params_base, opcoes)
%
% Entradas:
%   params_base - (Opcional) Parametros da extensao gerados por parametros_modelo_ext
%   opcoes      - (Opcional) Estrutura com opcoes do algoritmo:
%                   .k_min           (default: 6.00)
%                   .k_max           (default: 7.50)
%                   .tol_k           (default: 1e-4)
%                   .max_iter        (default: 30)
%                   .tol_V           (default: 1e-7)
%                   .tol_c           (default: 1e-6)
%                   .tol_dist        (default: 1e-10)
%                   .max_iter_solver (default: 1500)
%                   .max_iter_dist   (default: 25000)
%                   .verbose         (default: true)
%
% Saidas:
%   eq - Estrutura completa contendo o equilibrio geral, precos, agregados,
%        distribuicao estacionaria e historico de convergencia da bisseccao.

    if nargin < 1 || isempty(params_base)
        params_base = parametros_modelo_ext(0.00, 0.05, 400);
    end
    if nargin < 2, opcoes = struct(); end

    if ~isfield(opcoes, 'k_min'),           opcoes.k_min           = 6.00;  end
    if ~isfield(opcoes, 'k_max'),           opcoes.k_max           = 7.50;  end
    if ~isfield(opcoes, 'tol_k'),           opcoes.tol_k           = 1e-4;  end
    if ~isfield(opcoes, 'max_iter'),        opcoes.max_iter        = 30;    end
    if ~isfield(opcoes, 'tol_V'),           opcoes.tol_V           = 1e-7;  end
    if ~isfield(opcoes, 'tol_c'),           opcoes.tol_c           = 1e-6;  end
    if ~isfield(opcoes, 'tol_dist'),        opcoes.tol_dist        = 1e-10; end
    if ~isfield(opcoes, 'max_iter_solver'), opcoes.max_iter_solver = 1500;  end
    if ~isfield(opcoes, 'max_iter_dist'),   opcoes.max_iter_dist   = 25000; end
    if ~isfield(opcoes, 'verbose'),         opcoes.verbose         = true;  end

    t_total_start = tic;

    alpha = params_base.alpha;
    delta = params_base.delta;
    A_ptf = params_base.A;

    k_a = opcoes.k_min;
    k_b = opcoes.k_max;

    if opcoes.verbose
        fprintf('========================================================================\n');
        fprintf('  EQUILIBRIO GERAL VIA DC-EGM COM TASTE SHOCKS E CUSTOS DE TRANSICAO\n');
        fprintf('  Configuracao: s_eps = %.2f, chi_bar = %.2f, Na = %d\n', ...
            params_base.scale_eps, params_base.chi_bar, params_base.Na);
        fprintf('  Intervalo de bisseccao: [%.4f, %.4f], tol_k = %.1e\n', k_a, k_b, opcoes.tol_k);
        fprintf('========================================================================\n');
        fprintf('%-4s | %-7s | %-7s | %-7s | %-7s | %-7s | %-9s | %-9s | %-5s | %-6s\n', ...
            'Iter', 'k', 'r (%)', 'w', 'K_s', 'L_s', 'k_s', 'f(k)', 'Solv', 'Tempo');
        fprintf('------------------------------------------------------------------------\n');
    end

    % Estrutura de historico
    hist_k        = zeros(opcoes.max_iter, 1);
    hist_r        = zeros(opcoes.max_iter, 1);
    hist_w        = zeros(opcoes.max_iter, 1);
    hist_Ks       = zeros(opcoes.max_iter, 1);
    hist_Ls       = zeros(opcoes.max_iter, 1);
    hist_ks       = zeros(opcoes.max_iter, 1);
    hist_fk       = zeros(opcoes.max_iter, 1);
    hist_erro_rel = zeros(opcoes.max_iter, 1);
    hist_iter_s   = zeros(opcoes.max_iter, 1);
    hist_iter_d   = zeros(opcoes.max_iter, 1);
    hist_tempo    = zeros(opcoes.max_iter, 1);

    % Warm start
    V_guess = [];
    c_guess = [];
    mu_guess = [];

    convergiu = false;
    k_star = 0.5 * (k_a + k_b);

    for it = 1:opcoes.max_iter
        t_step = tic;
        k_cur = 0.5 * (k_a + k_b);

        % 1. Precos competitivos
        r_cur = alpha * A_ptf * (k_cur^(alpha - 1.0)) - delta;
        w_cur = (1.0 - alpha) * A_ptf * (k_cur^alpha);

        % 2. Parametros e preprocessamento
        params_cur   = params_base;
        params_cur.r = r_cur;
        params_cur.w = w_cur;
        modelo_cur   = preprocessamento_modelo_ext(params_cur);

        % 3. Solucao do problema das familias via DC-EGM
        sol_cur = dc_egm_extensao(modelo_cur, opcoes.tol_V, opcoes.tol_c, ...
                                  opcoes.max_iter_solver, V_guess, c_guess, false);

        % Atualizar warm start para solver
        V_guess = sol_cur.V;
        c_guess = sol_cur.c_d;

        % 4. Distribuicao estacionaria via operador de Young (2010)
        op_dist.tol_dist = opcoes.tol_dist;
        op_dist.max_iter = opcoes.max_iter_dist;
        op_dist.mu_init  = mu_guess;
        op_dist.verbose  = false;

        dist_cur = distribuicao_estacionaria(modelo_cur, sol_cur, op_dist);

        % Atualizar warm start para distribuicao
        mu_guess = dist_cur.mu;

        % 5. Agregados macroeconomicos
        agg_cur = agregados_macro(dist_cur, modelo_cur, sol_cur);

        % 6. Excesso de oferta de capital f(k) = K_s / L_s - k
        k_s  = agg_cur.k_supply;
        f_k  = k_s - k_cur;
        erro_rel = abs(f_k) / k_cur;
        tempo_step = toc(t_step);

        % Armazenar historico
        hist_k(it)        = k_cur;
        hist_r(it)        = r_cur;
        hist_w(it)        = w_cur;
        hist_Ks(it)       = agg_cur.K_s;
        hist_Ls(it)       = agg_cur.L_s;
        hist_ks(it)       = k_s;
        hist_fk(it)       = f_k;
        hist_erro_rel(it) = erro_rel;
        hist_iter_s(it)   = sol_cur.iter;
        hist_iter_d(it)   = dist_cur.iteracoes;
        hist_tempo(it)    = tempo_step;

        if opcoes.verbose
            fprintf('%-4d | %-7.4f | %-7.3f | %-7.4f | %-7.4f | %-7.4f | %-9.4f | %+9.4f | %-5d | %-6.2fs\n', ...
                it, k_cur, r_cur * 100, w_cur, agg_cur.K_s, agg_cur.L_s, k_s, f_k, sol_cur.iter, tempo_step);
        end

        % Criterio de parada
        if erro_rel < opcoes.tol_k || abs(f_k) < opcoes.tol_k
            convergiu = true;
            k_star = k_cur;
            break;
        end

        % Bisseccao: se f(k) > 0, ha excesso de oferta de capital -> k_cur eh menor que k*
        if f_k > 0
            k_a = k_cur;
        else
            k_b = k_cur;
        end
        k_star = 0.5 * (k_a + k_b);
    end

    tempo_total = toc(t_total_start);

    % Ajustar vetores de historico para numero real de iteracoes
    n_iters = it;
    historico = struct();
    historico.k        = hist_k(1:n_iters);
    historico.r        = hist_r(1:n_iters);
    historico.w        = hist_w(1:n_iters);
    historico.Ks       = hist_Ks(1:n_iters);
    historico.Ls       = hist_Ls(1:n_iters);
    historico.ks       = hist_ks(1:n_iters);
    historico.fk       = hist_fk(1:n_iters);
    historico.erro_rel = hist_erro_rel(1:n_iters);
    historico.iter_s   = hist_iter_s(1:n_iters);
    historico.iter_d   = hist_iter_d(1:n_iters);
    historico.tempo    = hist_tempo(1:n_iters);

    if opcoes.verbose
        fprintf('------------------------------------------------------------------------\n');
        if convergiu
            fprintf('  CONVERGENCIA ATINGIDA EM %d ITERACOES (Tempo total: %.2f s)\n', n_iters, tempo_total);
            fprintf('  k* = %.6f | r* = %.4f%% | w* = %.6f | K* = %.4f | L* = %.4f\n', ...
                k_star, r_cur * 100, w_cur, agg_cur.K_s, agg_cur.L_s);
            fprintf('  Residuo de Walras: %.2e | Gini: %.4f | Informais: %.2f%% | Formais: %.2f%%\n', ...
                agg_cur.hiato_walras, agg_cur.gini_riqueza, agg_cur.M_I * 100, agg_cur.M_F * 100);
        else
            fprintf('  ATENCAO: LIMITE DE ITERACOES ATINGIDO SEM CONVERGENCIA ESTRITA!\n');
        end
        fprintf('========================================================================\n\n');
    end

    % Consolidar estrutura de equilibrio geral
    eq = struct();
    eq.metodo       = 'DC-EGM';
    eq.k            = k_star;
    eq.r            = r_cur;
    eq.w            = w_cur;
    eq.R            = 1.0 + r_cur;
    eq.K            = agg_cur.K_s;
    eq.L            = agg_cur.L_s;
    eq.L_I          = agg_cur.L_I;
    eq.L_F          = agg_cur.L_F;
    eq.Y            = agg_cur.Y_prod;
    eq.C            = agg_cur.C_s;
    eq.I            = agg_cur.I_deprec;
    eq.G            = agg_cur.G_gov;
    eq.absorcao     = agg_cur.absorcao_total;
    eq.hiato_walras = agg_cur.hiato_walras;
    eq.M_N          = agg_cur.M_N;
    eq.M_I          = agg_cur.M_I;
    eq.M_F          = agg_cur.M_F;
    eq.gini         = agg_cur.gini_riqueza;
    eq.P50          = agg_cur.P50;
    eq.P90          = agg_cur.P90;
    eq.bottom_50    = agg_cur.bottom_50;
    eq.top_10       = agg_cur.top_10;
    eq.top_5        = agg_cur.top_5;
    eq.top_1        = agg_cur.top_1;
    eq.frac_a_min   = agg_cur.frac_a_min;
    eq.frac_a_max   = agg_cur.frac_a_max;
    eq.f_k          = f_k;
    eq.erro_rel     = erro_rel;
    eq.iteracoes    = n_iters;
    eq.convergiu    = convergiu;
    eq.tempo_total  = tempo_total;
    eq.historico    = historico;
    eq.modelo       = modelo_cur;
    eq.solucao      = sol_cur;
    eq.distribuicao = dist_cur;
    eq.agregados    = agg_cur;
end
