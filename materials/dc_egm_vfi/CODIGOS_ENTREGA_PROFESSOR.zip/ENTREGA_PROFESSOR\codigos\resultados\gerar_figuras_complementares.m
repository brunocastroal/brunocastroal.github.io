function gerar_figuras_complementares(pasta_figuras)
% GERAR_FIGURAS_COMPLEMENTARES Gera as 6 figuras complementares (11 a 16)
% a partir dos arquivos .mat e .csv oficiais do projeto, sem recalcular o modelo.
%
% Exporta em PDF vetorial, PNG (300 DPI) e FIG (MATLAB) para:
%   - figuras/ (PDF/, PNG/, FIG/)
%   - ../FIGURAS_FINAL/ (se existir)

    pasta_atual = fileparts(mfilename('fullpath'));
    if isempty(pasta_atual), pasta_atual = pwd; end
    pasta_raiz = pasta_atual;
    for k_up = 1:5
        if isfolder(fullfile(pasta_raiz, 'resultados')) && isfolder(fullfile(pasta_raiz, 'parametros'))
            break;
        end
        pasta_pai = fileparts(pasta_raiz);
        if strcmp(pasta_pai, pasta_raiz), break; end
        pasta_raiz = pasta_pai;
    end

    if nargin < 1 || isempty(pasta_figuras)
        pasta_figuras = fullfile(pasta_raiz, 'figuras');
    end
    if ~exist(pasta_figuras, 'dir')
        mkdir(pasta_figuras);
    end

    % Carregar dados consolidados (somente leitura)
    arq_final = fullfile(pasta_raiz, 'resultados', 'resultados_modelo_final.mat');
    arq_indiv = fullfile(pasta_raiz, 'resultados', 'resultados_solucao_individual.mat');
    arq_csv3  = fullfile(pasta_raiz, 'resultados', 'tabelas', 'tabela3_benchmark_historico_9implementacoes.csv');

    d_fin = load(arq_final);
    d_ind = load(arq_indiv);

    eq_dc       = d_fin.eq_dc;
    eq_vfi      = d_fin.eq_vfi;
    pe_baseline = d_fin.pe_baseline;
    r1600       = d_ind.resultados_fase1.Na_1600;

    % Paleta academica padrao do projeto
    azul_escuro   = [0.08, 0.25, 0.55];
    vermelho_vivo = [0.78, 0.16, 0.16];
    verde_escuro  = [0.10, 0.50, 0.25];
    roxo_escuro   = [0.48, 0.18, 0.58];
    laranja_queim = [0.85, 0.42, 0.08];
    cinza_escuro  = [0.35, 0.35, 0.35];

    % =========================================================================
    % FIGURA 11: POLITICAS DE CONSUMO E POUPANCA (PE CONVERGIDO Na = 1600)
    % =========================================================================
    a1600 = r1600.modelo.a(:);
    z1600 = r1600.modelo.z(:);
    dp_ref = 2; % Estado previo Informal (I)

    f11 = figure('Visible', 'off', 'Color', 'w', 'Position', [80, 80, 1200, 520]);

    % Painel A: Consumo Otimo c*(a, z, d^- = I)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;

    z_idxs = [1, 3, 5];
    cores_z = {azul_escuro, verde_escuro, roxo_escuro};
    nomes_z = {sprintf('z_1 = %.3f (baixa)', z1600(1)), ...
               sprintf('z_3 = %.3f (mediana)', z1600(3)), ...
               sprintf('z_5 = %.3f (alta)', z1600(5))};

    idx_mark = round(linspace(1, length(a1600), 32));
    for k = 1:3
        iz = z_idxs(k);
        plot(a1600, r1600.sol_dc.c_exp(:, iz, dp_ref), '-', 'LineWidth', 2.0, 'Color', cores_z{k}, ...
            'DisplayName', ['DC-EGM: ', nomes_z{k}]);
        plot(a1600(idx_mark), r1600.sol_vfi.c_exp(idx_mark, iz, dp_ref), 'o', 'MarkerSize', 4.5, ...
            'Color', cores_z{k}, 'MarkerFaceColor', 'w', 'LineWidth', 1.1, ...
            'DisplayName', ['VFI: ', nomes_z{k}]);
    end

    % Identificar salto ocupacional I -> N em z_1
    ds_z1 = r1600.sol_dc.d_star(:, 1, dp_ref);
    idx_salto = find(diff(ds_z1) ~= 0, 1, 'last');
    if ~isempty(idx_salto)
        xline(a1600(idx_salto), ':', 'Color', vermelho_vivo, 'LineWidth', 1.3, 'HandleVisibility', 'off');
        text(a1600(idx_salto) - 2.0, 2.35, sprintf('Troca I \\rightarrow N\n(a \\approx %.1f)', a1600(idx_salto)), ...
            'HorizontalAlignment', 'right', 'FontSize', 9, 'FontWeight', 'bold', 'Color', vermelho_vivo, ...
            'BackgroundColor', 'w', 'EdgeColor', vermelho_vivo, 'Margin', 3);
    end

    xlabel('Ativos Iniciais (a)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Consumo Otimo c^*(a, z, d^-=I)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel A: Politica de Consumo (DC-EGM vs VFI)', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8.2, 'NumColumns', 2, 'Color', 'w', 'TextColor', 'k');
    xlim([0, 80]);

    % Painel B: Poupanca Liquida a'(a) - a e Restricao de Credito a' >= 0
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;

    for k = 1:3
        iz = z_idxs(k);
        ap_dc  = r1600.sol_dc.aprime_exp(:, iz, dp_ref);
        ap_vfi = r1600.sol_vfi.aprime_exp(:, iz, dp_ref);
        plot(a1600, ap_dc - a1600, '-', 'LineWidth', 2.0, 'Color', cores_z{k}, ...
            'DisplayName', ['DC-EGM: ', nomes_z{k}]);
        plot(a1600(idx_mark), ap_vfi(idx_mark) - a1600(idx_mark), 'o', 'MarkerSize', 4.5, ...
            'Color', cores_z{k}, 'MarkerFaceColor', 'w', 'LineWidth', 1.1, ...
            'DisplayName', ['VFI: ', nomes_z{k}]);
    end
    yline(0, 'k--', 'LineWidth', 1.2, 'DisplayName', 'Poupanca liquida nula (a'' = a)');
    % Curva da restricao a' = 0 implica a' - a = -a
    plot(a1600(a1600 <= 12), -a1600(a1600 <= 12), ':', 'Color', cinza_escuro, 'LineWidth', 1.5, ...
        'DisplayName', 'Fronteira de endividamento (a'' = 0)');

    if ~isempty(idx_salto)
        xline(a1600(idx_salto), ':', 'Color', vermelho_vivo, 'LineWidth', 1.3, 'HandleVisibility', 'off');
        ap_salto = r1600.sol_dc.aprime_exp(idx_salto, 1, dp_ref) - a1600(idx_salto);
        text(a1600(idx_salto) - 2.0, ap_salto - 0.55, sprintf('Salto discreto\nem a''(a) (z_1)'), ...
            'HorizontalAlignment', 'right', 'FontSize', 9, 'FontWeight', 'bold', 'Color', vermelho_vivo, ...
            'BackgroundColor', 'w', 'EdgeColor', vermelho_vivo, 'Margin', 3);
    end

    xlabel('Ativos Iniciais (a)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Poupanca Liquida a''(a, z, d^-=I) - a', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel B: Poupanca Liquida e Restricao a'' \geq 0', 'FontSize', 11.5, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'southwest', 'FontSize', 8.0, 'NumColumns', 2, 'Color', 'w', 'TextColor', 'k');
    xlim([0, 80]);

    sgtitle('Funcoes Politica de Consumo e Poupanca Liquida — Equilibrio Parcial Convergido (N_a = 1600, \chi = 0.05)', ...
        'FontSize', 12.5, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f11, fullfile(pasta_figuras, 'figura11_politicas_consumo_poupanca.png'));

    % =========================================================================
    % FIGURA 12: MAPA DE ESCOLHAS OCUPACIONAIS d*(a, z, d^-) (PE Na = 1600)
    % =========================================================================
    f12 = figure('Visible', 'off', 'Color', 'w', 'Position', [60, 80, 1280, 500]);

    cmap_ocup = [
        0.92, 0.72, 0.22;  % 1 = N (Inativo)  - Dourado
        0.24, 0.60, 0.78;  % 2 = I (Informal) - Azul Medio
        0.09, 0.24, 0.48   % 3 = F (Formal)   - Azul Marinho
    ];
    titulos_dp = {'d^- = Inativo (N)', 'd^- = Informal (I)', 'd^- = Formal (F)'};

    for dp = 1:3
        subplot(1, 3, dp);
        D_slice = squeeze(r1600.sol_dc.d_star(:, :, dp))'; % [Nz x Na]
        imagesc(a1600, 1:r1600.modelo.Nz, D_slice);
        set(gca, 'YDir', 'normal', 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
        colormap(gca, cmap_ocup);
        caxis([0.5, 3.5]);
        hold on; box on;

        % Linhas horizontais separadoras de z
        for iz = 1.5:1:(r1600.modelo.Nz - 0.5)
            yline(iz, 'Color', [1, 1, 1], 'LineWidth', 0.8);
        end

        % Anotar transicoes horizontais dentro de z_1
        row_z1 = D_slice(1, :);
        idxs_tr = find(diff(row_z1) ~= 0);
        for tr = idxs_tr
            a_lim = a1600(tr);
            plot([a_lim, a_lim], [0.5, 1.5], 'k--', 'LineWidth', 1.3);
            text(a_lim, 1.0, sprintf('%.1f', a_lim), 'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', 'FontSize', 8, 'FontWeight', 'bold', ...
                'Color', 'k', 'BackgroundColor', 'w', 'Margin', 1.5);
        end

        set(gca, 'YTick', 1:r1600.modelo.Nz, ...
            'YTickLabel', arrayfun(@(x) sprintf('z_%d (%.2f)', x, z1600(x)), 1:r1600.modelo.Nz, 'UniformOutput', false));
        xlabel('Ativos Iniciais (a)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
        if dp == 1
            ylabel('Choque de Produtividade (z)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
        end
        title(['Estado Previo: ', titulos_dp{dp}], 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    end

    % Legenda global limpa no rodape da figura
    ax_leg = axes('Position', [0.20, 0.015, 0.60, 0.045], 'Visible', 'off');
    hold(ax_leg, 'on');
    patch(ax_leg, [NaN NaN NaN NaN], [NaN NaN NaN NaN], cmap_ocup(1,:), 'EdgeColor', 'k', 'DisplayName', 'Inativo (N)');
    patch(ax_leg, [NaN NaN NaN NaN], [NaN NaN NaN NaN], cmap_ocup(2,:), 'EdgeColor', 'k', 'DisplayName', 'Informal (I)');
    patch(ax_leg, [NaN NaN NaN NaN], [NaN NaN NaN NaN], cmap_ocup(3,:), 'EdgeColor', 'k', 'DisplayName', 'Formal (F)');
    lg12 = legend(ax_leg, 'Orientation', 'horizontal', 'Location', 'south', 'FontSize', 10, 'Box', 'on', 'Color', 'w', 'TextColor', 'k');
    % Ajustar altura dos 3 subplots para evitar colisao com sgtitle e legenda global
    axs12 = findall(f12, 'Type', 'axes');
    for k = 1:length(axs12)
        if axs12(k) ~= ax_leg
            pos = axs12(k).Position;
            pos(2) = pos(2) + 0.055;
            pos(4) = pos(4) - 0.115;
            axs12(k).Position = pos;
        end
    end

    sgtitle('Mapa de Escolhas Ocupacionais d^*(a, z, d^-) — Efeito Renda e Histerese por \chi = 0.05 (EP, N_a = 1600)', ...
        'FontSize', 12.2, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f12, fullfile(pasta_figuras, 'figura12_mapa_escolhas_ocupacionais.png'));

    % =========================================================================
    % FIGURA 13: DISTRIBUICAO ESTACIONARIA DE RIQUEZA POR OCUPACAO (EP vs EG)
    % =========================================================================
    f13 = figure('Visible', 'off', 'Color', 'w', 'Position', [80, 80, 1200, 520]);

    % Painel A: Equilibrio Parcial (bins largos de riqueza [0, 80], delta=4)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;

    edges_pe = 0:4:80;
    centros_pe = edges_pe(1:end-1) + 2;
    [M_bins_pe, stats_pe] = agregar_bins_ocupacao(pe_baseline.modelo.a(:), ...
        pe_baseline.distribuicao.mu, pe_baseline.solucao.d_star, edges_pe);

    b_pe = bar(centros_pe, M_bins_pe * 100, 1.0, 'stacked');
    b_pe(1).FaceColor = laranja_queim; b_pe(1).EdgeColor = 'k';
    b_pe(2).FaceColor = [0.24, 0.60, 0.78]; b_pe(2).EdgeColor = 'k';
    b_pe(3).FaceColor = azul_escuro; b_pe(3).EdgeColor = 'k';

    xline(stats_pe.media_a(2), '--', 'Color', [0.10, 0.35, 0.55], 'LineWidth', 1.5, 'HandleVisibility', 'off');
    xline(stats_pe.media_a(1), ':',  'Color', [0.75, 0.32, 0.05], 'LineWidth', 1.5, 'HandleVisibility', 'off');

    xlabel('Faixas de Riqueza (a \in [0, 80])', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Massa de Probabilidade por Faixa (%)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'Painel A: Equilibrio Parcial (r = 4.17%, w = 1.18)', ...
           sprintf('M_N=%.1f%% (a=%.1f) | M_I=%.1f%% (a=%.1f) | M_F=%.1f%% (a=%.1f)', ...
           stats_pe.massa(1)*100, stats_pe.media_a(1), ...
           stats_pe.massa(2)*100, stats_pe.media_a(2), ...
           stats_pe.massa(3)*100, stats_pe.media_a(3))}, ...
          'FontSize', 10.2, 'FontWeight', 'bold', 'Color', 'k');
    legend({'Inativos (N)', 'Informais (I)', 'Formais (F)'}, 'Location', 'northwest', 'FontSize', 9.5, 'Color', 'w', 'TextColor', 'k');
    xlim([0, 80]);

    % Painel B: Equilibrio Geral DC-EGM (bins finos [0, 34], delta=2)
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;

    edges_eg = 0:2:34;
    centros_eg = edges_eg(1:end-1) + 1;
    [M_bins_eg, stats_eg] = agregar_bins_ocupacao(eq_dc.modelo.a(:), ...
        eq_dc.distribuicao.mu, eq_dc.solucao.d_star, edges_eg);

    b_eg = bar(centros_eg, M_bins_eg * 100, 1.0, 'stacked');
    b_eg(1).FaceColor = laranja_queim; b_eg(1).EdgeColor = 'k';
    b_eg(2).FaceColor = [0.24, 0.60, 0.78]; b_eg(2).EdgeColor = 'k';
    b_eg(3).FaceColor = azul_escuro; b_eg(3).EdgeColor = 'k';

    xline(stats_eg.media_a(3), '--', 'Color', azul_escuro, 'LineWidth', 1.5, 'HandleVisibility', 'off');
    xline(stats_eg.media_a(2), ':',  'Color', [0.10, 0.45, 0.62], 'LineWidth', 1.6, 'HandleVisibility', 'off');
    text(stats_eg.media_a(2) + 0.6, max(sum(M_bins_eg, 2)*100) * 0.42, ...
        sprintf('Informais\n(M_I = %.2f%%,\nmedia a = %.1f)', stats_eg.massa(2)*100, stats_eg.media_a(2)), ...
        'FontSize', 9, 'FontWeight', 'bold', 'Color', [0.10, 0.40, 0.58], 'BackgroundColor', 'w', 'EdgeColor', [0.10, 0.40, 0.58], 'Margin', 3);

    xlabel('Faixas de Riqueza (a \in [0, 34], P_{99} = 26.7)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Massa de Probabilidade por Faixa (%)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    title({'Painel B: Equilibrio Geral DC-EGM (r* = 2.80%, w* = 1.26)', ...
           sprintf('M_N=%.2f%% | M_I=%.2f%% (a=%.1f) | M_F=%.2f%% (a=%.1f) | Gini=%.4f', ...
           stats_eg.massa(1)*100, stats_eg.massa(2)*100, stats_eg.media_a(2), ...
           stats_eg.massa(3)*100, stats_eg.media_a(3), eq_dc.gini)}, ...
          'FontSize', 10.2, 'FontWeight', 'bold', 'Color', 'k');
    legend({'Inativos (N)', 'Informais (I)', 'Formais (F)'}, 'Location', 'northeast', 'FontSize', 9.5, 'Color', 'w', 'TextColor', 'k');
    xlim([0, 34]);

    sgtitle('Distribuicao Estacionaria de Riqueza Decomposta por Ocupacao Escolhida d^* (N_a = 400)', ...
        'FontSize', 12.5, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f13, fullfile(pasta_figuras, 'figura13_distribuicao_por_ocupacao.png'));

    % =========================================================================
    % FIGURA 14: ANATOMIA DO UPPER ENVELOPE NA DOBRA INTERIOR (Na = 1600)
    % =========================================================================
    iz_d = 2; id_d = 2;
    a_endo = r1600.res_endo.a_endo_tensor(:, iz_d, id_d);
    c_endo = r1600.res_endo.c_endo_tensor(:, iz_d, id_d);
    W_vec  = r1600.sol_dc.W(:, iz_d, id_d);
    psi_d  = r1600.modelo.params.psi(id_d);
    sigma  = r1600.modelo.params.sigma;
    R_pe   = r1600.modelo.R;
    y_dz   = r1600.modelo.y(iz_d, id_d);

    idxs_neg = find(diff(a_endo) < -1e-8);
    k_ini = idxs_neg(1);
    k_fim = k_ini;
    while k_fim < length(a_endo)-1 && (a_endo(k_fim+2) - a_endo(k_fim+1)) < -1e-8
        k_fim = k_fim + 1;
    end
    idx_ramo1 = 1:k_ini;
    idx_inv   = k_ini:(k_fim+1);
    idx_ramo2 = (k_fim+1):length(a_endo);

    a_ov_min = min(a_endo(idx_inv));
    a_ov_max = max(a_endo(idx_inv));
    a_win_min = a_ov_min - 0.03;
    a_win_max = a_ov_max + 0.03;

    f14 = figure('Visible', 'off', 'Color', 'w', 'Position', [50, 80, 1340, 490]);

    % Painel A: Grade endogena nao-monotonica a_endo(a')
    subplot(1, 3, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    j_lo = max(1, k_ini - 12);
    j_hi = min(length(a1600), k_fim + 13);
    r1_loc = intersect(idx_ramo1, j_lo:j_hi);
    r2_loc = intersect(idx_ramo2, j_lo:j_hi);

    patch([a1600(r1_loc(1)), a1600(r2_loc(end)), a1600(r2_loc(end)), a1600(r1_loc(1))], ...
          [a_ov_min, a_ov_min, a_ov_max, a_ov_max], [0.95, 0.90, 0.70], 'FaceAlpha', 0.45, ...
          'EdgeColor', 'none', 'DisplayName', sprintf('Faixa multivalorada [%.3f, %.3f]', a_ov_min, a_ov_max));
    plot(a1600(r1_loc), a_endo(r1_loc), 'o-', 'Color', azul_escuro, 'LineWidth', 2.0, 'MarkerSize', 4.5, ...
        'MarkerFaceColor', azul_escuro, 'DisplayName', 'Ramo crescente 1 (pre-dobra)');
    plot(a1600(idx_inv), a_endo(idx_inv), 'x--', 'Color', vermelho_vivo, 'LineWidth', 2.2, 'MarkerSize', 8, ...
        'DisplayName', 'Inversao (da_{endo}/da'' < 0, descartada)');
    plot(a1600(r2_loc), a_endo(r2_loc), 's-', 'Color', verde_escuro, 'LineWidth', 2.0, 'MarkerSize', 4.5, ...
        'MarkerFaceColor', verde_escuro, 'DisplayName', 'Ramo crescente 2 (pos-dobra)');

    xlabel('Ativos Futuros a'' (grade de controle)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Ativos Iniciais Endogenos a_{endo}(a'')', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel A: Dobra na Grade Endogena', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8.0, 'Color', 'w', 'TextColor', 'k');
    xlim([a1600(j_lo), a1600(j_hi)]);

    % Painel B: Cruzamento de Valores dos Ramos estritamente nos dominios validos
    subplot(1, 3, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    a_f1 = linspace(a_win_min, a_endo(idx_ramo1(end)) - 1e-7, 250)';
    c1_f = interp1(a_endo(idx_ramo1), c_endo(idx_ramo1), a_f1, 'linear');
    ap1_f = max(a1600(1), min(a1600(end), R_pe * a_f1 + y_dz - c1_f));
    v1_f = utilidade_crra(c1_f, sigma) - psi_d + interp1(a1600, W_vec, ap1_f, 'linear');

    a_f2 = linspace(a_endo(idx_ramo2(1)) + 1e-7, a_win_max, 250)';
    c2_f = interp1(a_endo(idx_ramo2), c_endo(idx_ramo2), a_f2, 'linear');
    ap2_f = max(a1600(1), min(a1600(end), R_pe * a_f2 + y_dz - c2_f));
    v2_f = utilidade_crra(c2_f, sigma) - psi_d + interp1(a1600, W_vec, ap2_f, 'linear');

    % Referencia linear tangente comum baseada nos extremos finitos da faixa de sobreposicao
    a_ov = linspace(a_endo(idx_ramo2(1)) + 1e-7, a_endo(idx_ramo1(end)) - 1e-7, 300)';
    v1_ov = interp1(a_f1, v1_f, a_ov, 'linear');
    v2_ov = interp1(a_f2, v2_f, a_ov, 'linear');
    slope_ref = (v2_ov(end) - v1_ov(1)) / (a_ov(end) - a_ov(1));
    v0_ref = 0.5 * (v1_ov(1) + v2_ov(1));

    dv1 = (v1_f - (v0_ref + slope_ref * (a_f1 - a_ov(1)))) * 1e4;
    dv2 = (v2_f - (v0_ref + slope_ref * (a_f2 - a_ov(1)))) * 1e4;
    dv1_ov = (v1_ov - (v0_ref + slope_ref * (a_ov - a_ov(1)))) * 1e4;
    dv2_ov = (v2_ov - (v0_ref + slope_ref * (a_ov - a_ov(1)))) * 1e4;

    [~, idx_cross] = min(abs(dv1_ov - dv2_ov));
    a_cross = a_ov(idx_cross);
    dv_cross = dv1_ov(idx_cross);

    a_env = [a_f1(a_f1 <= a_cross); a_f2(a_f2 >= a_cross)];
    dv_env = [dv1(a_f1 <= a_cross); dv2(a_f2 >= a_cross)];

    plot(a_f1, dv1, '--', 'Color', azul_escuro, 'LineWidth', 1.8, 'DisplayName', 'Ramo 1: \Delta v_1(a)');
    plot(a_f2, dv2, '-.', 'Color', verde_escuro, 'LineWidth', 1.8, 'DisplayName', 'Ramo 2: \Delta v_2(a)');
    plot(a_env, dv_env, '-', 'Color', 'k', 'LineWidth', 2.8, 'DisplayName', 'Upper Envelope max_r \Delta v_r');
    plot(a_cross, dv_cross, 'p', 'MarkerSize', 12, 'MarkerFaceColor', vermelho_vivo, ...
        'MarkerEdgeColor', 'k', 'DisplayName', sprintf('Ponto de troca (a* = %.4f)', a_cross));

    xlabel('Ativos Iniciais (a)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('\Delta v_r(a) = [v_r(a) - v_{lin}(a)] \times 10^4', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel B: Cruzamento de Ramos (Upper Envelope)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'north', 'FontSize', 8.0, 'Color', 'w', 'TextColor', 'k');
    xlim([a_win_min, a_win_max]);

    % Painel C: Politica de Consumo Poda Pos-Envelope c_d(a) em janela ampla
    subplot(1, 3, 3);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10, 'LineWidth', 1.0);
    hold on; box on; grid on;

    a_w1 = linspace(a_ov_min - 0.14, a_endo(idx_ramo1(end)) - 1e-7, 250)';
    c1_w = interp1(a_endo(idx_ramo1), c_endo(idx_ramo1), a_w1, 'linear');
    a_w2 = linspace(a_endo(idx_ramo2(1)) + 1e-7, a_ov_max + 0.14, 250)';
    c2_w = interp1(a_endo(idx_ramo2), c_endo(idx_ramo2), a_w2, 'linear');

    plot(a_w1, c1_w, '--', 'Color', azul_escuro, 'LineWidth', 1.6, 'DisplayName', 'Consumo Ramo 1 (continuo)');
    plot(a_w2, c2_w, '-.', 'Color', verde_escuro, 'LineWidth', 1.6, 'DisplayName', 'Consumo Ramo 2 (continuo)');

    mask_zoom = (a1600 >= a_ov_min - 0.14) & (a1600 <= a_ov_max + 0.14);
    plot(a1600(mask_zoom), r1600.sol_dc.c_d(mask_zoom, iz_d, id_d), 'ko-', 'LineWidth', 2.0, ...
        'MarkerSize', 5, 'MarkerFaceColor', laranja_queim, 'DisplayName', 'Politica final na grade c_d(a)');
    xline(a_cross, ':', 'Color', vermelho_vivo, 'LineWidth', 1.4, ...
        'DisplayName', sprintf('Descontinuidade (a* = %.3f)', a_cross));

    xlabel('Ativos Iniciais (a)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Consumo Condicional c_d(a, z_2, d=I)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel C: Poda e Salto em Consumo', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 8.0, 'Color', 'w', 'TextColor', 'k');
    xlim([a_ov_min - 0.14, a_ov_max + 0.14]);

    sgtitle(sprintf('Anatomia do Upper Envelope na Dobra Interior — N_a = 1600, z = z_2 (%.3f), d = Informal (EP)', z1600(iz_d)), ...
        'FontSize', 12.2, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f14, fullfile(pasta_figuras, 'figura14_upper_envelope_dobras.png'));

    % =========================================================================
    % FIGURA 15: EXCESSO DE DEMANDA DE CAPITAL & CONVERGENCIA COMPARATIVA (EG)
    % =========================================================================
    f15 = figure('Visible', 'off', 'Color', 'w', 'Position', [80, 80, 1200, 520]);

    % Painel A: Excesso de Demanda Ks(r) - Kd(r) vs Taxa de Juros r (%)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;

    alpha_p = eq_dc.modelo.params.alpha;
    delta_p = eq_dc.modelo.params.delta;
    A_p     = eq_dc.modelo.params.A;

    hdc = eq_dc.historico;
    Kd_dc_hist = hdc.Ls .* ((hdc.r + delta_p) / (alpha_p * A_p)).^(1.0 / (alpha_p - 1.0));
    exc_dc = hdc.Ks - Kd_dc_hist;
    [r_dc_s, id_dc] = sort(hdc.r * 100);

    hvfi = eq_vfi.historico;
    Kd_vfi_hist = hvfi.Ls .* ((hvfi.r + delta_p) / (alpha_p * A_p)).^(1.0 / (alpha_p - 1.0));
    exc_vfi = hvfi.Ks - Kd_vfi_hist;
    [r_vfi_s, id_vfi] = sort(hvfi.r * 100);

    plot(r_dc_s, exc_dc(id_dc), 'o-', 'Color', azul_escuro, 'LineWidth', 2.1, 'MarkerSize', 6, ...
        'MarkerFaceColor', azul_escuro, 'DisplayName', 'DC-EGM: K_s(r) - K_d(r) (11 iter.)');
    plot(r_vfi_s, exc_vfi(id_vfi), 's--', 'Color', vermelho_vivo, 'LineWidth', 1.8, 'MarkerSize', 5.5, ...
        'MarkerFaceColor', 'w', 'DisplayName', 'VFI: K_s(r) - K_d(r) (15 iter.)');
    yline(0, 'k:', 'LineWidth', 1.3, 'DisplayName', 'Fechamento de Mercado (Excesso = 0)');

    plot(eq_dc.r * 100, 0, 'p', 'MarkerSize', 13, 'MarkerFaceColor', verde_escuro, 'MarkerEdgeColor', 'k', ...
        'DisplayName', sprintf('r*_{DC} = %.4f%%', eq_dc.r * 100));
    plot(eq_vfi.r * 100, 0, 'd', 'MarkerSize', 8, 'MarkerFaceColor', laranja_queim, 'MarkerEdgeColor', 'k', ...
        'DisplayName', sprintf('r*_{VFI} = %.4f%%', eq_vfi.r * 100));

    xlabel('Taxa Real de Juros r (%)  [Intervalo inicial k \in [6.00, 7.50]]', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Excesso de Oferta de Capital: K_s(r) - K_d(r)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel A: Excesso de Capital vs Taxa de Juros (EG, N_a=400)', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northwest', 'FontSize', 8.5, 'Color', 'w', 'TextColor', 'k');

    % Painel B: Convergencia Comparativa da Bissecao |f(k)|/k em escala logaritmica
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0, 'YScale', 'log');
    hold on; box on; grid on;

    semilogy(1:length(hdc.erro_rel), hdc.erro_rel, 'o-', 'Color', azul_escuro, 'LineWidth', 2.1, ...
        'MarkerFaceColor', azul_escuro, 'DisplayName', sprintf('DC-EGM (11 it., erro final %.2e)', hdc.erro_rel(end)));
    semilogy(1:length(hvfi.erro_rel), hvfi.erro_rel, 's--', 'Color', vermelho_vivo, 'LineWidth', 1.8, ...
        'MarkerFaceColor', 'w', 'DisplayName', sprintf('VFI (15 it., erro final %.2e)', hvfi.erro_rel(end)));
    yline(1e-4, ':', 'Color', verde_escuro, 'LineWidth', 1.6, 'DisplayName', 'Tolerancia de Mercado (10^{-4})');
    set(gca, 'YScale', 'log');

    xlabel({'Iteracao Externa da Bissecao de Equilibrio Geral', ...
            'Nota: historico por iteracao interna de Bellman nao armazenado nos .mat'}, ...
        'FontSize', 10, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Erro Relativo de Mercado |f(k)| / k (escala log)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel B: Convergencia Externa do Equilibrio Geral', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 8.8, 'Color', 'w', 'TextColor', 'k');
    xlim([0.5, max(length(hdc.erro_rel), length(hvfi.erro_rel)) + 0.5]);
    ylim([5e-5, 0.5]);

    sgtitle('Fechamento do Mercado de Capitais e Convergencia do Equilibrio Geral — DC-EGM vs VFI', ...
        'FontSize', 12.5, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f15, fullfile(pasta_figuras, 'figura15_excesso_demanda_capital.png'));

    % =========================================================================
    % FIGURA 16: FRONTEIRA TEMPO-PRECISAO (BENCHMARK HISTORICO COMPLEMENTAR)
    % =========================================================================
    if exist(arq_csv3, 'file')
        T3 = readtable(arq_csv3, 'Delimiter', ',');
        nomes_imp  = T3.Implementacao;
        tempo_med  = T3.Mediana_s;
        euler_err  = T3.Euler_Erro_Consumo;
        bell_mae   = T3.Bellman_MAE;
    else
        error('Arquivo tabela3_benchmark_historico_9implementacoes.csv nao encontrado em %s', arq_csv3);
    end

    f16 = figure('Visible', 'off', 'Color', 'w', 'Position', [60, 80, 1280, 550]);

    is_dc = contains(nomes_imp, 'DC-EGM');

    % Painel A: Mediana de Tempo vs Erro de Euler Consumo (Log-Log)
    subplot(1, 2, 1);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;
    set(gca, 'XScale', 'log', 'YScale', 'log');

    scatter(tempo_med(~is_dc), euler_err(~is_dc), 75, vermelho_vivo, 's', 'filled', ...
        'MarkerEdgeColor', 'k', 'DisplayName', 'Variantes VFI (7 implementacoes)');
    scatter(tempo_med(is_dc), euler_err(is_dc), 110, azul_escuro, 'd', 'filled', ...
        'MarkerEdgeColor', 'k', 'DisplayName', 'Variantes DC-EGM (2 implementacoes)');

    idx_dc_opt = find(strcmp(nomes_imp, 'DC-EGM Otimizado'), 1);
    if ~isempty(idx_dc_opt)
        plot(tempo_med(idx_dc_opt), euler_err(idx_dc_opt), 'o', 'MarkerSize', 15, ...
            'Color', verde_escuro, 'LineWidth', 2.0, 'DisplayName', 'Fronteira Pareto: DC-EGM Otimizado');
    end

    desloc_A = containers.Map( ...
        {'DC-EGM Otimizado', 'DC-EGM Padrao', 'VFI Monotonicidade (400)', 'VFI Vetorizada (400)', ...
         'VFI Refinada (400 cand)', 'VFI Forca Bruta (400)', 'VFI Refinada (800 cand)', ...
         'VFI Refinada (1600 cand)', 'VFI Refinada (3200 cand)'}, ...
        {[0.72, 2.35], [0.46, 2.05], [0.85, 1.48], [0.68, 0.56], ...
         [0.85, 0.45], [1.08, 1.55], [1.05, 1.55], [0.45, 0.48], [0.35, 0.46]});

    rotulos_curtos = {'DC-EGM Otim. (1.66s | 7.18e-7)', 'VFI Monot.', 'VFI Vet.', 'VFI 400c', ...
        'VFI Bruta', 'VFI 800c', 'VFI 1600c', 'DC-EGM Padrao (49.1s)', 'VFI 3200c (91.1s | 1.88e-3)'};

    for i = 1:length(nomes_imp)
        nm = nomes_imp{i};
        if isKey(desloc_A, nm)
            fac = desloc_A(nm);
        else
            fac = [1.15, 1.15];
        end
        lbl = rotulos_curtos{i};
        text(tempo_med(i) * fac(1), euler_err(i) * fac(2), lbl, ...
            'FontSize', 8.2, 'FontWeight', 'bold', 'Color', 'k');
    end

    xlabel('Tempo Mediano de Execucao (s, escala log)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Erro de Euler Consumo Equiv. MAE (escala log)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel A: Precisao de Primeira Ordem (Euler) vs Tempo', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'west', 'FontSize', 8.2, 'Color', 'w', 'TextColor', 'k');
    xlim([1.0, 200]); ylim([2e-7, 4e-2]);

    % Painel B: Mediana de Tempo vs Bellman MAE (Log-Log)
    subplot(1, 2, 2);
    set(gca, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', 'FontSize', 10.5, 'LineWidth', 1.0);
    hold on; box on; grid on;
    set(gca, 'XScale', 'log', 'YScale', 'log');

    scatter(tempo_med(~is_dc), bell_mae(~is_dc), 75, vermelho_vivo, 's', 'filled', ...
        'MarkerEdgeColor', 'k', 'DisplayName', 'Variantes VFI');
    scatter(tempo_med(is_dc), bell_mae(is_dc), 110, azul_escuro, 'd', 'filled', ...
        'MarkerEdgeColor', 'k', 'DisplayName', 'Variantes DC-EGM');

    rotulos_B = {'DC-EGM Otim. (3.56e-5)', 'VFI Monot.', 'VFI Vet.', 'VFI 400c', ...
        'VFI Bruta', 'VFI 800c (1.68e-4)', 'VFI 1600c (4.50e-5)', 'DC-EGM Padrao', 'VFI 3200c (2.92e-5)'};
    desloc_B = containers.Map( ...
        {'DC-EGM Otimizado', 'DC-EGM Padrao', 'VFI Monotonicidade (400)', 'VFI Vetorizada (400)', ...
         'VFI Refinada (400 cand)', 'VFI Forca Bruta (400)', 'VFI Refinada (800 cand)', ...
         'VFI Refinada (1600 cand)', 'VFI Refinada (3200 cand)'}, ...
        {[1.12, 0.70], [0.35, 0.65], [0.75, 1.38], [0.78, 0.62], ...
         [0.90, 1.38], [1.12, 1.30], [1.15, 1.25], [0.32, 1.45], [0.38, 0.48]});

    for i = 1:length(nomes_imp)
        nm = nomes_imp{i};
        if isKey(desloc_B, nm)
            fac = desloc_B(nm);
        else
            fac = [1.15, 1.15];
        end
        text(tempo_med(i) * fac(1), bell_mae(i) * fac(2), rotulos_B{i}, ...
            'FontSize', 8.2, 'FontWeight', 'bold', 'Color', 'k');
    end

    xlabel('Tempo Mediano de Execucao (s, escala log)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    ylabel('Erro Medio Absoluto de Bellman MAE (escala log)', 'FontSize', 10.5, 'FontWeight', 'bold', 'Color', 'k');
    title('Painel B: Erro de Bellman (MAE) vs Tempo', 'FontSize', 11, 'FontWeight', 'bold', 'Color', 'k');
    legend('Location', 'northeast', 'FontSize', 8.5, 'Color', 'w', 'TextColor', 'k');
    xlim([1.0, 200]); ylim([1e-5, 3e-3]);

    sgtitle({'Fronteira Tempo-Precisao — Benchmark Historico Complementar (\chi = 0, Modelo Preliminar, 9 Implementacoes)', ...
             'N_a = 400 (7 repeticoes estatisticas) | Nao confundir com o modelo canonico \chi = 0.05'}, ...
        'FontSize', 12, 'FontWeight', 'bold', 'Color', 'k');

    salvar_figura(f16, fullfile(pasta_figuras, 'figura16_fronteira_tempo_precisao_historico.png'));

    fprintf('Todas as 6 figuras complementares (11 a 16) foram geradas com sucesso em:\n  %s\n', pasta_figuras);
end


function [M_bins, stats] = agregar_bins_ocupacao(a_grid, mu, dstar, edges)
    nb = length(edges) - 1;
    M_bins = zeros(nb, 3);
    stats.massa = zeros(1, 3);
    stats.media_a = zeros(1, 3);
    [~, Nz, Nd] = size(mu);
    a_3d = repmat(a_grid, [1, Nz, Nd]);

    for d = 1:3
        mask_d = (dstar == d);
        stats.massa(d) = sum(mu(mask_d));
        if stats.massa(d) > 0
            stats.media_a(d) = sum(a_3d(mask_d) .* mu(mask_d)) / stats.massa(d);
        else
            stats.media_a(d) = NaN;
        end
        for b = 1:nb
            if b == 1
                in_b = (a_grid >= edges(b)) & (a_grid <= edges(b+1));
            else
                in_b = (a_grid > edges(b)) & (a_grid <= edges(b+1));
            end
            mask_b = mask_d & repmat(in_b, [1, Nz, Nd]);
            M_bins(b, d) = sum(mu(mask_b));
        end
    end
end


function salvar_figura(fig_handle, caminho_arquivo)
    [pasta, nome, ~] = fileparts(caminho_arquivo);

    % 1. PNG em 300 DPI na pasta local (figuras/)
    arq_png = fullfile(pasta, [nome, '.png']);
    if exist(arq_png, 'file')
        try, delete(arq_png); catch, pause(0.2); try, delete(arq_png); catch, end, end
    end
    exportgraphics(fig_handle, arq_png, 'Resolution', 300);

    % 2. Exportacoes estruturadas
    pasta_raiz = fileparts(pasta);
    locais_pdf = {fullfile(pasta, 'PDF')};
    locais_png = {fullfile(pasta, 'PNG')};
    locais_fig = {fullfile(pasta, 'FIG')};

    pasta_ff = fullfile(pasta_raiz, '..', 'FIGURAS_FINAL');
    if exist(pasta_ff, 'dir')
        locais_pdf{end+1} = fullfile(pasta_ff, 'PDF');
        locais_png{end+1} = fullfile(pasta_ff, 'PNG');
        locais_fig{end+1} = fullfile(pasta_ff, 'FIG');
    end

    for i = 1:length(locais_pdf)
        p_pdf = locais_pdf{i};
        p_png = locais_png{i};
        p_fig = locais_fig{i};
        if ~exist(p_pdf, 'dir'), mkdir(p_pdf); end
        if ~exist(p_png, 'dir'), mkdir(p_png); end
        if ~exist(p_fig, 'dir'), mkdir(p_fig); end

        arq_pdf = fullfile(p_pdf, [nome, '.pdf']);
        if exist(arq_pdf, 'file'), try, delete(arq_pdf); catch, end, end
        exportgraphics(fig_handle, arq_pdf, 'ContentType', 'vector');

        arq_png_dest = fullfile(p_png, [nome, '.png']);
        if exist(arq_png_dest, 'file'), try, delete(arq_png_dest); catch, end, end
        copyfile(arq_png, arq_png_dest);

        arq_fig = fullfile(p_fig, [nome, '.fig']);
        if exist(arq_fig, 'file'), try, delete(arq_fig); catch, end, end
        savefig(fig_handle, arq_fig);
    end

    close(fig_handle);
end
