function sol = dc_egm_solver(modelo, tol_V, tol_c, max_iter)
% DC_EGM_SOLVER Solucionador do Discrete-Continuous EGM com Upper Envelope.
%
% Sintaxe:
%   sol = dc_egm_solver(modelo)
%   sol = dc_egm_solver(modelo, tol_V, tol_c, max_iter)

    if nargin < 2 || isempty(tol_V),   tol_V = 1e-7;   end
    if nargin < 3 || isempty(tol_c),   tol_c = 1e-6;   end
    if nargin < 4 || isempty(max_iter), max_iter = 1500; end

    sol = dc_egm_extensao(modelo, tol_V, tol_c, max_iter);
end
