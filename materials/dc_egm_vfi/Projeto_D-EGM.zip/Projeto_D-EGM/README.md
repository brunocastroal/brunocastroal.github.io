# Pacote de Entrega: Modelo de Agentes Heterogêneos com Escolhas Ocupacionais e Custos de Transição

**Uma Comparação entre VFI e DC-EGM com *Upper Envelope***  
*Disciplina: Economia Computacional / Macroeconomia Quantitativa*  
*Nível: Pós-Graduação em Economia (FEARP/USP)*  
*Autor: Bruno Castro Alves*  
*Data: 18 de novembro de 2026*  
*Ambiente de Referência: MATLAB R2026b Update 1 (compatível com R2020b+)*

---

## 1. Visão Geral

Este pacote reúne código-fonte em MATLAB, calibração, resultados armazenados (`.mat`, `.csv`, `.xlsx`), figuras em três formatos (`PDF`, `PNG`, `FIG`) e documentação completa (incluindo a apresentação final de **64 slides** em `documentacao/APRESENTACAO_COMPLETA.pdf`) comparando dois métodos para modelos de mercados incompletos com escolha contínua de poupança ($a' \ge 0$) e escolha discreta de ocupação ($d \in \{N, I, F\}$):

1. **Value Function Iteration (VFI) Vetorizada:** busca direta exaustiva em grade discreta $(a, a')$.
2. **Discrete-Continuous Endogenous Grid Method (DC-EGM) com *Upper Envelope*:** extensão de Carroll (2006) e Iskhakov et al. (2017) com inversão analítica da Equação de Euler e poda geométrica para lidar com quebras de concavidade local induzidas por custos fixos de transição ocupacional.

---

## 2. Parametrização Canônica e Convenção de Chamada

A configuração canônica da entrega adota utilidade CRRA $u(c) = \frac{c^{1-\sigma}-1}{1-\sigma}$ ($\sigma = 2{,}00$, $\beta = 0{,}96$), desutilidades $\psi = (0;\, 0{,}05;\, 0{,}08)$, informalidade $\kappa = 0{,}72$, imposto formal $\tau = 0{,}20$, grade uniforme $a \in [0, 80]$ e processo Rouwenhorst ($N_z = 5, \rho_z = 0{,}90, \sigma_{\varepsilon,z} = 0{,}20$), sob o regime determinístico com atrito de transição:

$$
\boxed{\bar\chi = 0{,}05, \qquad s_\varepsilon = 0{,}00}
$$

- **`parametros_modelo(Na, chi_bar)`:** utiliza **`chi_bar = 0.05`** (e `scale_eps = 0.00`, `Na = 400`) por padrão, reproduzindo diretamente a configuração canônica.
- **`parametros_modelo_ext(scale_eps, chi_bar, Na)`:** utiliza **`chi_bar = 0.00`** e `scale_eps = 0.00` quando chamada sem argumentos (usada originalmente no estudo preliminar sem atrito). Ao chamá-la diretamente para o modelo principal, informe **`parametros_modelo_ext(0.00, 0.05, Na)`**.

> *Nota de escopo (calibração ilustrativa):* conforme destacado nos slides (`3.8`, `4.18`, `5.3`), os resultados agregados em equilíbrio geral ($\approx 98{,}28\%$ de formalidade e massa desprezível de inativos) decorrem dessa parametrização ilustrativa e **não** representam estimação empírica do mercado de trabalho brasileiro.

---

## 3. Início Rápido (Instruções de Execução)

1. Abra o **MATLAB**, defina o *Current Folder* na raiz do pacote (`Projeto_D-EGM/`):
   ```matlab
   cd('caminho/para/Projeto_D-EGM')
   ```
2. Execute no *Command Window* (ou clique em **Run / F5** em `executar_projeto.m`; a detecção de raiz também suporta *Run Section / F9* quando a pasta ou aba do projeto estiver ativa):
   ```matlab
   executar_projeto
   ```
3. Selecione o modo desejado:
   - **Opção `[1]` — Validação Rápida (padrão, ~35–60 s):** carrega os arquivos `.mat` oficiais de `resultados/`, executa a suíte de **11 testes formais**, exporta as **16 figuras** (`PDF/`, `PNG/` e `FIG/`) e regenera as tabelas CSV em `resultados/tabelas/`.
   - **Opção `[2]` — Reprodução Completa em EG (~40–95 s):** resolve DC-EGM e VFI vetorizada do zero em Equilíbrio Parcial e Equilíbrio Geral ($N_a=400$), reutiliza `resultados_solucao_individual.mat` para o multigrade e atualiza `resultados_modelo_final.mat`.
   - **Opção `[3]` — Benchmark Multigrade (~2–3 min):** executa também do zero o refinamento em Equilíbrio Parcial para $N_a \in \{400, 800, 1600\}$.

---

## 4. Estrutura do Pacote

```text
Projeto_D-EGM/
│
├── README.md                              <- Este guia técnico e resumo auditado
├── executar_projeto.m                     <- Ponto de entrada único (menus [1], [2], [3])
│
├── parametros/                            <- Parâmetros econômicos, grades e localização
│   ├── configuracao_modelo.m
│   ├── parametros_modelo.m / _ext.m
│   ├── preprocessamento_modelo.m / _ext.m
│   └── obter_raiz_projeto.m
│
├── codigos/                               <- 30 arquivos .m modulares sem duplicação
│   ├── solucionadores/                    <- VFI vetorizada, DC-EGM, Upper Envelope e CRRA
│   ├── distribuicao/                      <- Operador de Young (2010) e agregados_macro.m
│   ├── equilibrio_geral/                  <- Bisseção de EG (DC-EGM e VFI) e comparação
│   ├── diagnosticos/                      <- 11 testes, multigrade, dobras e segundas diferenças
│   └── resultados/                        <- Orquestração, geração de 16 figuras e CSVs
│
├── resultados/                            <- Registros numéricos oficiais
│   ├── resultados_modelo_final.mat
│   ├── resultados_solucao_individual.mat
│   ├── resultados_benchmark.mat
│   ├── log_execucao_modelo.txt
│   └── tabelas/                           <- tabela1..3.csv e TABELAS_RESULTADOS_FINAIS.xlsx
│
├── figuras/                               <- 16 figuras científicas em formato triplo
│   ├── PDF/                               <- 16 PDFs vetoriais
│   ├── PNG/                               <- 16 PNGs em 300 DPI (também espelhados em figuras/)
│   └── FIG/                               <- 16 arquivos editáveis .fig do MATLAB
│
└── documentacao/                          <- Documentação completa alinhada aos slides
    ├── MANUAL_EXECUCAO.pdf                <- Guia operacional passo a passo
    ├── MAPA_CODIGOS.pdf / .md             <- Arquitetura, dependências e assinaturas
    ├── DESCRICAO_ALGORITMOS.pdf           <- Formulação matemática detalhada
    ├── RELATORIO_FINAL.pdf                <- Relatório técnico consolidado
    ├── APRESENTACAO_COMPLETA.pdf          <- Apresentação definitiva em Beamer (64 slides, 16:9)
    ├── EBOOK_DC_EGM_VFI_FINAL.pdf         <- E-book didático consolidado
    └── COLETANEA_FIGURAS.pdf              <- Caderno vetorial com as 16 figuras
```

---

## 5. Síntese dos Resultados Armazenados e Ressalvas Metodológicas

### A. Equilíbrio Geral Estacionário ($N_a = 400$, $\bar\chi = 0{,}05$, $s_\varepsilon = 0$)

Valores gravados em `resultados_modelo_final.mat` e `resultados/tabelas/tabela2_comparacao_equilibrio_geral.csv` (idênticos aos Slides `4.8`, `4.22`, `4.23` e ao `RELATORIO_FINAL.pdf`):

| Indicador / Variável | DC-EGM com *Upper Envelope* | VFI Vetorizada | Discrepância / Critério |
| :--- | :---: | :---: | :--- |
| Razão Capital-Trabalho ($k^*$) | 6,564697 | 6,547806 | 0,258% |
| Taxa Real de Juros ($r^*$) | 2,7966% | 2,8144% | 0,633% (1,8 pb) |
| Salário Real Competitivo ($w^*$) | 1,260020 | 1,258851 | 0,093% |
| Estoque de Capital ($K^*$) / Trabalho ($L^*$) | 6,5349 / 0,9956 | 6,5147 / 0,9947 | 0,310% / 0,090% |
| Produto ($Y^*$) / Consumo ($C^*$) | 1,9600 / 1,1892 | 1,9567 / 1,1885 | 0,169% / 0,055% |
| Gini de Riqueza / Massa em $a=0$ | 0,4948 / 5,03% | 0,5115 / 14,09% | $+3{,}38\%$ / $-9{,}06$ pp |
| Participação Formal ($M_F$) / Informal ($M_I$) | 98,28% / 1,72% | 97,96% / 2,04% | $\approx 0\%$ inativos ($M_N = 4{,}17\times 10^{-14}$) |
| **Fechamento do mercado de capitais ($|f(k)|/k < 10^{-4}$)** | **$9{,}76 \times 10^{-5}$ (Atende)** | **$2{,}88 \times 10^{-4}$ (Não atende)** | 11 vs. 15 iterações da bisseção |
| **Resíduo contábil da Lei de Walras ($Y - C - \delta K - G$)** | **$-1{,}68 \times 10^{-8}$** | **$-2{,}47 \times 10^{-8}$** | Identidade contábil satisfeita em ambos |
| **Tempo de CPU oficial em Equilíbrio Geral** | **7,61 s** | **26,60 s** | **Speedup 3,49x** (vs. VFI vetorizada) |

**Ressalvas obrigatórias de interpretação (coerentes com os Slides `4.22`, `4.23`, `5.1`–`5.3`):**
1. **Fechamento de mercado vs. Lei de Walras:** os resíduos muito pequenos da identidade contábil de Walras ($\sim 10^{-8}$) verificam apenas a consistência orçamentária agregada nos preços candidatos e **não** devem ser confundidos com o fechamento do mercado de capitais ($|f(k)|/k < 10^{-4}$). Apenas o **DC-EGM** atendeu à tolerância de equilíbrio de capitais (`9,76e-5 < 1e-4`); a **VFI** congelou em platô discreto entre as iterações 12 e 15 com resíduo `2,88e-4` (acima de `1e-4`) e encerrou pela largura do intervalo (`|k_b - k_a| = 9,15e-5 < tol_k`). Assim, `convergiu = 1` na estrutura da VFI reflete parada pelo critério de intervalo, **não** atendimento de todos os critérios de equilíbrio.
2. **Tempos de CPU ao reexecutar:** se a **Opção `[2]`** for executada do zero em outro computador, os agregados econômicos reproduzem-se com exatidão, mas os tempos de relógio variam naturalmente conforme o hardware (ex.: em testes em MATLAB R2026b foram medidos `7,99 s` vs. `24,68 s` [`3,09x`] e `5,17 s` vs. `18,75 s` [`3,63x`], enquanto a referência oficial gravada nos arquivos `.mat`/CSV e slides é `7,61 s` vs. `26,60 s` [`3,49x`]).
3. **Dobras em EG ($N_a=400$):** nenhuma dobra na grade endógena foi detectada na solução de EG examinada com $N_a=400$; não é possível generalizar esse achado para malhas mais finas em EG sem rodar novos experimentos.

### B. Refinamento Multigrade em Equilíbrio Parcial ($\bar\chi = 0{,}05$, $s_\varepsilon = 0$, 15 ramos $(d,z)$)

Valores gravados em `resultados_solucao_individual.mat` e `tabela1_multigrade_modelo_transicao.csv` (Slides `2.8`, `4.5`, `4.15`, `5.1`, `5.2`):

| $N_a$ | It. VFI / DC-EGM | Tempo VFI vet. | Tempo DC-EGM | Ganho (vs. VFI vet.) | $\|V_{\text{VFI}}-V_{\text{DC}}\|_\infty$ | Concordância Ocup. | Dobras Endógenas (Interior + Borda) |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 400 | 376 / 1500* | 2,914 s | 4,990 s | 0,58x | 0,3387 | 99,27% | **0** ($\min \Delta a^{\text{endo}} = +0{,}0452$) |
| 800 | 376 / 376 | 10,591 s | 2,530 s | **4,19x** | 0,0682 | 99,78% | **2 = 1 interior** ($74{,}39\,[I,z_2]$) $+$ **1 borda** ($79{,}80\,[F,z_3]$) |
| 1600 | 376 / 376 | 39,749 s | 5,199 s | **7,65x** | 0,0156 | 99,97% | **4 = 3 interiores** ($60{,}49\,[I,z_1];\,64{,}49\,[F,z_2];\,74{,}40\,[I,z_2]$) $+$ **1 borda** ($79{,}80\,[F,z_3]$) |

*\*Ressalva sobre EP e testes formais:* em $N_a = 400$ em Equilíbrio Parcial, o DC-EGM **não convergiu** abaixo de $10^{-7}$ devido a ciclagem discreta na fronteira ocupacional (atingiu 1.500 iterações com $\Delta V = 2{,}09 \times 10^{-6}$); convergiu normalmente em $N_a \in \{800, 1600\}$ (`376` iterações). Os ganhos acima medem comparação estrita contra **VFI vetorizada de força bruta** (não contra variantes com monotonicidade ou Howard). Além disso, a aprovação nos **11/11 testes formais** (`testes_modelo.m`) certifica invariantes contábeis, restrições, ergodicidade e consistência estrutural, mas **não** deve ser interpretada como garantia de convergência irrestrita em todos os experimentos.

### C. Separação do Benchmark Histórico ($\bar\chi = 0$, Modelo Preliminar)

Os números de precisão marginal (`Euler MAE = 7,18e-7` em `1,661 s` para o DC-EGM Otimizado vs. `1,88e-3` em `91,149 s` na VFI-3200c, onde `Bellman MAE` é `3,56e-5` vs. `2,92e-5`) presentes em `resultados_benchmark.mat` e `tabela3_benchmark_historico_9implementacoes.csv` referem-se **exclusivamente** ao estudo histórico preliminar sem custos de transição ($\bar\chi=0$, Slide `4.16`) e não medem erro de Euler no modelo canônico ($\bar\chi=0{,}05$).

---

## 6. Referências Bibliográficas

1. **Aiyagari, S. R. (1994).** Uninsured Idiosyncratic Risk and Aggregate Saving. *Quarterly Journal of Economics*, 109(3), 659–684.
2. **Carroll, C. D. (2006).** The Method of Endogenous Gridpoints for Solving Dynamic Stochastic Optimization Problems. *Economics Letters*, 91(3), 312–320.
3. **Druedahl, J., & Jørgensen, T. H. (2017).** A General Endogenous Grid Method for Multi-Dimensional Models with Non-Convexities and Constraints. *JEDC*, 74, 87–107.
4. **Huggett, M. (1993).** The Risk-Free Rate in Heterogeneous-Agent Incomplete-Insurance Economies. *JEDC*, 17(5–6), 953–969.
5. **Iskhakov, F., Jørgensen, T. H., Rust, J., & Schjerning, B. (2017).** The Endogenous Grid Method for Discrete-Continuous Dynamic Choice Models with (or without) Taste Shocks. *Quantitative Economics*, 8(2), 317–365.
6. **Rouwenhorst, K. G. (1995).** Asset Pricing Implications of Equilibrium Business Cycle Models. *Frontiers of Business Cycle Research*, Princeton University Press.
7. **Young, E. R. (2010).** Solving the Incomplete Markets Model with Aggregate Uncertainty Using the Krusell–Smith Algorithm and Non-Stochastic Simulations. *JEDC*, 34(1), 36–41.
