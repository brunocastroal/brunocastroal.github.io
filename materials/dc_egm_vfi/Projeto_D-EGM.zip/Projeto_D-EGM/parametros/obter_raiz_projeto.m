function pasta_raiz = obter_raiz_projeto(caminho_ref)
% OBTER_RAIZ_PROJETO Localiza a pasta raiz do projeto (contendo codigos/ e parametros/).
%
% Suporta execucao direta (F5/Command Window) e execucao de secao/selecao no
% Editor (onde mfilename('fullpath') aponta para AppData\Local\Temp\Editor_*).
%
% Sintaxe:
%   pasta_raiz = obter_raiz_projeto()
%   pasta_raiz = obter_raiz_projeto(mfilename('fullpath'))

    candidatos = {};
    if nargin >= 1 && ~isempty(caminho_ref)
        candidatos{end+1} = caminho_ref;
    end
    mf = mfilename('fullpath');
    if ~isempty(mf)
        candidatos{end+1} = mf;
    end
    candidatos{end+1} = pwd;
    if usejava('desktop')
        try
            ed = matlab.desktop.editor.getActiveFilename;
            if ~isempty(ed)
                candidatos{end+1} = ed;
            end
            docs_abertos = matlab.desktop.editor.getAll;
            for idx_d = 1:numel(docs_abertos)
                fn_d = docs_abertos(idx_d).Filename;
                if ~isempty(fn_d)
                    candidatos{end+1} = fn_d;
                end
            end
        catch
        end
    end
    ep = which('executar_projeto.m');
    if ~isempty(ep)
        candidatos{end+1} = ep;
    end

    for c = 1:numel(candidatos)
        p = candidatos{c};
        if ~isfolder(p)
            p = fileparts(p);
        end
        for k_up = 1:5
            if ~isempty(p) && isfolder(fullfile(p, 'codigos')) && isfolder(fullfile(p, 'parametros'))
                pasta_raiz = p;
                return;
            end
            pasta_pai = fileparts(p);
            if isempty(pasta_pai) || strcmp(pasta_pai, p)
                break;
            end
            p = pasta_pai;
        end
    end

    error('obter_raiz_projeto:RaizNaoEncontrada', ...
        ['Nao foi possivel localizar a pasta raiz do projeto (com codigos/ e parametros/).\n' ...
         'Defina a pasta do projeto como Current Folder no MATLAB ou clique em "Run" (F5) em vez de "Run Section" (F9).']);
end
