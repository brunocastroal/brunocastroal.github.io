# Mapa Didático dos Códigos MATLAB (`Projeto_D-EGM`)

**Projeto:** Modelo de Agentes Heterogêneos com Escolhas Ocupacionais e Custos de Transição: Uma Comparação entre VFI e DC-EGM  
**Ambiente de Referência:** MATLAB R2026b Update 1 (compatível com R2020b+, sem toolboxes pagas obrigatórias)  
**Ponto de Entrada Único:** `executar_projeto.m` (na pasta raiz `Projeto_D-EGM/`)

---

## 1. Visão Geral: Arquivos Principais vs. Auxiliares

Para simplificar a navegação e a avaliação docente, o código foi organizado em **um único script principal na raiz** e **seis subpastas modulares** (30 arquivos `.m` únicos, sem duplicações de arquivo e sem caminhos absolutos):

```text
Projeto_D-EGM/
├── executar_projeto.m                 # ÚNICO PONTO DE ENTRADA (menu [1], [2], [3])
├── README.md                          # Guia rápido do pacote
├── parametros/                        # 6 arquivos de calibração e grades
│   ├── configuracao_modelo.m          # Consulta interativa da calibração canônica
│   ├── parametros_modelo.m            # Wrapper: parametros_modelo(Na, chi_bar)
│   ├── parametros_modelo_ext.m        # Núcleo canônico dos parâmetros econômicos
│   ├── preprocessamento_modelo.m      # Wrapper de pré-processamento
│   ├── preprocessamento_modelo_ext.m  # Grade [0,80], Rouwenhorst (5 estados), matriz chi
│   └── obter_raiz_projeto.m           # Localizador automático da raiz do pacote
├── codigos/
│   ├── solucionadores/                # 6 rotinas de Bellman (VFI e DC-EGM + Envelope)
│   │   ├── dc_egm_solver.m            # Interface simples -> dc_egm_extensao
│   │   ├── dc_egm_extensao.m          # Loop Bellman DC-EGM (15 ramos + Euler + custos)
│   │   ├── dc_egm_ramo_condicional.m  # Inversão de Euler + Upper Envelope + cantos KKT
│   │   ├── vfi_solver.m               # Interface simples -> vfi_extensao_vetorizada
│   │   ├── vfi_extensao_vetorizada.m  # Solucionador VFI vetorizado em tensor 4D
│   │   └── utilidade_crra.m           # u(c), u'(c), (u')^-1 e u''(c) com piso numérico
│   ├── distribuicao/                  # 2 rotinas de agregação e distribuição invariante
│   │   ├── distribuicao_estacionaria.m# Operador esparso de Young (2010)
│   │   └── agregados_macro.m          # K_s, L_s, Y, C, I, G, Walras, Gini e percentis
│   ├── equilibrio_geral/              # 4 rotinas de fechamento competitivo (k = K/L)
│   │   ├── equilibrio_geral_dc_egm.m  # Bisseção de EG via DC-EGM
│   │   ├── equilibrio_geral_vfi.m     # Bisseção de EG via VFI vetorizada
│   │   ├── comparacao_equilibrio_geral.m # Diferenças macroeconômicas e speedup
│   │   └── comparacao_metodos.m       # Interface resumida -> comparacao_equilibrio_geral
│   ├── diagnosticos/                  # 5 rotinas de auditoria numérica e testes
│   │   ├── testes_modelo.m            # Bateria formal dos 11 testes automatizados
│   │   ├── validar_solucao_individual.m # Benchmark multigrade Na in {400, 800, 1600}
│   │   ├── diagnostico_grades_endogenas.m # Detecção de dobras (diff(a_endo) < 0)
│   │   ├── diagnostico_concavidade_V.m    # Segundas diferenças finitas de V
│   │   └── diagnostico_concavidade.m      # Interface resumida de concavidade
│   └── resultados/                    # 6 rotinas de orquestração e exportação
│       ├── validar_resultados.m       # Pipeline rápido (Opção [1] / .mat)
│       ├── executar_modelo.m          # Atalho -> validar_resultados
│       ├── executar_modelo_completo.m # Pipeline completo do zero (Opções [2] e [3])
│       ├── gerar_figuras_modelo.m     # Exporta Figuras 1 a 10 (PDF, PNG, FIG)
│       ├── gerar_figuras_complementares.m # Exporta Figuras 11 a 16 (PDF, PNG, FIG)
│       └── gerar_tabelas_csv.m        # Exporta tabela1, tabela2 e tabela3 (.csv)
├── resultados/                        # Arquivos .mat, log e CSVs/XLSX
├── figuras/                           # Figuras em PDF/, PNG/ (300 DPI) e FIG/
└── documentacao/                      # Relatórios, apresentações, manuais e e-book
```

---

## 2. Grafo de Dependências

```text
executar_projeto.m (raiz)
 ├── [Opção 1] validar_resultados.m
 │    ├── carrega: resultados/resultados_modelo_final.mat & resultados_solucao_individual.mat
 │    ├── diagnosticos/testes_modelo.m ──> distribuicao/distribuicao_estacionaria.m
 │    └── resultados/gerar_figuras_modelo.m (Figuras 1..10)
 ├── [Opção 1] resultados/gerar_tabelas_csv.m (tabela1..3.csv)
 ├── [Opção 1] resultados/gerar_figuras_complementares.m (Figuras 11..16; lê tabela3.csv)
 │
 └── [Opções 2 e 3] executar_modelo_completo.m
      ├── parametros/parametros_modelo_ext.m
      ├── parametros/preprocessamento_modelo_ext.m
      ├── equilibrio_geral/equilibrio_geral_dc_egm.m
      │    ├── preprocessamento_modelo_ext.m
      │    ├── solucionadores/dc_egm_extensao.m ──> dc_egm_ramo_condicional.m ──> utilidade_crra.m
      │    ├── distribuicao/distribuicao_estacionaria.m
      │    └── distribuicao/agregados_macro.m
      ├── equilibrio_geral/equilibrio_geral_vfi.m
      │    ├── preprocessamento_modelo_ext.m
      │    ├── solucionadores/vfi_extensao_vetorizada.m ──> utilidade_crra.m
      │    ├── distribuicao/distribuicao_estacionaria.m
      │    └── distribuicao/agregados_macro.m
      ├── equilibrio_geral/comparacao_equilibrio_geral.m
      ├── [Opção 3] diagnosticos/validar_solucao_individual.m
      │    ├── vfi_extensao_vetorizada.m & dc_egm_extensao.m
      │    └── diagnostico_concavidade_V.m & diagnostico_grades_endogenas.m
      ├── diagnosticos/testes_modelo.m
      ├── resultados/gerar_figuras_modelo.m
      └── salva: resultados/resultados_modelo_final.mat & log_execucao_modelo.txt
```

---

## 3. Ordem de Execução por Modo

| Modo | O que executa | Chamadas na ordem exata | Tempo típico |
| :--- | :--- | :--- | :--- |
| **Opção `[1]`** (Padrão) | Validação formal rápida a partir dos `.mat` canônicos | `validar_resultados` $\to$ `testes_modelo` $\to$ `gerar_figuras_modelo` $\to$ `gerar_tabelas_csv` $\to$ `gerar_figuras_complementares` | ~35–60 s |
| **Opção `[2]`** | Reprodução do zero em Equilíbrio Geral ($N_a=400$), reutilizando `resultados_solucao_individual.mat` para multigrade | `executar_modelo_completo` (`forcar_recalculo_multigrade = false`): Etapas 1–8 (`dc_egm_extensao`, `vfi_extensao_vetorizada`, `equilibrio_geral_dc_egm`, `equilibrio_geral_vfi`, `comparacao_equilibrio_geral`, `testes_modelo`, `gerar_figuras_modelo`) | ~40–60 s |
| **Opção `[3]`** | Reprodução completa + recálculo multigrade em Equilíbrio Parcial ($N_a \in \{400, 800, 1600\}$) | Igual à Opção `[2]`, porém com `forcar_recalculo_multigrade = true`, invocando `validar_solucao_individual()` antes dos testes e figuras | ~1,5–2,5 min |

---

## 4. Tabela Completa de Arquivos, Funções, Entradas e Saídas

| Arquivo / Caminho Relativo | Tipo | Entradas Principais | Saídas Principais |
| :--- | :--- | :--- | :--- |
| `executar_projeto.m` | Script | Escolha `[1]`, `[2]` ou `[3]` (`opcao_projeto` opcional) | Orquestra caminhos, execução e resumo final |
| `parametros/parametros_modelo_ext.m` | Função | `(scale_eps, chi_bar, Na)` | `params` (padrão sem args: $\bar\chi=0$; informar `(0.00, 0.05, Na)` no canônico) |
| `parametros/parametros_modelo.m` | Wrapper | `(Na, chi_bar)` | `params` canônicos com $s_\varepsilon = 0{,}00$ e $\bar\chi = 0{,}05$ padrão |
| `parametros/configuracao_modelo.m` | Função | `(Na, chi_bar)` | `cfg` documentando calibração e preços de referência |
| `parametros/preprocessamento_modelo_ext.m` | Função | `params` | `modelo` (`a`, `z`, `Pi`, `pi_z`, `y`, `chi_mat`, `r`, `w`, `R`) |
| `parametros/preprocessamento_modelo.m` | Wrapper | `params` | `modelo` |
| `parametros/obter_raiz_projeto.m` | Auxiliar | `caminho_ref` (opcional) | `pasta_raiz` absoluta detectada dinamicamente |
| `codigos/solucionadores/utilidade_crra.m` | Auxiliar | `(c, sigma, target_du)` | `[u, du, inv_du, d2u]` (com piso $10^{-12}$ e $\sigma \to 1$) |
| `codigos/solucionadores/dc_egm_extensao.m` | Principal | `(modelo, tol_V, tol_c, max_iter, V_init, c_init, use_parfor, kinks_by_d)` | `sol` (`V`, `c_d`, `aprime_d`, `P_d`, `Wprime`, `total_dobras`, `max_violacao_orc`) |
| `codigos/solucionadores/dc_egm_solver.m` | Wrapper | `(modelo, tol_V, tol_c, max_iter)` | `sol` |
| `codigos/solucionadores/dc_egm_ramo_condicional.m` | Principal | `(a_grid, W_d_z, Wprime_d_z, y_dz, psi_d, R, sigma, kinks_cand)` | `[pol_c, pol_aprime, v_cond, teve_dobra, diag_ramo]` |
| `codigos/solucionadores/vfi_extensao_vetorizada.m` | Principal | `(modelo, tol_V, max_iter, V_init)` | `sol` (`V`, `c_d`, `aprime_d`, `P_d`, `iter`, `erro_V`, `tempo`) |
| `codigos/solucionadores/vfi_solver.m` | Wrapper | `(modelo, tol_V, max_iter, V_init)` | `sol` |
| `codigos/distribuicao/distribuicao_estacionaria.m` | Principal | `(modelo, solucao, opcoes)` | `dist` (`mu` $N_a \times N_z \times 3$, `mu_a`, `T` esparsa, `iteracoes`) |
| `codigos/distribuicao/agregados_macro.m` | Principal | `(distribuicao, modelo, solucao)` | `agregados` (`K_s`, `L_s`, `Y_prod`, `C_s`, `hiato_walras`, `gini_riqueza`, percentis) |
| `codigos/equilibrio_geral/equilibrio_geral_dc_egm.m` | Principal | `(params_base, opcoes)` | `eq` (preços `r, w`, agregados, `distribuicao`, `historico`) |
| `codigos/equilibrio_geral/equilibrio_geral_vfi.m` | Principal | `(params_base, opcoes)` | `eq` (mesma estrutura para VFI vetorizada) |
| `codigos/equilibrio_geral/comparacao_equilibrio_geral.m` | Principal | `(eq_dc, eq_vfi, eq_pe_dc, eq_pe_vfi)` | `comp` (diferenças absolutas/relativas e `speedup_eg`) |
| `codigos/equilibrio_geral/comparacao_metodos.m` | Wrapper | `(eq_dc, eq_vfi)` | `comp` |
| `codigos/diagnosticos/testes_modelo.m` | Principal | `(eq_dc, eq_vfi, comp, res_multigrade)` | `[tabela_testes, aprovado_geral]` (11 testes formais) |
| `codigos/diagnosticos/validar_solucao_individual.m` | Principal | Sem argumentos | `res_multigrade` ($N_a \in \{400, 800, 1600\}$ em EP) |
| `codigos/diagnosticos/diagnostico_grades_endogenas.m` | Auxiliar | `(modelo, solucao)` | `res` (tensores `a_endo`, `da_endo`, contagem de dobras) |
| `codigos/diagnosticos/diagnostico_concavidade_V.m` | Auxiliar | `(modelo, solucao)` | `res` (segundas diferenças `D2V`, maior sequência positiva) |
| `codigos/diagnosticos/diagnostico_concavidade.m` | Wrapper | `(solucao, modelo)` | `res` |
| `codigos/resultados/validar_resultados.m` | Script | Lê `resultados_modelo_final.mat` e `resultados_solucao_individual.mat` | Testes no console, Figuras 1–10 e `log_execucao_modelo.txt` |
| `codigos/resultados/executar_modelo_completo.m` | Script | `forcar_recalculo_multigrade` (opcional) | Atualiza `.mat`, Figuras 1–10 e `log_execucao_modelo.txt` |
| `codigos/resultados/executar_modelo.m` | Wrapper | Sem argumentos | Chama `validar_resultados` |
| `codigos/resultados/gerar_figuras_modelo.m` | Gerador | `(eq_dc, eq_vfi, comp, res_multigrade, pasta_figuras)` (todos opcionais) | Salva Figuras 1 a 10 em `figuras/{PDF,PNG,FIG}/` |
| `codigos/resultados/gerar_figuras_complementares.m` | Gerador | `pasta_figuras` (opcional) | Salva Figuras 11 a 16 em `figuras/{PDF,PNG,FIG}/` |
| `codigos/resultados/gerar_tabelas_csv.m` | Script | Lê os 3 `.mat` de `resultados/` | Grava `tabela1..3.csv` em `resultados/tabelas/` |

---

## 5. Onde Cada Resultado Fica Salvo

- **Figuras (1 a 16):** `figuras/PDF/`, `figuras/PNG/` (300 DPI) e `figuras/FIG/` (formatos editáveis do MATLAB).
- **Tabelas numéricas CSV:** `resultados/tabelas/tabela1_multigrade_modelo_transicao.csv`, `tabela2_comparacao_equilibrio_geral.csv` e `tabela3_benchmark_historico_9implementacoes.csv`.
- **Planilha consolidada:** `resultados/tabelas/TABELAS_RESULTADOS_FINAIS.xlsx` (8 abas auditadas).
- **Arquivos binários `.mat`:** `resultados/resultados_modelo_final.mat` (equilíbrio geral e baseline EP), `resultados/resultados_solucao_individual.mat` (multigrade $N_a \in \{400, 800, 1600\}$) e `resultados/resultados_benchmark.mat` (benchmark histórico complementar de 9 implementações).
- **Diário de execução:** `resultados/log_execucao_modelo.txt`.
