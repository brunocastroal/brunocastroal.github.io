% =========================================================================
% SCRIPT PRINCIPAL DE EXECUCAO DO PROJETO PARA AVALIACAO DOCENTE
% =========================================================================
% Titulo: Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
%         Uma Comparacao entre VFI e DC-EGM
%
% Disciplina: Economia Computacional / Macroeconomia Quantitativa
% Autor: Bruno Castro Alves (Pos-Graduacao em Economia)
% Data: 12 de novembro de 2026
%
% Instrucoes:
%   Basta digitar "executar_projeto" no Command Window do MATLAB.
%   O script configura automaticamente os caminhos e oferece modos de execucao.
% =========================================================================

clearvars -except opcao_projeto; clc; close all;

% 1. Configuracao automatica dos caminhos relativos a partir da raiz
%    (resiliente a Run Section / F9 que executa em Temp\Editor_*)
if exist('obter_raiz_projeto', 'file') ~= 2
    bases_busca = {fileparts(mfilename('fullpath')), pwd};
    ep_loc = which('executar_projeto.m');
    if ~isempty(ep_loc), bases_busca{end+1} = fileparts(ep_loc); end
    if usejava('desktop')
        try
            ed = matlab.desktop.editor.getActiveFilename;
            if ~isempty(ed), bases_busca{end+1} = fileparts(ed); end
            docs_abertos = matlab.desktop.editor.getAll;
            for idx_d = 1:numel(docs_abertos)
                fn_d = docs_abertos(idx_d).Filename;
                if ~isempty(fn_d), bases_busca{end+1} = fileparts(fn_d); end
            end
        catch
        end
    end
    for i_b = 1:numel(bases_busca)
        p_b = bases_busca{i_b};
        for k_up = 1:5
            if ~isempty(p_b) && isfolder(fullfile(p_b, 'codigos')) && isfolder(fullfile(p_b, 'parametros'))
                addpath(fullfile(p_b, 'parametros'));
                break;
            end
            p_pai = fileparts(p_b);
            if isempty(p_pai) || strcmp(p_pai, p_b), break; end
            p_b = p_pai;
        end
        if exist('obter_raiz_projeto', 'file') == 2, break; end
    end
end

if exist('obter_raiz_projeto', 'file') ~= 2
    error('executar_projeto:RaizNaoEncontrada', ...
        ['Nao foi possivel localizar a pasta raiz do projeto (com subpastas codigos/ e parametros/).\n' ...
         'No MATLAB, defina a pasta do projeto no Current Folder (cd) e execute "executar_projeto" ou clique em "Run" (F5) em vez de "Run Section" (F9).']);
end

pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));

addpath(pasta_raiz);
addpath(genpath(fullfile(pasta_raiz, 'codigos')));
addpath(fullfile(pasta_raiz, 'parametros'));
cd(pasta_raiz);

fprintf('========================================================================\n');
fprintf('  MODELO DE AGENTES HETEROGENEOS COM ESCOLHAS OCUPACIONAIS E CUSTOS\n');
fprintf('                  UMA COMPARACAO ENTRE VFI E DC-EGM\n');
fprintf('========================================================================\n');
fprintf('  Diretorio do Projeto: %s\n', pasta_raiz);
fprintf('  Ambiente: MATLAB %s\n', version);
fprintf('------------------------------------------------------------------------\n');
fprintf('  Selecione o modo de execucao desejado:\n');
fprintf('    [1] Validacao Rapida (~30-60s): Testes formais + 16 figuras + CSVs\n');
fprintf('    [2] Reproducao Completa (~40s): Resolve DC-EGM e VFI do zero em EG\n');
fprintf('    [3] Benchmark Multigrade (~2m): Executa malhas Na = {400, 800, 1600}\n');
fprintf('========================================================================\n');

opcao = 1; % Padrao para execucao automatica ou nao-interativa
if exist('opcao_projeto', 'var') && ~isempty(opcao_projeto)
    opcao = opcao_projeto;
elseif ~isempty(getenv('OPCAO_PROJETO'))
    op_env = str2double(getenv('OPCAO_PROJETO'));
    if ~isnan(op_env)
        opcao = op_env;
    end
elseif usejava('desktop')
    try
        entrada = input('  Digite a opcao desejada [1, 2 ou 3] (padrao: 1): ', 's');
        if ~isempty(strtrim(entrada))
            opcao = str2double(entrada);
        end
    catch
        opcao = 1;
    end
end

fprintf('\n>>> Executando Opcao [%d]...\n\n', opcao);

switch opcao
    case 1
        % Validacao formal rapida (testes + tabelas CSV + regeneracao das 16 figuras)
        validar_resultados;
        gerar_tabelas_csv;
        gerar_figuras_complementares;
        
    case 2
        % Reproducao integral do zero
        forcar_recalculo_multigrade = false;
        executar_modelo_completo;
        
    case 3
        % Benchmark multigrade completo
        forcar_recalculo_multigrade = true;
        executar_modelo_completo;
        
    otherwise
        fprintf('Opcao invalida. Executando Validacao Rapida por padrao.\n');
        validar_resultados;
        gerar_tabelas_csv;
        gerar_figuras_complementares;
end

cd(pasta_raiz);

fprintf('\n========================================================================\n');
fprintf('  EXECUCAO CONCLUIDA COM SUCESSO!\n');
fprintf('  - Figuras exportadas em: %s\n', fullfile(pasta_raiz, 'figuras', 'PDF'));
fprintf('  - Tabelas CSV salvas em : %s\n', fullfile(pasta_raiz, 'resultados', 'tabelas'));
fprintf('  - Manuais e Relatorios  : %s\n', fullfile(pasta_raiz, 'documentacao'));
fprintf('========================================================================\n');
