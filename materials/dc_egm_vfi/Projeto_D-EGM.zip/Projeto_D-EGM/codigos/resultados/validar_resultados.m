% =========================================================================
% SCRIPT DE VALIDACAO DOS RESULTADOS: VALIDAR_RESULTADOS
% =========================================================================
% Titulo Oficial:
% "Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
%  Uma Comparacao entre VFI e DC-EGM"
%
% Este script valida os resultados calculados e armazenados em .mat:
% 1. Carrega os resultados consolidados de equilibrio geral e multigrade
% 2. Executa a bateria formal de 11 testes de consistencia economica e numerica
% 3. Regenera as 10 figuras academicas em alta resolucao (300 DPI)
% 4. Grava o diario atualizado de execucao em resultados/log_execucao_modelo.txt
%
% Tempo tipico de execucao: ~15 a 40 segundos.
% =========================================================================

clearvars -except pasta_raiz opcao opcao_projeto; clc; close all;
t_validacao_start = tic;

if exist('obter_raiz_projeto', 'file') ~= 2
    cand_r = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    if isfolder(fullfile(cand_r, 'parametros'))
        addpath(fullfile(cand_r, 'parametros'));
    elseif isfolder(fullfile(pwd, 'parametros'))
        addpath(fullfile(pwd, 'parametros'));
    end
end
pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));
if exist('testes_modelo', 'file') ~= 2 || exist('gerar_figuras_modelo', 'file') ~= 2
    addpath(pasta_raiz);
    addpath(genpath(fullfile(pasta_raiz, 'codigos')));
    addpath(fullfile(pasta_raiz, 'parametros'));
end

pasta_res = fullfile(pasta_raiz, 'resultados');
pasta_fig = fullfile(pasta_raiz, 'figuras');

cd(pasta_raiz);

arquivo_log = fullfile(pasta_res, 'log_execucao_modelo.txt');
if exist(arquivo_log, 'file')
    delete(arquivo_log);
end
diary(arquivo_log);

fprintf('========================================================================\n');
fprintf('  VALIDACAO FORMAL DOS RESULTADOS CALCULADOS - VFI vs DC-EGM\n');
fprintf('========================================================================\n');
fprintf('Titulo Oficial : Modelo de Agentes Heterogeneos com Escolhas Ocupacionais\n');
fprintf('                 e Custos de Transicao: Uma Comparacao entre VFI e DC-EGM\n');
fprintf('Diretorio Raiz : %s\n', pasta_raiz);
fprintf('Data e Hora    : %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
fprintf('Versao MATLAB  : %s\n', version);
fprintf('Ambiente       : Windows (Execucao serial vetorizada em no unico)\n');
fprintf('========================================================================\n\n');

% 1. Carregar resultados
arq_final = fullfile(pasta_res, 'resultados_modelo_final.mat');
arq_indiv = fullfile(pasta_res, 'resultados_solucao_individual.mat');

if ~exist(arq_final, 'file')
    error(['Arquivo de resultados nao encontrado: %s\n' ...
           'Execute primeiro executar_modelo_completo para calcular o modelo do zero.'], arq_final);
end

fprintf('>>> Carregando resultados consolidados de:\n  %s\n', arq_final);
d_final = load(arq_final);
eq_dc   = d_final.eq_dc;
eq_vfi  = d_final.eq_vfi;
comp    = d_final.comp;

if isfield(d_final, 'res_multigrade')
    res_multigrade = d_final.res_multigrade;
elseif exist(arq_indiv, 'file')
    fprintf('>>> Carregando resultados multigrade de:\n  %s\n', arq_indiv);
    d_ind = load(arq_indiv);
    if isfield(d_ind, 'res_multigrade')
        res_multigrade = d_ind.res_multigrade;
    elseif isfield(d_ind, 'resultados_fase1')
        res_multigrade = d_ind.resultados_fase1;
    end
else
    error('Estrutura res_multigrade nao encontrada nos arquivos MAT.');
end

% 2. Executar bateria de 11 testes
fprintf('\n>>> Executando Bateria de 11 Testes Automatizados...\n');
[tabela_testes, aprovado_geral] = testes_modelo(eq_dc, eq_vfi, comp, res_multigrade);

% 3. Gerar figuras academicas atualizadas (300 DPI)
fprintf('>>> Gerando as 10 Figuras Academicas em %s...\n', pasta_fig);
gerar_figuras_modelo(eq_dc, eq_vfi, comp, res_multigrade, pasta_fig);

tempo_val = toc(t_validacao_start);
fprintf('========================================================================\n');
fprintf('  VALIDACAO CONCLUIDA COM SUCESSO EM %.2f SEGUNDOS!\n', tempo_val);
if aprovado_geral
    fprintf('  Status: 100%% DOS TESTES APROVADOS. FIGURAS SALVAS EM 300 DPI.\n');
else
    fprintf('  Status: ATENCAO - VERIFICAR TESTES QUE FALHARAM.\n');
end
fprintf('========================================================================\n\n');

diary off;
