% =========================================================================
% SCRIPT MASTER DE REPRODUCAO INTEGRAL DO ZERO: EXECUTAR_MODELO_COMPLETO
% =========================================================================
% Titulo Oficial:
% "Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
%  Uma Comparacao entre VFI e DC-EGM"
%
% Opcoes de Execucao:
%   forcar_recalculo_multigrade : se true, forca a resolucao do zero das malhas
%                                 Na in {400, 800, 1600} em equilibrio parcial.
%                                 se false (padrao), reaproveita resultados
%                                 pre-existentes em resultados_solucao_individual.mat.
%
% Este script executa a solucao integral do modelo economico:
% 1. Definicao e calibracao dos parametros
% 2. Preprocessamento das grades e cadeias de Markov
% 3. Solucao da funcao valor via VFI vetorizada (Equilibrio Parcial)
% 4. Solucao da funcao valor via DC-EGM com Upper Envelope (Equilibrio Parcial)
% 5. Calculo da distribuicao estacionaria conjunta invariante
% 6. Determinacao do Equilibrio Geral Estacionario (bisseccao DC-EGM e VFI)
% 7. Comparacao quantitativa detalhada DC-EGM vs VFI
% 8. Salvamento consolidado dos resultados (.mat) e diario de execucao (.txt)
% =========================================================================

if ~exist('forcar_recalculo_multigrade', 'var')
    forcar_recalculo_multigrade = false;
end

clearvars -except forcar_recalculo_multigrade pasta_raiz opcao opcao_projeto; clc; close all;
t_inicio_master = tic;

if exist('obter_raiz_projeto', 'file') ~= 2
    cand_r = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    if isfolder(fullfile(cand_r, 'parametros'))
        addpath(fullfile(cand_r, 'parametros'));
    elseif isfolder(fullfile(pwd, 'parametros'))
        addpath(fullfile(pwd, 'parametros'));
    end
end
pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));
if exist('equilibrio_geral_dc_egm', 'file') ~= 2 || exist('parametros_modelo_ext', 'file') ~= 2
    addpath(pasta_raiz);
    addpath(genpath(fullfile(pasta_raiz, 'codigos')));
    addpath(fullfile(pasta_raiz, 'parametros'));
end

pasta_res = fullfile(pasta_raiz, 'resultados');
pasta_fig = fullfile(pasta_raiz, 'figuras');

if ~exist(pasta_res, 'dir'), mkdir(pasta_res); end
if ~exist(pasta_fig, 'dir'), mkdir(pasta_fig); end

cd(pasta_raiz);

arquivo_log = fullfile(pasta_res, 'log_execucao_modelo.txt');
if exist(arquivo_log, 'file')
    delete(arquivo_log);
end
diary(arquivo_log);

fprintf('========================================================================\n');
fprintf('  REPRODUCAO INTEGRAL DO MODELO: VFI vs DC-EGM COM CUSTOS DE TRANSICAO\n');
fprintf('========================================================================\n');
fprintf('Data e Hora de Execucao : %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
fprintf('Diretorio Raiz          : %s\n', pasta_raiz);
fprintf('Versao do MATLAB        : %s\n', version);
fprintf('Ambiente Operacional    : Windows (Single-node vetorizado sem parfor)\n');
fprintf('Especificacao Economica : s_eps = 0.00 (Determinismo) | chi_bar = 0.05\n');
fprintf('========================================================================\n\n');

% -------------------------------------------------------------------------
% ETAPA 1: DEFINICAO DOS PARAMETROS DO MODELO
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 1/8] Carregando e Calibrando Parametros Estruturais...\n');
params = parametros_modelo();
fprintf('  Parametros calibrados:\n');
fprintf('    beta = %.2f, sigma = %.2f, s_eps = %.2f, chi_bar = %.2f\n', ...
    params.beta, params.sigma, params.scale_eps, params.chi_bar);
fprintf('    alpha = %.2f, delta = %.2f, tau = %.2f, kappa = %.2f\n', ...
    params.alpha, params.delta, params.tau, params.kappa);
fprintf('    Grade a: [%.1f, %.1f] com Na = %d pontos\n\n', ...
    params.a_min, params.a_max, params.Na);

% -------------------------------------------------------------------------
% ETAPA 2: PREPROCESSAMENTO DE GRADES E MARKOV
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 2/8] Preprocessamento de Grades e Discretizacao de Markov...\n');
modelo = preprocessamento_modelo(params);
fprintf('  Processo de produtividade discretizado (Rouwenhorst, Nz = %d):\n', modelo.Nz);
fprintf('    z = [%s]\n\n', num2str(modelo.z(:)', ' %.4f'));

% -------------------------------------------------------------------------
% ETAPA 3: SOLUCAO INDIVIDUAL VIA VFI VETORIZADA (EQUILIBRIO PARCIAL)
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 3/8] Resolvendo Funcao Valor via VFI Vetorizada (EP)...\n');
t_vfi_pe = tic;
sol_vfi_pe = vfi_solver(modelo, 1e-7, 1500);
tempo_vfi_pe = toc(t_vfi_pe);
fprintf('  VFI concluido em %.2f s: iter = %d, residuo_V = %.2e, convergiu = %d\n\n', ...
    tempo_vfi_pe, sol_vfi_pe.iter, sol_vfi_pe.erro_V, sol_vfi_pe.convergiu);

% -------------------------------------------------------------------------
% ETAPA 4: SOLUCAO INDIVIDUAL VIA DC-EGM COM UPPER ENVELOPE (EQUILIBRIO PARCIAL)
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 4/8] Resolvendo Funcao Valor via DC-EGM com Upper Envelope (EP)...\n');
t_dc_pe = tic;
sol_dc_pe = dc_egm_solver(modelo, 1e-7, 1e-6, 1500);
tempo_dc_pe = toc(t_dc_pe);
fprintf('  DC-EGM concluido em %.2f s: iter = %d, residuo_V = %.2e, residuo_c = %.2e, convergiu = %d\n\n', ...
    tempo_dc_pe, sol_dc_pe.iter, sol_dc_pe.erro_V, sol_dc_pe.erro_c, sol_dc_pe.convergiu);

% -------------------------------------------------------------------------
% ETAPA 5: DISTRIBUICAO ESTACIONARIA CONJUNTA EM EQUILIBRIO PARCIAL
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 5/8] Calculando Distribuicao Estacionaria Invariante (Young 2010)...\n');
t_dist_pe = tic;
dist_dc_pe = distribuicao_estacionaria(modelo, sol_dc_pe);
agg_dc_pe  = agregados_macro(dist_dc_pe, modelo, sol_dc_pe);
tempo_dist_pe = toc(t_dist_pe);

pe_baseline = struct();
pe_baseline.parametros   = params;
pe_baseline.modelo       = modelo;
pe_baseline.solucao      = sol_dc_pe;
pe_baseline.distribuicao = dist_dc_pe;
pe_baseline.agregados    = agg_dc_pe;
pe_baseline.tempo        = tempo_dc_pe + tempo_dist_pe;

fprintf('  Agregados em Equilibrio Parcial (r = %.4f%%, w = %.4f):\n', ...
    modelo.r * 100, modelo.w);
fprintf('    K_s = %.4f | L_s = %.4f | k_supply = %.4f | M_I = %.2f%% | M_F = %.2f%%\n\n', ...
    agg_dc_pe.K_s, agg_dc_pe.L_s, agg_dc_pe.k_supply, agg_dc_pe.M_I * 100, agg_dc_pe.M_F * 100);

% -------------------------------------------------------------------------
% ETAPA 6: EQUILIBRIO GERAL ESTACIONARIO COMPETITIVO
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 6/8] Solucionando Equilibrio Geral Competitivo (Bisseccao em k = K/L)...\n');
opcoes_eg = struct();
opcoes_eg.k_min           = 6.00;
opcoes_eg.k_max           = 7.50;
opcoes_eg.tol_k           = 1e-4;
opcoes_eg.max_iter        = 30;
opcoes_eg.tol_V           = 1e-7;
opcoes_eg.tol_c           = 1e-6;
opcoes_eg.tol_dist        = 1e-10;
opcoes_eg.max_iter_solver = 1500;
opcoes_eg.max_iter_dist   = 25000;
opcoes_eg.verbose         = true;

fprintf('  -- Executando Bisseccao de Equilibrio Geral via DC-EGM --\n');
eq_dc = equilibrio_geral_dc_egm(params, opcoes_eg);

fprintf('\n  -- Executando Bisseccao de Equilibrio Geral via VFI Vetorizada --\n');
eq_vfi = equilibrio_geral_vfi(params, opcoes_eg);

% -------------------------------------------------------------------------
% ETAPA 7: COMPARACAO QUANTITATIVA E BATERIA DE TESTES
% -------------------------------------------------------------------------
fprintf('\n>>> [ETAPA 7/8] Comparacao Quantitativa DC-EGM vs VFI e Testes...\n');
comp = comparacao_equilibrio_geral(eq_dc, eq_vfi);

% Carregar ou recalcular multigrade
arq_indiv = fullfile(pasta_res, 'resultados_solucao_individual.mat');
if ~forcar_recalculo_multigrade && exist(arq_indiv, 'file')
    fprintf('  Carregando resultados multigrade pre-existentes de:\n    %s\n', arq_indiv);
    d_ind = load(arq_indiv);
    if isfield(d_ind, 'res_multigrade')
        res_multigrade = d_ind.res_multigrade;
    elseif isfield(d_ind, 'resultados_fase1')
        res_multigrade = d_ind.resultados_fase1;
    end
else
    if forcar_recalculo_multigrade
        fprintf('  [Opcao ativa] Forcando recalculacao integral do refinamento multigrade (Na in {400, 800, 1600})...\n');
    else
        fprintf('  Resultados multigrade nao encontrados. Executando refinamento multigrade (Na in {400, 800, 1600})...\n');
    end
    res_multigrade = validar_solucao_individual();
end

[tabela_testes, aprovado_geral] = testes_modelo(eq_dc, eq_vfi, comp, res_multigrade);

% Gerar figuras atualizadas
gerar_figuras_modelo(eq_dc, eq_vfi, comp, res_multigrade, pasta_fig);

% -------------------------------------------------------------------------
% ETAPA 8: SALVAMENTO CONSOLIDADO DOS RESULTADOS
% -------------------------------------------------------------------------
fprintf('>>> [ETAPA 8/8] Salvando Resultados Finais Consolidados...\n');
arquivo_mat_final = fullfile(pasta_res, 'resultados_modelo_final.mat');
save(arquivo_mat_final, 'eq_dc', 'eq_vfi', 'comp', 'pe_baseline', ...
     'res_multigrade', 'tabela_testes', 'aprovado_geral', '-v7.3');
fprintf('  Resultados salvos com sucesso em:\n    %s\n', arquivo_mat_final);

tempo_total = toc(t_inicio_master);
fprintf('\n========================================================================\n');
fprintf('  REPRODUCAO INTEGRAL CONCLUIDA COM SUCESSO!\n');
fprintf('  Tempo total de execucao: %.2f s (%.2f min)\n', tempo_total, tempo_total / 60);
fprintf('========================================================================\n\n');

diary off;
