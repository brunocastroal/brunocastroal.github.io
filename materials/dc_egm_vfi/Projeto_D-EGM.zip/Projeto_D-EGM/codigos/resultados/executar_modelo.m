% =========================================================================
% SCRIPT MESTRE: EXECUCAO E VALIDACAO DO MODELO VFI vs DC-EGM
% =========================================================================
% Modelo de Agentes Heterogeneos com Escolhas Ocupacionais e Custos de Transicao:
% Uma Comparacao entre VFI e DC-EGM
%
% Este script oferece dois modos de operacao:
%
% 1. VALIDACAO RAPIDA (Padrao, ~15-20 segundos):
%    Carrega os resultados calculados (.mat), executa a bateria de 11 testes
%    formais e regenera as 10 figuras academicas em 300 DPI.
%    Comando direto: validar_resultados;
%
% 2. REPRODUCAO INTEGRAL DO ZERO (~35-45 segundos):
%    Resolve todas as equacoes de Bellman, busca o equilibrio geral por
%    bisseccao em VFI e DC-EGM, computa a distribuicao estacionaria e salva tudo.
%    Comando direto: executar_modelo_completo;
% =========================================================================

clearvars -except pasta_raiz opcao opcao_projeto; clc; close all;

if exist('obter_raiz_projeto', 'file') ~= 2
    cand_r = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    if isfolder(fullfile(cand_r, 'parametros'))
        addpath(fullfile(cand_r, 'parametros'));
    elseif isfolder(fullfile(pwd, 'parametros'))
        addpath(fullfile(pwd, 'parametros'));
    end
end
pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));
if exist('validar_resultados', 'file') ~= 2
    addpath(pasta_raiz);
    addpath(genpath(fullfile(pasta_raiz, 'codigos')));
    addpath(fullfile(pasta_raiz, 'parametros'));
end

fprintf('========================================================================\n');
fprintf('  MODELO DE AGENTES HETEROGENEOS COM ESCOLHAS OCUPACIONAIS E CUSTOS\n');
fprintf('                  UMA COMPARACAO ENTRE VFI E DC-EGM\n');
fprintf('========================================================================\n');
fprintf('  Modo padrao: Executando VALIDACAO FORMAL DOS RESULTADOS (validar_resultados)\n');
fprintf('  Para resolver o modelo do zero, execute: executar_modelo_completo\n');
fprintf('========================================================================\n\n');

validar_resultados;
