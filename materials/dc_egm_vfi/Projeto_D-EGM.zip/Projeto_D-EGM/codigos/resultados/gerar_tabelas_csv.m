% =========================================================================
% GERADOR DE TABELAS CIENTIFICAS (CSV) - PROJETO VFI vs DC-EGM
% =========================================================================
% Gera os 3 arquivos CSV consolidados:
%   1. tabela1_multigrade_modelo_transicao.csv (Benchmark canonico com chi_bar=0.05)
%   2. tabela2_comparacao_equilibrio_geral.csv (Equilibrio Geral Na=400)
%   3. tabela3_benchmark_historico_9implementacoes.csv (Benchmark 9 implementacoes Na=400)
% =========================================================================

if exist('obter_raiz_projeto', 'file') ~= 2
    cand_r = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    if isfolder(fullfile(cand_r, 'parametros'))
        addpath(fullfile(cand_r, 'parametros'));
    elseif isfolder(fullfile(pwd, 'parametros'))
        addpath(fullfile(pwd, 'parametros'));
    end
end
pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));
pasta_tab     = fullfile(pasta_raiz, 'resultados', 'tabelas');
if ~exist(pasta_tab, 'dir'), mkdir(pasta_tab); end

% 1. Carregar dados consolidados
arq_final = fullfile(pasta_raiz, 'resultados', 'resultados_modelo_final.mat');
arq_indiv = fullfile(pasta_raiz, 'resultados', 'resultados_solucao_individual.mat');

% Localizacao de resultados_benchmark.mat com busca local prioritaria
bench_path = fullfile(pasta_raiz, 'resultados', 'resultados_benchmark.mat');
if ~exist(bench_path, 'file')
    bench_path = fullfile(pasta_raiz, '..', 'benchmark_vfi_vs_dc_egm', 'resultados_benchmark.mat');
end

d_fin = load(arq_final);
d_ind = load(arq_indiv);

% =========================================================================
% TABELA 1: Refinamento Multigrade Modelo com Custos de Transicao (Canonico)
% =========================================================================
fid1 = fopen(fullfile(pasta_tab, 'tabela1_multigrade_modelo_transicao.csv'), 'w');
fprintf(fid1, 'Na,Iter_VFI,Iter_DCEGM,Convergencia_DCEGM,Tempo_VFI_s,Tempo_DCEGM_s,Speedup,dif_sup_V,dif_sup_c,dif_sup_ap,Concordancia_Ocup_pct,Dobras_Grade_Endogena_Final\n');

r400  = d_ind.resultados_fase1.Na_400;
r800  = d_ind.resultados_fase1.Na_800;
r1600 = d_ind.resultados_fase1.Na_1600;

conv_str = {'Nao', 'Sim'};
c400  = conv_str{r400.sol_dc.convergiu + 1};
c800  = conv_str{r800.sol_dc.convergiu + 1};
c1600 = conv_str{r1600.sol_dc.convergiu + 1};

% Utiliza estritamente res_endo.total_dobras (diagnostico final da grade endogena)
% Speedup calculado sobre os tempos arredondados a 3 casas (consistencia com Tabela 1 e Figura 10)
fprintf(fid1, '400,%d,%d,%s,%.3f,%.3f,%.2f,%.4f,%.4f,%.4f,%.2f,%d\n', ...
    r400.sol_vfi.iter, r400.sol_dc.iter, c400, r400.tempo_vfi, r400.tempo_dc, ...
    round(r400.tempo_vfi, 3)/round(r400.tempo_dc, 3), r400.dif_sup_V, r400.dif_sup_c, r400.dif_sup_ap, ...
    r400.pct_d_star_match, r400.res_endo.total_dobras);

fprintf(fid1, '800,%d,%d,%s,%.3f,%.3f,%.2f,%.4f,%.4f,%.4f,%.2f,%d\n', ...
    r800.sol_vfi.iter, r800.sol_dc.iter, c800, r800.tempo_vfi, r800.tempo_dc, ...
    round(r800.tempo_vfi, 3)/round(r800.tempo_dc, 3), r800.dif_sup_V, r800.dif_sup_c, r800.dif_sup_ap, ...
    r800.pct_d_star_match, r800.res_endo.total_dobras);

fprintf(fid1, '1600,%d,%d,%s,%.3f,%.3f,%.2f,%.4f,%.4f,%.4f,%.2f,%d\n', ...
    r1600.sol_vfi.iter, r1600.sol_dc.iter, c1600, r1600.tempo_vfi, r1600.tempo_dc, ...
    round(r1600.tempo_vfi, 3)/round(r1600.tempo_dc, 3), r1600.dif_sup_V, r1600.dif_sup_c, r1600.dif_sup_ap, ...
    r1600.pct_d_star_match, r1600.res_endo.total_dobras);
fclose(fid1);

% =========================================================================
% TABELA 2: Comparacao Macroeconomica em Equilibrio Geral (Na = 400)
% =========================================================================
fid2 = fopen(fullfile(pasta_tab, 'tabela2_comparacao_equilibrio_geral.csv'), 'w');
fprintf(fid2, 'Variavel,DC_EGM_Envelope,VFI_Vetorizada,Discrepancia_Absoluta,Discrepancia_Relativa_pct\n');

eq_dc  = d_fin.eq_dc;
eq_vfi = d_fin.eq_vfi;
comp   = d_fin.comp;

fprintf(fid2, 'Razao Capital-Trabalho (k*),%.6f,%.6f,%.6f,%.3f\n', eq_dc.k, eq_vfi.k, comp.dif_k, comp.dif_rel_k * 100);
fprintf(fid2, 'Taxa de Juros Real (r* pct),%.4f,%.4f,%.4f,%.3f\n', eq_dc.r * 100, eq_vfi.r * 100, comp.dif_r * 100, comp.dif_rel_r * 100);
fprintf(fid2, 'Salario Real (w*),%.6f,%.6f,%.6f,%.3f\n', eq_dc.w, eq_vfi.w, comp.dif_w, comp.dif_rel_w * 100);
fprintf(fid2, 'Estoque de Capital (K*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.K, eq_vfi.K, comp.dif_K, comp.dif_rel_K * 100);
fprintf(fid2, 'Trabalho Efetivo (L*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.L, eq_vfi.L, comp.dif_L, comp.dif_rel_L * 100);
fprintf(fid2, 'Produto Total (Y*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.Y, eq_vfi.Y, comp.dif_Y, comp.dif_rel_Y * 100);
fprintf(fid2, 'Consumo Privado (C*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.C, eq_vfi.C, comp.dif_C, comp.dif_rel_C * 100);
fprintf(fid2, 'Investimento (I*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.I, eq_vfi.I, abs(eq_dc.I - eq_vfi.I), abs(eq_dc.I - eq_vfi.I)/eq_dc.I * 100);
fprintf(fid2, 'Gasto Governo (G*),%.4f,%.4f,%.4f,%.3f\n', eq_dc.G, eq_vfi.G, abs(eq_dc.G - eq_vfi.G), abs(eq_dc.G - eq_vfi.G)/eq_dc.G * 100);
fprintf(fid2, 'Residuo de Walras,%.2e,%.2e,-,-\n', eq_dc.hiato_walras, eq_vfi.hiato_walras);
fprintf(fid2, 'Gini de Riqueza,%.4f,%.4f,%.4f,%.2f\n', eq_dc.gini, eq_vfi.gini, comp.dif_gini, comp.dif_gini/eq_dc.gini * 100);
fprintf(fid2, 'Participacao Inativos (pct),%.2f,%.2f,%.2f,-\n', eq_dc.M_N * 100, eq_vfi.M_N * 100, comp.dif_MN * 100);
fprintf(fid2, 'Participacao Informais (pct),%.2f,%.2f,%.2f,-\n', eq_dc.M_I * 100, eq_vfi.M_I * 100, comp.dif_MI * 100);
fprintf(fid2, 'Participacao Formais (pct),%.2f,%.2f,%.2f,-\n', eq_dc.M_F * 100, eq_vfi.M_F * 100, comp.dif_MF * 100);
fprintf(fid2, 'Iteracoes Bisseccao,%d,%d,-,-\n', eq_dc.iteracoes, eq_vfi.iteracoes);
fprintf(fid2, 'Tempo Total EG (s),%.2f,%.2f,-,%.2fx mais rapido\n', eq_dc.tempo_total, eq_vfi.tempo_total, comp.speedup_eg);
fclose(fid2);

% =========================================================================
% TABELA 3: Benchmark Historico de 9 Implementacoes e 7 Repeticoes (Na=400)
% =========================================================================
if exist(bench_path, 'file')
    d_b = load(bench_path);
    st = d_b.benchmark.bench_tempo.tabela_stats;

    fid3 = fopen(fullfile(pasta_tab, 'tabela3_benchmark_historico_9implementacoes.csv'), 'w');
    fprintf(fid3, 'Implementacao,Mediana_s,Media_s,Std_s,Min_s,Max_s,Speedup_vs_VFI_Vet,Euler_Erro_Consumo,Residuo_Euler_Conv,Bellman_MAE,Concordancia_Ocup_pct\n');

    chaves = {'dc_otim', 'vfi_mono', 'vfi_vet', 'vfi_ref_400', 'vfi_fb', 'vfi_ref_800', 'vfi_ref_1600', 'dc_padrao', 'vfi_ref_3200'};
    nomes  = {'DC-EGM Otimizado', 'VFI Monotonicidade (400)', 'VFI Vetorizada (400)', 'VFI Refinada (400 cand)', ...
              'VFI Forca Bruta (400)', 'VFI Refinada (800 cand)', 'VFI Refinada (1600 cand)', 'DC-EGM Padrao', 'VFI Refinada (3200 cand)'};

    % Valores de precisao documentados no relatorio 08
    e_ceq = [7.18e-7, 6.38e-3, 6.38e-3, 6.38e-3, 6.38e-3, 3.59e-3, 2.60e-3, 7.18e-7, 1.88e-3];
    e_cnv = [1.44e-6, 1.28e-2, 1.28e-2, 1.28e-2, 1.28e-2, 7.22e-3, 5.21e-3, 1.44e-6, 3.76e-3];
    b_mae = [3.56e-5, 7.11e-4, 7.11e-4, 7.11e-4, 7.11e-4, 1.68e-4, 4.50e-5, 3.56e-5, 2.92e-5];
    conc  = [100.00,  98.95,   98.95,   98.95,   98.95,   99.70,   100.00,  100.00,  100.00];

    for i = 1:length(chaves)
        c = chaves{i};
        s = st.(c);
        sp = st.vfi_vet.mediana_solv / s.mediana_solv;
        media_val = mean(s.tempos_solv);
        fprintf(fid3, '%s,%.3f,%.3f,%.3f,%.3f,%.3f,%.2fx,%.2e,%.2e,%.2e,%.2f\n', ...
            nomes{i}, s.mediana_solv, media_val, s.std_solv, s.min_solv, s.max_solv, sp, e_ceq(i), e_cnv(i), b_mae(i), conc(i));
    end
    fclose(fid3);
end

fprintf('Tabelas geradas com sucesso em: %s\n', pasta_tab);
