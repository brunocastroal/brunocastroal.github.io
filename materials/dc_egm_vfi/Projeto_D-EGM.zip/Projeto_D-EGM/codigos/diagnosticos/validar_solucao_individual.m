function res_multigrade = validar_solucao_individual()
% VALIDAR_SOLUCAO_INDIVIDUAL Valida a solucao individual do modelo multigrade
% sob Na in {400, 800, 1600} para VFI e DC-EGM em Equilibrio Parcial.
%
% Sintaxe:
%   res_multigrade = validar_solucao_individual()

    if exist('obter_raiz_projeto', 'file') ~= 2
        cand_r = fileparts(fileparts(fileparts(mfilename('fullpath'))));
        if isfolder(fullfile(cand_r, 'parametros'))
            addpath(fullfile(cand_r, 'parametros'));
        elseif isfolder(fullfile(pwd, 'parametros'))
            addpath(fullfile(pwd, 'parametros'));
        end
    end
    pasta_raiz = obter_raiz_projeto(mfilename('fullpath'));
    if exist('parametros_modelo_ext', 'file') ~= 2 || exist('dc_egm_extensao', 'file') ~= 2
        addpath(pasta_raiz);
        addpath(genpath(fullfile(pasta_raiz, 'codigos')));
        addpath(fullfile(pasta_raiz, 'parametros'));
    end
    pasta_res     = fullfile(pasta_raiz, 'resultados');
    if ~exist(pasta_res, 'dir'), mkdir(pasta_res); end

    fprintf('========================================================================\n');
    fprintf('  VALIDACAO DA SOLUCAO INDIVIDUAL MULTIGRADE (Na in {400, 800, 1600})\n');
    fprintf('  Especificacao: s_eps = 0.00, chi_bar = 0.05 (Determinismo + Custos)\n');
    fprintf('========================================================================\n\n');

    na_grid = [400, 800, 1600];
    res_multigrade = struct();

    for idx = 1:length(na_grid)
        Na = na_grid(idx);
        fprintf('>>> AVALIANDO RESOLUCAO Na = %d (Delta a = %.4f)...\n', Na, 80.0 / (Na - 1));
        
        % 1. Parametros e Preprocessamento
        p = parametros_modelo_ext(0.00, 0.05, Na);
        m = preprocessamento_modelo_ext(p);
        
        % 2. VFI
        fprintf('  Executando VFI vetorizada...\n');
        t_vfi = tic;
        sol_vfi = vfi_extensao_vetorizada(m, 1e-7, 1500);
        tempo_vfi = toc(t_vfi);
        fprintf('    VFI concluido: %d iters, tempo = %.3f s, erro_V = %.2e, convergiu = %d\n', ...
            sol_vfi.iter, tempo_vfi, sol_vfi.erro_V, sol_vfi.convergiu);
        
        % 3. DC-EGM
        fprintf('  Executando DC-EGM com Upper Envelope...\n');
        t_dc = tic;
        sol_dc = dc_egm_extensao(m, 1e-7, 1e-6, 1500);
        tempo_dc = toc(t_dc);
        fprintf('    DC-EGM concluido: %d iters, tempo = %.3f s, erro_V = %.2e, erro_c = %.2e, convergiu = %d\n', ...
            sol_dc.iter, tempo_dc, sol_dc.erro_V, sol_dc.erro_c, sol_dc.convergiu);
        
        % 4. Comparacao VFI vs DC-EGM
        dif_sup_V = max(abs(sol_dc.V(:) - sol_vfi.V(:)));
        dif_sup_c = max(abs(sol_dc.c_d(:) - sol_vfi.c_d(:)));
        dif_sup_ap = max(abs(sol_dc.aprime_d(:) - sol_vfi.aprime_d(:)));
        dif_d_star = sum(sol_dc.d_star(:) ~= sol_vfi.d_star(:));
        pct_d_star_match = 100.0 * (1.0 - dif_d_star / numel(sol_dc.d_star));
        
        fprintf('    Discrepancia DC-EGM vs VFI: dif_V = %.2e, dif_c = %.2e, dif_ap = %.2e, match ocup = %.2f%%\n', ...
            dif_sup_V, dif_sup_c, dif_sup_ap, pct_d_star_match);
        
        % 5. Diagnosticos
        res_V = diagnostico_concavidade_V(m, sol_dc);
        res_endo = diagnostico_grades_endogenas(m, sol_dc);
        
        fprintf('    Auditoria de Grade Endogena: total dobras = %d, min(Delta a_end) = %+.4f\n', ...
            res_endo.total_dobras, res_endo.min_global_inc);
        
        % Armazenamento
        campo = sprintf('Na_%d', Na);
        res_multigrade.(campo) = struct(...
            'Na', Na, ...
            'modelo', m, ...
            'sol_vfi', sol_vfi, ...
            'sol_dc', sol_dc, ...
            'tempo_vfi', tempo_vfi, ...
            'tempo_dc', tempo_dc, ...
            'dif_sup_V', dif_sup_V, ...
            'dif_sup_c', dif_sup_c, ...
            'dif_sup_ap', dif_sup_ap, ...
            'pct_d_star_match', pct_d_star_match, ...
            'res_V', res_V, ...
            'res_endo', res_endo ...
        );
    end

    % Salvar arquivo consolidado multigrade
    arq_salvar = fullfile(pasta_res, 'resultados_solucao_individual.mat');
    resultados_fase1 = res_multigrade;
    save(arq_salvar, 'res_multigrade', 'resultados_fase1', 'na_grid', '-v7.3');
    fprintf('\nResultados multigrade salvos com sucesso em:\n  %s\n\n', arq_salvar);
end
